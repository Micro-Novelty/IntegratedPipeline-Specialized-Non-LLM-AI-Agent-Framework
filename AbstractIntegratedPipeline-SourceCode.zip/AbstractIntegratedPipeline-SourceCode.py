# THIS IS THE SOURCE CODE OF ABSTRACTINTEGRATEDMODULE
# YOU ARE HEREBY GRANTED TO AUDIT, REVIEW, AND INITIATE PULL REQUESTS AND ISSUES
# LICENSE: MIT, PROVIDED.

'''
AbstractIntegratedPipeline
==========================
A self-contained, dependency-light ML pipeline for text classification that combines
a custom Multi-Layer Perceptron (MLP) with a hand-rolled Transformer, running on top
of NumPy alone (no PyTorch / TensorFlow required).

Core design pillars
-------------------
1. Geometric Weight Shaping (GWS)
   Weight initialisation driven by the intrinsic geometry of the input batch
   (eigenvalue decomposition, anisotropy, AME energy) rather than fixed He/Xavier
   constants.  Intended for scarce-data regimes where standard inits overfit.

2. Hybrid MLP + Transformer inference
   Each prediction combines an MLP (TF-IDF features) with a small Transformer
   (token-sequence features).  An Abstract Attention Transformation (AAT) scalar
   arbitrates between the two when they disagree.

3. Distributed / multi-agent inference
   Agents communicate over TCP sockets (optionally TLS).  Trust levels, HMAC
   message signing, and rate-limiting govern peer interactions.  Probability
   calibration can be delegated to a remote peer and blended back with local
   predictions.

4. Async wrapper
   PipelineAsyncManager bridges synchronous callers with an asyncio event loop
   running in a daemon thread.  It includes circuit-breaking, per-IP rate
   limiting, API-key auth, and audit logging.

5. Persistent memory via SQLite
   ModelStorage serialises model weights (and attention snapshots) to SQLite
   using an "active record" versioning pattern so only the latest save is
   considered "live".

Quick-start
-----------
    pipeline = IntegratedPipeline('my_model.pkl')
    manager  = PipelinePredictionManager(pipeline, label_csv='labels.csv',
                                         target_title='window_title', label='label')
    titles, y_raw, label_map = manager.load_labels_from_csv(...)
    pipeline.train(titles, y_raw)
    results = manager.advanced_prediction_method(test_titles, label_map, rules,
                                                  use_transformer=True)

Public classes (in definition order)
-------------------------------------
  MessagePriority, WrapperState, AsyncTask, TrustLevel
  RequestStatus, AsyncRequest, SecureMessage, Message
  SecurityConfig, SecurityLevel, SecurityError, AdminRole
  SingletonMeta, Singleton
  GeometricWeightShaping   – GWS weight initialisation utilities
  Activation               – static activation functions
  Loss                     – static loss / gradient helpers
  Transformer              – single-block Transformer classifier
  MLP                      – multilayer perceptron with GWS
  ModelStorage             – SQLite persistence layer
  ExplainablePredictor     – human-readable prediction explanations
  AutoBatcherAutomation    – dynamic mini-batch scheduler
  AgentDistributedInference – P2P agent networking layer
  QueryNode                – per-agent node registry and agreement checks
  IntegratedPipeline       – top-level pipeline (train / predict)
  RateLimiter, InputSanitizer, ApiKeyManager
  AsyncResultQueue, WorkerPool
  PipelineAsyncManager     – async wrapper with security and health monitoring
  PipelinePredictionManager – high-level prediction & evaluation helper
'''

import numpy as np
from sklearn.preprocessing import StandardScaler
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
import random
from sklearn.feature_extraction.text import TfidfVectorizer
from datetime import datetime, timedelta
import sqlite3
import json
import joblib
import ast
import re
import sys
import threading
import time
from collections import deque
import socket
import pickle
from collections import defaultdict
import hashlib
import ssl
import os
import asyncio
import queue
import threading
import uuid
import time
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Tuple, Optional, Dict, List
from datetime import datetime, timedelta
from enum import IntEnum, Enum
from collections import deque
import traceback
from concurrent.futures import TimeoutError as FutureTimeoutError
import secrets
import ipaddress
from functools import wraps
import hmac
import aiohttp
import psutil
from sklearn.preprocessing import StandardScaler



# initial Setup logging for AgentDistributedInference and ModelStorage class logger and security logger
logger = logging.getLogger(__name__)

class MessagePriority(Enum):
    '''
    Priority levels for messages in the async/threaded queues.
    Lower integer value = higher urgency.  Messages with equal priority are
    processed in FIFO order (oldest creation timestamp first).
    '''
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3

class WrapperState(Enum):
    """Wrapper state machine."""
    UNINITIALIZED = "uninitialized"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    STOPPED = "stopped"
    ERROR = "error"

@dataclass
class AsyncTask:
    """Track async tasks for proper cleanup."""
    id: str
    future: asyncio.Future
    created_at: float
    callback: Optional[Callable] = None
    timeout: float = 30.0

class TrustLevel(IntEnum):
    """Trust levels for peer agents"""
    UNTRUSTED = 0      # No trust - will be rejected
    BASIC = 1          # Basic trust - limited operations
    STANDARD = 2       # Standard trust - most operations
    HIGH = 3           # High trust - sensitive operations
    FULL = 4           # Full trust - administrative access


class RequestStatus(Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"

@dataclass
class AsyncRequest:
    """Track an async prediction request"""
    request_id: str
    texts: Any
    api_key: Optional[str]
    client_ip: Optional[str]
    callback: Optional[Callable] = None
    webhook_url: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    status: RequestStatus = RequestStatus.PENDING
    result: Optional[Dict] = None
    error: Optional[str] = None
    completed_at: Optional[float] = None
    
    @property
    def age(self) -> float:
        return time.time() - self.created_at
    
    @property
    def is_expired(self, timeout: int = 30) -> bool:
        return self.age > timeout

@dataclass
class SecureMessage:
    '''
    Lightweight authenticated envelope for inter-agent socket messages.

    Fields
    ------
    id        : Unique message identifier (UUID string recommended).
    type      : Logical message type string (e.g. 'predict_request').
    payload   : Arbitrary data to transmit.  Must be pickle-serialisable.
    timestamp : Unix epoch float; used by the receiver for replay-attack
                detection (reject messages older than a configurable window).
    signature : HMAC-SHA256 hex digest computed over the sorted, pickled
                payload by AgentDistributedInference._sign_message().
                Empty string means the message has not yet been signed.
    '''
    # Secure message wrapper
    id: str
    type: str
    payload: Any
    timestamp: float
    signature: str = ""

@dataclass
class Message:
    '''
    Full-featured message object used by both AsyncMessageQueue and
    ThreadedMessageQueue.

    Routing
    -------
    sender / recipient : Logical agent identifiers (string).
    type               : Handler dispatch key.  Each queue registers handlers
                         keyed on this string (e.g. 'predict', 'sync_memory').

    Reliability
    -----------
    retry_count / max_retries : A failed handler is re-queued up to max_retries
                                times before the message is forwarded to the
                                dead-letter queue.
    timeout / is_expired      : Messages older than `timeout` seconds are
                                dropped silently with a warning log.

    Priority ordering
    -----------------
    Comparison operators (__lt__ etc.) allow Python's heapq / PriorityQueue to
    sort messages.  Within the same priority level, older messages win (FIFO).
    '''
    id: str
    type: str
    sender: str
    recipient: str
    payload: Any
    timestamp: datetime
    priority: MessagePriority = MessagePriority.NORMAL
    callback: Optional[Callable] = None
    retry_count: int = 0
    max_retries: int = 3
    timeout: float = 30.0
    created_at: float = field(default_factory=time.time)
    
    @property
    def age(self) -> float:
        """Age of message in seconds."""
        return time.time() - self.created_at
    
    @property
    def is_expired(self) -> bool:
        """Check if message has expired."""
        return self.age > self.timeout
    
    # ============ COMPARISON METHODS FOR PRIORITY QUEUE ============
    
    def __lt__(self, other):
        """Less than comparison for priority queue."""
        if not isinstance(other, Message):
            return NotImplemented
        
        # Compare by priority value first (lower number = higher priority)
        if self.priority.value != other.priority.value:
            return self.priority.value < other.priority.value
        
        # If same priority, compare by creation time (older messages get processed first)
        return self.created_at < other.created_at
    
    def __le__(self, other):
        """Less than or equal."""
        if not isinstance(other, Message):
            return NotImplemented
        return self.__lt__(other) or self.__eq__(other)
    
    def __eq__(self, other):
        """Equality comparison."""
        if not isinstance(other, Message):
            return NotImplemented
        return self.id == other.id
    
    def __ne__(self, other):
        """Not equal."""
        if not isinstance(other, Message):
            return NotImplemented
        return not self.__eq__(other)
    
    def __gt__(self, other):
        """Greater than."""
        if not isinstance(other, Message):
            return NotImplemented
        return not self.__lt__(other) and not self.__eq__(other)
    
    def __ge__(self, other):
        """Greater than or equal."""
        if not isinstance(other, Message):
            return NotImplemented
        return not self.__lt__(other)
    
    def __hash__(self):
        """Make Message hashable (useful for sets/dicts)."""
        return hash(self.id)


@dataclass
class SecurityConfig:
    """
    Security configuration for PipelineAsyncManager.

    Rate limiting
    -------------
    rate_limit_requests   : Max requests allowed per `rate_limit_window` seconds
                            for a regular (non-admin) caller.
    admin_rate_limit      : Separate, higher limit for admin-token callers.
    admin_bypass_rate_limit : When True, admin callers skip the bucket entirely
                              unless admin_rate_limit < 999.

    IP access control
    -----------------
    allowed_ips           : CIDR-capable whitelist.  Empty list = allow all IPs.
    blocklisted_ips       : Explicit deny list, checked before whitelist.
    admin_allowed_ips     : Separate whitelist for admin callers when
                            enforce_admin_ip_whitelist is True.

    Resource guards (NOT authentication)
    -------------------------------------
    max_cpu_percent / max_memory_percent / min_disk_space_mb:
        PipelineAsyncManager._start_with_limits() refuses to start if any
        system resource threshold is exceeded, preventing runaway launches.
    min_start_interval    : Minimum seconds between successive start() calls;
                            blocks rapid restart / crash-loop attacks.
    max_consecutive_failures : Circuit-breaker threshold; after this many
                            failed start attempts the breaker opens.

    Bootstrap auth (optional, only enforced in HARDENED security level)
    --------------------------------------------------------------------
    require_bootstrap_auth : When True, start() demands a one-time bootstrap
                             token whose SHA-256 hash matches bootstrap_token_hash.
    """
    max_text_length: int = 10000
    max_queue_size: int = 100
    max_pending_tasks: int = 50
    rate_limit_requests: int = 60  # per minute
    rate_limit_window: int = 60  # seconds
    request_timeout: float = 30.0
    max_concurrent: int = 10
    enable_auth: bool = True
    allowed_ips: List[str] = field(default_factory=list)  # Empty = allow all
    blocklisted_ips: List[str] = field(default_factory=list)
    require_api_key: bool = True
    api_key_rotation_days: int = 30

    # Admin-specific settings
    admin_bypass_rate_limit: bool = True  # Admins bypass rate limiting
    admin_bypass_ip_check: bool = False   # Admins still need IP whitelist
    enforce_admin_ip_whitelist: bool = True  # Separate admin IP whitelist
    admin_allowed_ips: List[str] = field(default_factory=list)  # Admin-specific IPs
    admin_rate_limit: int = 300  # Higher limit for admins (per minute)
    log_all_admin_actions: bool = True
    
    # Start protection (NOT authentication)
    min_start_interval: float = 5.0  # Seconds between start attempts
    max_consecutive_failures: int = 3  # Before circuit breaker
    max_cpu_percent: float = 99.0  # Don't start if CPU > 99%
    max_memory_percent: float = 95.0  # Don't start if memory > 95%
    min_disk_space_mb: int = 100  # Minimum 100MB free
    
    # Per-request security (REAL authentication)
    rate_limit_per_ip: bool = True
    
    # Optional: Bootstrap only for critical deployments
    require_bootstrap_auth: bool = False  # Default OFF for flexibility
    bootstrap_token_hash: Optional[str] = None  # Only if above is True    

class SecurityLevel(Enum):
    """Deployment security levels"""
    DEVELOPMENT = "dev"      # No security, max flexibility
    STAGING = "staging"      # API keys only
    PRODUCTION = "prod"      # API keys + rate limiting
    HARDENED = "hardened"    # Everything + bootstrap token

class SecurityError(Exception):
    pass

class AdminRole(Enum):
    ADMIN = "admin"
    OPERATOR = "operator"  # Can view but not modify
    AUDITOR = "auditor"     # Can only view audit log


class SingletonMeta(type):
    """Thread-safe singleton metaclass"""
    _instances: Dict[type, Any] = {}
    _lock: threading.Lock = threading.Lock()
    
    def __call__(cls, *args, **kwargs):
        # Double-checked locking pattern:
        #   Fast path (no lock) — if the instance already exists, return immediately.
        #   Slow path (with lock) — only one thread can create the instance; a second
        #   check inside the lock guards against two threads both passing the fast path
        #   before either acquires the lock.
        if cls in cls._instances:
            return cls._instances[cls]
        
        # Slow path: create instance with lock
        with cls._lock:
            if cls not in cls._instances:
                instance = super().__call__(*args, **kwargs)
                cls._instances[cls] = instance
            return cls._instances[cls]
    
    @classmethod
    def clear_instance(cls, target_class):
        """Clear singleton instance (useful for testing)"""
        with cls._lock:
            if target_class in cls._instances:
                del cls._instances[target_class]
    
    @classmethod
    def get_instance(cls, target_class):
        """Get instance without creating"""
        return cls._instances.get(target_class)


class Singleton(metaclass=SingletonMeta):
    """Base singleton class - inherit from this"""
    _initialized = False
    
    def __new__(cls, *args, **kwargs):
        # This is handled by metaclass, but for clarity
        return super().__new__(cls)
    
    def __init__(self, *args, **kwargs):
        if self._initialized:
            print(f"[===] Reusing existing {self.__class__.__name__} instance (id: {id(self)})")
            return
        self._initialized = True
        print(f"[===] Creating NEW {self.__class__.__name__} instance (id: {id(self)})")

# ________ UTILITY functions for activations and losses, can be used across different models and architectures, targeted for LSTM. _________

def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -500, 500)))

def sigmoid_deriv(s):          # s = sigmoid(x) already computed
    return s * (1.0 - s)

def tanh_deriv(t):             # t = tanh(x) already computed
    return 1.0 - t ** 2


class LSTMCell:
    """
    Single LSTM cell operating on one time-step.

    Gate layout (all concatenated into one weight matrix for speed):
        W shape: (4*hidden, input + hidden)
        b shape: (4*hidden,)

    Slice order: [forget | input | gate (candidate) | output]
    """

    def __init__(self, input_size: int, hidden_size: int, seed: int = 42):
        self.input_size  = input_size
        self.hidden_size = hidden_size
        np.random.seed(seed)

        # Xavier / Glorot init
        scale = np.sqrt(2.0 / (input_size + hidden_size))
        self.W = np.random.randn(4 * hidden_size, input_size + hidden_size) * scale
        self.b = np.zeros((4 * hidden_size,))

        # Output projection: hidden → output
        self.Wy = np.random.randn(hidden_size, hidden_size) * scale
        self.by = np.zeros((hidden_size,))

    # ── slicing helpers ──────────────────────
    def _f(self, v): return v[:self.hidden_size]
    def _i(self, v): return v[self.hidden_size:2*self.hidden_size]
    def _g(self, v): return v[2*self.hidden_size:3*self.hidden_size]
    def _o(self, v): return v[3*self.hidden_size:]

    # _________ forward method for cell class _____________
    def forward(self, x_seq: np.ndarray, h0=None, c0=None):
        T              = x_seq.shape[0]
        H              = self.hidden_size
        expected_input = self.input_size

        h = np.zeros(H) if h0 is None else h0.copy()
        c = np.zeros(H) if c0 is None else c0.copy()

        hs    = np.zeros((T, H))
        cs    = np.zeros((T, H))
        cache = []

        # preallocate xh buffer once
        xh = np.empty(expected_input + H)

        for t in range(T):
            x = x_seq[t]
            if x.ndim == 0:
                x = x.reshape(1)
            if x.shape[0] < expected_input:
                x = np.pad(x, (0, expected_input - x.shape[0]))
            elif x.shape[0] > expected_input:
                x = x[:expected_input]

            # write into buffer, no allocation
            xh[:expected_input] = x
            xh[expected_input:] = h

            z      = self.W @ xh + self.b
            H1, H2, H3 = H, H * 2, H * 3

            # direct slices, no method calls
            f      = sigmoid(z[:H1])
            i      = sigmoid(z[H1:H2])
            g      = np.tanh(z[H2:H3])
            o      = sigmoid(z[H3:])

            c_new  = f * c + i * g
            tanh_c = np.tanh(c_new)
            h_new  = o * tanh_c

            # store copies — h/c will be overwritten next iteration 
            cache.append((x.copy(), h.copy(), c.copy(),
                        f, i, g, o, c_new, tanh_c, xh.copy()))
            h, c = h_new, c_new
            hs[t] = h
            cs[t] = c

        return hs, cs, cache

    # ________ backward method for Cell class __________
    def backward(self, dhs: np.ndarray, cache,
                dh_next=None, dc_next=None, T_limit=None):
        # T_limit avoids slicing cache list externally
        T = T_limit if T_limit is not None else len(cache)
        H = self.hidden_size

        dW     = np.zeros_like(self.W)
        db     = np.zeros_like(self.b)
        dh     = np.zeros(H) if dh_next is None else dh_next.copy()
        dc     = np.zeros(H) if dc_next is None else dc_next.copy()
        dx_seq = np.zeros((T, self.input_size))

        # preallocate dz buffer once
        dz     = np.empty(4 * H)
        H1, H2, H3 = H, H * 2, H * 3

        for t in reversed(range(T)):
            x, h_prev, c_prev, f, i, g, o, c_new, tanh_c, xh = cache[t]

            dh_total = dhs[t] + dh

            do     = dh_total * tanh_c
            dtanhc = dh_total * o
            dc_new = dtanhc * tanh_deriv(tanh_c) + dc

            df = dc_new * c_prev
            di = dc_new * g
            dg = dc_new * i
            dc = dc_new * f

            # write into preallocated dz buffer
            dz[:H1]  = df * sigmoid_deriv(f)
            dz[H1:H2] = di * sigmoid_deriv(i)
            dz[H2:H3] = dg * tanh_deriv(g)
            dz[H3:]   = do * sigmoid_deriv(o)

            # nplace accumulation, no intermediate allocation
            dW  += np.outer(dz, xh)   # unavoidable alloc but outer is C-level
            db  += dz

            dxh        = self.W.T @ dz
            dx_seq[t]  = dxh[:self.input_size]
            dh         = dxh[self.input_size:]

        return {"dW": dW, "db": db}, dx_seq, dh, dc


# ─────────────────────────────────────────────
#  LSTM Network (cell + linear output head)
# ─────────────────────────────────────────────
class LSTMNetwork:
    def __init__(self, pipeline, input_size, hidden_size, output_size, seed=0):
        self.cell         = LSTMCell(input_size, hidden_size, seed)
        self.weight_shaper = GeometricWeightShaping(output_size, hidden_size)
        self.Wy           = None
        self.by           = np.zeros(output_size)
        self.pipeline     = pipeline
        self._trained     = False

    # forward method to calculate proper weight for prediction and training.
    def forward(self, x_seq):
        # also Wy init only here, removed from train_step
        if self.Wy is None:
            self.Wy = self.weight_shaper.weight_shaping(x_seq)
        hs, cs, cache = self.cell.forward(x_seq)
        preds = hs @ self.Wy.T + self.by   # (T, output_size)
        return preds, hs, cs, cache

    # calculate loss of MSE (Mean squared error.)
    def loss_mse(self, preds, targets, AMR):
        # proper and correct shape alignment
        min_T = min(preds.shape[0], targets.shape[0])
        min_F = min(preds.shape[1], targets.shape[1])
        preds   = preds[:min_T, :min_F]
        targets = targets[:min_T, :min_F]

        diff = preds - targets
        loss = (1.0 - AMR) * np.mean(diff ** 2)
        dloss = diff / (min_T * min_F)   # FIX 3 — normalize by full element count
        return loss, dloss

    # backward method for the network to calculate proper weights with cell backward
    def backward(self, dpreds, hs, cache):
        min_T  = min(dpreds.shape[0], hs.shape[0])
        dpreds = dpreds[:min_T]
        hs     = hs[:min_T]

        dWy = dpreds.T @ hs
        dby = dpreds.sum(axis=0)
        dhs = dpreds @ self.Wy

        # pass min_T directly, need to avoid creating a sliced list
        cell_grads, dx, _, _ = self.cell.backward(dhs, cache, T_limit=min_T)
        return cell_grads, {"dWy": dWy, "dby": dby}, dx

    # update ensured proper gradient clipping
    def update(self, cell_grads, out_grads, lr=1e-3, clip=5.0):
        def clip_and_step(param, grad):
            np.clip(grad, -clip, clip, out=grad)  
            param -= lr * grad

        clip_and_step(self.cell.W, cell_grads["dW"])
        clip_and_step(self.cell.b, cell_grads["db"])
        clip_and_step(self.Wy,     out_grads["dWy"])
        clip_and_step(self.by,     out_grads["dby"])

    # train step for each LSTM fitting method 
    def train_step(self, x_seq, targets, lr=1e-3, AMR=None):
        # accept precomputed AMR 
        if AMR is None:
            AME = self.pipeline.AME_Encoder(x_seq)
            AMR = 1.0 / (1.0 + np.exp(-AME))

        preds, hs, cs, cache = self.forward(x_seq)
        loss, dloss          = self.loss_mse(preds, targets, AMR)
        cell_grads, out_grads, _ = self.backward(dloss, hs, cache)
        self.update(cell_grads, out_grads, lr)
        return loss, preds



# ─────────────────────────────────────────────
#  LSTM Engine
# ─────────────────────────────────────────────

class LSTMEngine:
    """
    Wraps a trained LSTMNetwork and adds three confidence layers:

      Layer 1 — MC Dropout on hidden state (h)
                Perturbs h between timesteps — respects the cell's
                internal recurrence without touching W or b.
                Most faithful to this architecture.

      Layer 2 — Gate uncertainty
                Reads forget/input gate activations directly from cache.
                Low forget + high input = model is overwriting memory
                = structurally uncertain moment.

      Layer 3 — Prediction interval
                Built from validation residuals. Distribution-free,
                zero extra parameters, works on edge hardware.

    Usage:
        engine = LSTMEngine(model, dropout=0.1, n_samples=50)
        engine.calibrate(X_val, Y_val)
        result = engine.predict(x_seq, label_bins=None)
    """

    def __init__(self, pipeline: Any, model_network: LSTMNetwork, dropout: float = 0.1,
                 n_samples: int = 50):
        self.pipeline = pipeline
        self.model     = model_network
        self.dropout   = dropout
        self.n_samples = n_samples
        self.residual_std  = None   # set by calibrate()
        self.residual_mean = None

    # ── calibrate on validation set ──────────
    def calibrate_residual(self, X_val, Y_val):
        if len(X_val) == 0:
            self.residual_mean = 0.0
            self.residual_std  = 1.0
            return

        confidence_errors = []

        for j in range(len(X_val)):
            preds, _, _, _ = self.model.forward(X_val[j])

            pred_vals = preds[:, 0] if preds.ndim > 1 else preds

            # get true class
            true_vals = Y_val[j, :, 0] if Y_val[j].ndim > 1 else Y_val[j]
            min_len   = min(len(pred_vals), len(true_vals))

            # sigmoid to get predicted probability
            pred_prob = 1.0 / (1.0 + np.exp(-pred_vals[:min_len]))
            true_bin  = true_vals[:min_len].astype(float)

            # confidence error — how wrong was the predicted probability
            # correct prediction   → low error
            # wrong prediction     → high error
            err = np.abs(pred_prob - true_bin)
            confidence_errors.extend(err.tolist())

        errors = np.array(confidence_errors)

        # IQR outlier removal
        q25, q75     = np.percentile(errors, [25, 75])
        iqr          = q75 - q25
        mask         = (errors >= q25 - 1.5 * iqr) & (errors <= q75 + 1.5 * iqr)
        clean        = errors[mask] if mask.sum() > 0 else errors

        self.residual_mean = float(clean.mean())
        self.residual_std  = float(max(clean.std(), 1e-6))

        # floor std on small n — can't trust calibration with few samples
        if len(X_val) < 20:
            self.residual_std = max(self.residual_std, 0.1)
            print(f'[!] Small val set ({len(X_val)} samples) — flooring σ to 0.1')

        self.calibration_coverage   = float(mask.mean())
        self.n_calibration_samples  = len(X_val)

        print(f"[=] Calibrated: residual μ={self.residual_mean:.4f} "
            f"σ={self.residual_std:.4f} "
            f"coverage={self.calibration_coverage:.1%} "
            f"n={self.n_calibration_samples}")


    # ── MC dropout forward ────────────────────
    def _mc_forward(self, x_seq: np.ndarray) -> np.ndarray:
        T            = x_seq.shape[0]
        H            = self.model.cell.hidden_size
        expected_input = self.model.cell.input_size
        p            = self.dropout
        cell         = self.model.cell
        W            = cell.W
        b            = cell.b
        H1, H2, H3  = H, H * 2, H * 3   # slice boundaries precomputed

        # Wy check once before loop
        if self.model.Wy is None:
            self.model.Wy = self.model.weight_shaper.weight_shaping(x_seq)
        Wy = self.model.Wy
        by = self.model.by

        h     = np.zeros(H)
        c     = np.zeros(H)
        xh    = np.empty(expected_input + H)  # preallocate concat buffer
        preds = np.empty(T)                   # preallocate output

        # precompute dropout scale factor
        inv_keep = 1.0 / (1.0 - p)

        for t in range(T):
            x = x_seq[t]

            # shape alignment
            if x.ndim == 0:
                x = x.reshape(1)
            if x.shape[0] < expected_input:
                x = np.pad(x, (0, expected_input - x.shape[0]))
            elif x.shape[0] > expected_input:
                x = x[:expected_input]

            # need to write into preallocated buffer instead of np.concatenate
            xh[:expected_input] = x
            xh[expected_input:] = h

            z = W @ xh + b                    # (4H,)

            # direct slices instead of method calls
            f      = sigmoid(z[:H1])
            i      = sigmoid(z[H1:H2])
            g      = np.tanh(z[H2:H3])
            o      = sigmoid(z[H3:])

            c      = f * c + i * g
            tanh_c = np.tanh(c)
            h      = o * tanh_c

            # precomputed inv_keep, inplace mask application
            mask = (np.random.rand(H) > p) * inv_keep
            h   *= mask

            preds[t] = (h @ Wy.T + by)[0]

        return preds   # (T,)

    # ── gate uncertainty for LSTM prediction──────────────────────
    def _gate_uncertainty(self, x_seq: np.ndarray, AMR: float) -> np.ndarray:
        """
        Structural uncertainty from gate activations.
        Vectorized — no Python loop over timesteps.
        """
        _, _, cache = self.model.cell.forward(x_seq)

        # cache[t] = (x, h_prev, c_prev, f, i, g, o, c_new, tanh_c, xh)
        # need to extract f and i directly as stacked arrays — shape (T, H)
        T = len(cache)
        
        if T == 0:
            return np.array([0.0])

        # vectorized extraction — one pass instead of T unpacks
        f_all = np.empty((T, cache[0][3].shape[0]))  # (T, H)
        i_all = np.empty((T, cache[0][4].shape[0]))  # (T, H)

        for t, entry in enumerate(cache):
            f_all[t] = entry[3]   # forget gate
            i_all[t] = entry[4]   # input gate

        # vectorized computation — no per-timestep Python arithmetic
        forget_instability = 1.0 - f_all.mean(axis=1)   # (T,)
        input_activity     = i_all.mean(axis=1)           # (T,)

        # precompute scalar factor once
        scale = 1.0 - AMR
        gate_uncertainty = scale * (forget_instability + input_activity)

        return np.clip(gate_uncertainty, 0.0, 1.0)      

    # empirical quantiles from actual residuals
    def calibrate(self, X_val, Y_val):
        if len(X_val) == 0:
            self.residual_mean = 0.0
            self.residual_std  = 1.0
            self.quantiles     = {}
            return

        all_errors = []
        for j in range(len(X_val)):
            preds, _, _, _ = self.model.forward(X_val[j])
            y         = Y_val[j]
            pred_vals = preds[:, 0] if preds.ndim > 1 else preds
            true_vals = y[:, 0]    if y.ndim > 1    else y
            min_T     = min(len(pred_vals), len(true_vals))
            all_errors.append(pred_vals[:min_T] - true_vals[:min_T])

        residuals = np.concatenate(all_errors)
        n         = len(residuals)

        self.residual_mean = float(residuals.mean())
        self.residual_std  = float(max(residuals.std(), 1e-6))

        # adapt confidence levels to sample size
        # small n → only compute what's statistically supportable
        if n < 20:
            # only 90% interval is reliable — use 10th/90th percentile
            # wide enough to be honest about uncertainty
            levels = [10.0, 90.0]
            p = np.percentile(residuals, levels)
            self.quantiles = {
                0.90: (float(p[0]), float(p[1])),
                0.95: (float(p[0]), float(p[1])),  # same as 90% — honest, not fake precision
                0.99: (float(p[0]), float(p[1])),
            }
            print(f'[!] n={n} too small for tail quantiles — '
                f'using 10th/90th for all intervals')

        elif n < 50:
            # 90% and 95% supportable, 99% not reliable
            levels = [2.5, 5.0, 95.0, 97.5]
            p = np.percentile(residuals, levels)
            self.quantiles = {
                0.90: (float(p[1]), float(p[2])),
                0.95: (float(p[0]), float(p[3])),
                0.99: (float(p[0]), float(p[3])),  # same as 95% — honest
            }
            print(f'[!] n={n} insufficient for 99% interval — '
                f'using 95% as proxy')

        else:
            # full precision justified
            levels = [0.5, 2.5, 5.0, 95.0, 97.5, 99.5]
            p = np.percentile(residuals, levels)
            self.quantiles = {
                0.90: (float(p[2]), float(p[3])),
                0.95: (float(p[1]), float(p[4])),
                0.99: (float(p[0]), float(p[5])),
            }

        # floor std on small n
        if n < 20:
            self.residual_std = max(self.residual_std, 0.1)

        print(f"[=] Calibrated: μ={self.residual_mean:.4f} "
            f"σ={self.residual_std:.4f} "
            f"n={n} "
            f"90%=[{self.quantiles[0.90][0]:.4f}, {self.quantiles[0.90][1]:.4f}]")

    # interval to calculate prediction interval from MC mean + empirical quantiles
    def _interval(self, mc_mean, confidence_level):
        # flatten mc_mean safely — handles scalar, 0-d array, or 1-d array
        mc_scalar = float(np.asarray(mc_mean).flat[0])

        if confidence_level not in self.quantiles:
            available = sorted(self.quantiles.keys())
            if not available:
                return mc_scalar - self.residual_std, mc_scalar + self.residual_std
            confidence_level = min(available, key=lambda k: abs(k - confidence_level))
            print(f'[!] Confidence level not found, using closest: {confidence_level}')

        lo_bias, hi_bias = self.quantiles[confidence_level]

        lo = mc_scalar + float(np.asarray(lo_bias).flat[0])
        hi = mc_scalar + float(np.asarray(hi_bias).flat[0])

        if lo > hi:
            lo, hi = hi, lo

        return lo, hi

    # MC sample counting for label confidence (last timestep)
    def _label_confidence_empirical(self, mc_samples_last, label_bins):
        """
        mc_samples_last : (n_samples,) — raw MC draws at last timestep
        label_bins      : {"Good": (0, 35), "Moderate": (35, 75), ...}
        """
        n = len(mc_samples_last)
        if n == 0:
            return {name: 0.0 for name in label_bins}

        names  = list(label_bins.keys())
        bounds = np.array(list(label_bins.values()))  # (n_bins, 2)

        # vectorized — broadcast (n_samples,) against (n_bins, 2)
        # samples shape: (1, n_samples), bounds shape: (n_bins, 1)
        samples = mc_samples_last[np.newaxis, :]          # (1, n_samples)
        lo      = bounds[:, 0, np.newaxis]                # (n_bins, 1)
        hi      = bounds[:, 1, np.newaxis]                # (n_bins, 1)

        hits = ((samples >= lo) & (samples < hi)).sum(axis=1)  # (n_bins,)
        probs = hits / n                                        # (n_bins,)

        return dict(zip(names, probs.tolist()))

    # LSTM training loop with confidence layers integrated into the loss and validation monitoring.
    def fit_stm(self, X, Y, epochs=50, hidden=32, lr=5e-3, seq_len=20, print_every=5):
        print("[= =] Training LSTM with confidence layers (MC dropout + gate uncertainty + prediction intervals)")
   
        model   = self.model
        AME = self.pipeline.AME_Encoder(X)
        AMR = 1.0 / (1.0 + np.exp(-AME))

        n_train = int((1.0 - AMR) * len(X))
        X_tr, Y_tr = X[:n_train], Y[:n_train]
        X_te, Y_te = X[n_train:], Y[n_train:]

        idx = np.arange(n_train)

        for epoch in range(1, epochs + 1):
            np.random.shuffle(idx)
            epoch_loss = 0.0
            for j in idx:
                loss, _ = model.train_step(X_tr[j], Y_tr[j], lr=lr, AMR=AMR)
                epoch_loss += loss
            epoch_loss /= n_train

            if epoch % print_every == 0 or epoch == 1:
                # validation
                val_loss = 0.0
                for j in range(len(X_te)):
                    preds, _, _, _ = model.forward(X_te[j])
                    if preds.shape != Y_te.shape:
                        if preds.shape[0] > Y_te.shape[0]:
                            Y_te = Y_te[:preds.shape[0], :]
                        if Y_te.shape[0] > preds.shape[0]:
                            preds = preds[:Y_te.shape[0], :]
                        else:
                            preds = preds[:Y_te.shape[0], :Y_te.shape[1]]

                    Y_te = Y_te[:preds.shape[0], :preds.shape[1]]
                    preds = preds[:Y_te.shape[0], :Y_te.shape[1]]   

                    val_loss += AMR * np.mean((preds - Y_te[j]) ** 2)
                val_loss /= len(X_te)
                print(f"[=] Epoch {epoch:>4}/{epochs}  "
                    f"[=] train_loss={epoch_loss:.6f}  val_loss={val_loss:.6f}")

        print("[=] Training complete!")
        print(f"[=] Final val loss: {val_loss:.6f}")
        print('===== CALIBRATION METHOD =====')
        self.calibrate_residual(X_te, Y_te)

    # get optimal lstm samples amount for the model to process
    def lstm_optimal_samples(self, engine, x_seq, tolerance=0.005, max_n=500):
        """
        Run increasing n_samples until std estimate stabilizes.
        Stable = change in std < tolerance between consecutive checks.
        """
        prev_std = None
        for n in range(10, max_n, 10):
            samples = np.stack([
                engine._mc_forward(x_seq) for _ in range(n)
            ])
            current_std = samples.std(axis=0).mean()
            if prev_std is not None:
                delta = abs(current_std - prev_std)
                print(f"  n={n:>4}  std={current_std:.5f}  delta={delta:.5f}")
                if delta < tolerance:
                    print(f"  → Converged at n={n}")
                    return n
            prev_std = current_std
        return max_n

    # derive local bins for flexibility in scarce dataset
    def derive_bins_from_data(self, y_values, n_bins=4, labels=None):
        """
        Use percentiles of actual data to set boundaries.
        Guarantees roughly equal sample count per bin —
        avoids empty bins on skewed distributions.
        """
        unique_vals = np.unique(y_values)

        # if binary or near-binary — skip percentiles entirely
        if len(unique_vals) <= 2:
            if labels is None:
                labels = ["Negative", "Positive"]
            return {
                labels[0]: (float(unique_vals[0]) - 1e-6,
                            float(unique_vals[0]) + 1e-6),
                labels[1]: (float(unique_vals[-1]) - 1e-6,
                            float(unique_vals[-1]) + 1e-6),
            }

        # if highly skewed — need to derive from non-dominant values
        dominant_val  = float(np.percentile(y_values, 50))
        dominant_frac = (y_values == dominant_val).mean()

        if dominant_frac > 0.5:
            # majority is one value — use non-dominant for percentiles
            non_dominant = y_values[y_values != dominant_val]
            percentiles  = np.linspace(0, 100, n_bins)
            boundaries   = np.percentile(non_dominant, percentiles)

            if labels is None:
                labels = ["Base"] + [f"Level_{i+1}" for i in range(n_bins-1)]

            bins = {"Base": (-1e-6, float(boundaries[0]))}
            for i in range(n_bins - 1):
                lo = boundaries[i]
                hi = boundaries[i+1] if i < n_bins-2 else boundaries[i+1]*1.5
                bins[labels[i+1]] = (float(lo), float(hi))
            return bins

        # normal case — standard percentile approach
        percentiles = np.linspace(0, 100, n_bins + 1)
        boundaries  = np.percentile(y_values, percentiles)
        if labels is None:
            labels = [f"Level_{i+1}" for i in range(n_bins)]
        bins = {}
        for i in range(n_bins):
            lo = boundaries[i]
            hi = boundaries[i+1] if i < n_bins-1 else boundaries[i+1]*1.5
            bins[labels[i]] = (float(lo), float(hi))
        return bins


    # ── main predict function for the whole network ─────────────────────────
    def predict(self, x_seq: np.ndarray,
                label_bins: dict = None,
                confidence_level: float = 0.90) -> Any:
        """
        Full confidence-aware prediction.

        Args:
            x_seq          : (T, input_size)
            label_bins     : optional dict defining label thresholds
                             e.g. {"Low": (-1, -0.33),
                                   "Mid": (-0.33, 0.33),
                                   "High": (0.33, 1.0)}
            confidence_level: for prediction interval (default 90%)

        Returns dict with:
            prediction     : point estimate (T,)
            mc_mean        : MC dropout mean (T,)
            mc_std         : MC dropout std  (T,)
            mc_confidence  : per-timestep confidence in [0,1]
            gate_uncertainty: structural uncertainty (T,)
            interval_low   : lower bound of prediction interval (T,)
            interval_high  : upper bound of prediction interval (T,)
            label_confidence: {label: probability} if label_bins given
            overall        : single scalar confidence for last timestep
        """
        # ── point prediction ──────────────────
        preds_clean, _, _, _ = self.model.forward(x_seq)
        AME = self.pipeline.AME_Encoder(x_seq)  # geometric complexity scalar
        AMR = 1.0 / (1.0 + np.exp(-AME))  # abstract modelling rate
        point = preds_clean[:, 0]   # (T,)

        # ── MC dropout sampling ───────────────
        samples = np.stack([
            self._mc_forward(x_seq) for _ in range(self.n_samples)
        ])  # (n_samples, T)


        mc_mean = samples.mean(axis=0)   # (T,)
        mc_std  = samples.std(axis=0)    # (T,)

        # confidence: tight distribution = high confidence
        # normalize std by typical residual std so scale is meaningful
        normalized_std = mc_std / (self.residual_std + 1e-8)
        mc_confidence  = np.exp(-normalized_std)   # (T,) in (0,1]

        # ── gate uncertainty ──────────────────
        gate_unc = self._gate_uncertainty(x_seq, AMR)   # (T,)

        # ── prediction interval ───────────────
        total_std = np.sqrt(mc_std**2 + self.residual_std**2)        
        # compute interval for every timestep — always returns (T,) arrays
        interval_low  = np.empty(len(mc_mean))
        interval_high = np.empty(len(mc_mean))
        for t in range(len(mc_mean)):
            interval_low[t], interval_high[t] = self._interval(mc_mean[t], confidence_level)

        # ── label confidence (last timestep) ──
        label_conf = None
        if label_bins is not None:
            label_conf = self._label_confidence_empirical(samples[:, -1], 
                          label_bins)

            # renormalize
            total_p = sum(label_conf.values()) + 1e-8
            label_conf = {k: v/total_p for k, v in label_conf.items()}

        # ── overall scalar confidence ─────────
        # weighted combination of MC confidence and gate stability
        gate_stability = 1.0 - gate_unc[-1]           # high = stable
        overall = (1.0 - AMR) * mc_confidence[-1] + \
                  self.pipeline.confidence_threshold * gate_stability     

        return {
            "prediction"      : point,
            "mc_mean"         : mc_mean,
            "mc_std"          : mc_std,
            "mc_confidence"   : mc_confidence,
            "gate_uncertainty": gate_unc,
            "interval_low"    : interval_low,
            "interval_high"   : interval_high,
            "label_confidence": label_conf,
            "overall"         : overall,
        }
        
    # ─────────────────────────────────────────────
    #  Architecture summary helper to visualize results
    # ─────────────────────────────────────────────
    def architectural_summary(self, model: LSTMNetwork):
        H = model.cell.hidden_size
        I = model.cell.input_size
        O = model.Wy.shape[0]
        W_params  = model.cell.W.size + model.cell.b.size
        Wy_params = model.Wy.size + model.by.size
        total     = W_params + Wy_params

        print("\n┌─────────────────────────────────────────┐")
        print("  │          LSTM Architecture Summary      │")
        print("  ├─────────────────────────────────────────┤")
        print(f" │  Input  size   : {I:<24}│")
        print(f" │  Hidden size   : {H:<24}│")
        print(f" │  Output size   : {O:<24}│")
        print(f" │  LSTM   params : {W_params:<24,}│")
        print(f" │  Linear params : {Wy_params:<24,}│")
        print(f" │  Total  params : {total:<24,}│")
        print("  └─────────────────────────────────────────┘")




# geometric weight shaping provides the model with a robust geometric complexity alignment>
#  allowing it to better process data with varying geometric complexity, and providing a more stable training process in scarce data environment. 
# It can be used as a general weight initialization and shaping method for various models, especially in scenarios where data geometry is complex and data is scarce.

class GeometricWeightShaping:
    '''
    Data-adaptive weight initialisation based on the geometric properties of an
    input batch.

    Motivation
    ----------
    Standard He / Xavier initialisation scales weights by a fixed function of
    layer size.  In low-sample regimes (few dozen examples) this can be
    suboptimal because the true scale of the feature space varies wildly
    between tasks.  GWS instead measures three complementary properties of the
    *actual* input data and uses them as the upper bound for a uniform weight
    sampler:

    - Anisotropy   : directional spread of the input's gradient field.
                     High anisotropy → the data has varied geometry → wider
                     weight range helps the layer respond to diverse directions.
    - Eigenvalue encoding (trC, k) : compact scalar derived from the input's
                     covariance eigenspectrum.  k is the number of principal
                     components that capture 90% of variance; trC is a
                     three-stage cascade that compresses k and anisotropy into
                     a single magnitude.
    - AME          : Abstract Modelling Error — log-product of input magnitude
                     and gradient energy.  Measures raw "learning difficulty".

    Usage
    -----
    Instantiate with the layer's (input_size, output_size), then call
    weight_shaping(X) where X is the training batch.  Returns a float32
    matrix of shape (input_size, output_size) drawn from
    Uniform[0, efficient_distributed_energy].
    '''
    def __init__(self, input_size, output_size):
        self.input_size = input_size
        self.output_size = output_size
        self.floating_context = None

    def eigenvalue_encoder(self, x):
        # Encodes the geometric complexity of the input data into a scalar (trC) and a
        # principal component count (k). The scalar trC is later used as the upper bound
        # for the random floating-point context in abstract_weight_shaping.
        #
        # Step-by-step logic:
        #   1. Augment input with magnitude-scaled structured noise so the covariance
        #      matrix is never degenerate even on very small or homogeneous datasets.
        #   2. Run eigendecomposition on the augmented covariance, sort eigenvalues
        #      descending, then find k = the number of principal components that
        #      capture 90% of cumulative variance.  k is a compact measure of
        #      intrinsic dimensionality.
        #   3. Derive three chained scalars (trA → trB → trC) that compress k and the
        #      data anisotropy into a single weight-shaping magnitude.
        #      - trA  : scales k by directional variation; high anisotropy → large trA
        #      - trB  : dampens trA²; keeps the signal in a bounded range
        #      - trC  : final scalar — NOTE: trB² - 1.0 can equal zero when trB == ±1,
        #               causing division-by-zero (known fragility flagged in code review)
        eps = 1e-5
        raw_X = np.asarray(x)
        if raw_X.ndim > 2:
            raw_X = raw_X.reshape(raw_X.shape[0], -1)

        mag = np.mean(np.linalg.norm(raw_X, axis=-1))

        anisotropy = self.anisotropy_measurement(raw_X)

        # Augment data with noise proportional to its magnitude to avoid a singular
        # covariance matrix when the dataset is small or nearly constant.
        structured_noise = np.random.uniform(0, mag, size=raw_X.shape)
        X = np.vstack((raw_X, structured_noise))
        if X.ndim == 2 and X.shape[1] == 1:
            X = np.hstack((raw_X, structured_noise))  

        cov = np.cov(X, rowvar=False)

        # eigh is used instead of eig because cov is symmetric; it returns real eigenvalues
        # and is numerically more stable than the general eigensolver.
        eigenvalues, eigenvectors = np.linalg.eigh(cov)
        idx = np.argsort(eigenvalues)[::-1]  # sort largest-first

        eigenvalues = eigenvalues[idx]
        # Cumulative explained variance ratio; searchsorted finds the elbow at 90 %.
        energy = np.cumsum(eigenvalues) / np.sum(eigenvalues)
        k = np.searchsorted(energy, 0.90) + 1     # +1 converts 0-based index to count

        # K_G: normalised inverse of k — small k (low-dim data) → K_G near 1,
        #       large k (high-dim data) → K_G near 0.
        K_G = 1.0 / (1.0 + k)
        mag_G = 1.0 / (1.0 + K_G)  # secondary magnitude dampener

        # Three-stage compression cascade that maps (k, anisotropy) → trC scalar.
        trA = k / (1.0 - anisotropy) + eps   # anisotropy close to 1 inflates trA
        trB = (1/2 + mag_G) / (1.0 + trA**2) # quadratic dampener keeps trB < 0.5
        # WARNING: trB² - 1.0 is negative for all typical trB values (|trB| < 1),
        # so trC ends up negative.  When trB == ±1 exactly this divides by zero.
        trC = (1/6 + K_G) / (trB**2 - 1.0)
        if np.isnan(trC) or np.isinf(trC):
            trC = anisotropy * (1.0 - mag_G) + eps

        floating_point = np.random.uniform(0, trC, size=x.shape)

        return k, floating_point, structured_noise


    def spectral_signature(self, x, structured_noise, k=5):
        '''
        Returns the top-k normalised eigenvalues of the input covariance matrix.
        These form a compact "fingerprint" of the dataset's principal variance
        structure.  Used by spectral_similarity to measure how geometrically
        close two arrays are.

        Parameters
        ----------
        x : array-like, shape (n_samples, n_features)
        k : number of leading eigenvalues to return (default 5)

        Returns
        -------
        ndarray of shape (k,) — each value in [0, 1], sums to ≤ 1.
        '''
        raw_X = np.asarray(x)
        if raw_X.ndim > 2:
            X = raw_X.reshape(raw_X.shape[0], -1)
        else:
            X = raw_X.reshape(raw_X.shape[0], -1)
            
        X = np.atleast_2d(X)
        if X.ndim == 2 and X.shape[1] == 1:
            X = np.hstack((X, structured_noise))

        cov = np.cov(X, rowvar=False)
        eigvals = np.linalg.eigvalsh(cov)
        eigvals = np.sort(eigvals)[::-1]
        return eigvals[:k] / (eigvals.sum() + 1e-8)

    def spectral_similarity(self, a, b, structured_noise):
        '''
        Measures how spectrally similar two arrays are by comparing their top-k
        eigenvalue signatures via the L2 norm of their difference, mapped through
        an exponential kernel so the result is in (0, 1].
        Value near 1 → arrays share similar geometric structure.
        Value near 0 → very different spectral profiles.
        Used in abstract_weight_shaping to gauge how much the real data
        "looks like" random noise drawn from the same eigenvalue range.
        '''
        sa = self.spectral_signature(a, structured_noise)
        sb = self.spectral_signature(b, structured_noise)
        return np.exp(-np.linalg.norm(sa - sb))

    # abstract modelling error provides the model how to better process weights when the data complexity has little geometric complexity
    def AME_Encoder(self, x):
        X = np.asarray(x)
        try:
            gradient = np.gradient(x)
        except:
            subnet = x[:min(10, x.shape[0]), :min(10, x.shape[1])]
            gradient = np.gradient(subnet.flatten())

        grad_energy = np.mean(np.linalg.norm(gradient, axis=-1))       
        X_mag = np.mean(np.linalg.norm(X, axis=-1))
        # Regular AME Equations, higher AME provides capabilities for the model to experience errors during abstraction
        # Lower AME means lower chance for un optimal abstraction.
        
        AME =  np.log1p(X_mag) * np.log1p(grad_energy) 
        return AME

    # anisotropy provides the model the standard complexity of the data geometry, allowing it to know how complex the data needs to be processed.
    def anisotropy_measurement(self, x):
        eps = 1e-5
        try:
            gradient = np.gradient(x)
        except:
            subnet = x[:min(10, x.shape[0]), :min(10, x.shape[1])]
            gradient = np.gradient(subnet.flatten())        
     
        val = [np.linalg.norm(v) for v in gradient]
        anisotropy = np.std(val) / np.mean(val) + eps
        return anisotropy

    # weight shaping provides directional context in which how the data should be processed in order to align with the data geometry
    def abstract_weight_shaping(self, x):
        # Derives a data-adaptive random weight matrix whose range is governed by
        # the geometric complexity of the input batch x.
        #
        # Key scalars produced along the way:
        #   anisotropy  — directional spread of gradients across x (higher = more varied)
        #   trC, k      — eigenvalue-derived complexity scalar and intrinsic dimensionality
        #   AME         — Abstract Modelling Error: log-product of magnitude × gradient energy
        #   AEL         — Adaptive Energy Level: blends spectral similarity with anisotropy;
        #                 measures how much the data geometry resembles random noise
        #   AMR         — sigmoid-scaled AME; used as a soft gate between 0 and 1
        #   efficient_distributed_energy — the upper bound fed to the final uniform sampler;
        #                 equals k + AEL*(1 - AMR): dominated by intrinsic dimensionality
        #                 when the model rate (AMR) is high, shifts to AEL when AMR is low.
        #
        # The resulting weight matrix (shape: input_size × output_size) is drawn from
        # Uniform[0, efficient_distributed_energy], which gives the downstream Dense layer
        # a geometry-aware initialisation instead of a fixed scale like He/Xavier.
        input_size = self.input_size
        output_size = self.output_size

        rng = np.random.default_rng()

        anisotropy = self.anisotropy_measurement(x)
        mag = np.mean(np.linalg.norm(x))

        k, floating_point, structured_noise = self.eigenvalue_encoder(x)
        AME = self.AME_Encoder(x)
        AMR = 1.0 / (1.0 + np.exp(-AME))  # abstract modelling rate — sigmoid gate on AME

        # floating_point: noise draw bounded by trC; used only to compute spectral
        # similarity (how much the real data "looks like" noise geometrically).
        spectral_similarity = self.spectral_similarity(x, floating_point, structured_noise)

        # AEL rises when data is both spectrally noise-like and highly anisotropic.
        AEL = 0.3 + spectral_similarity * anisotropy       
        scaled_anisotropy = anisotropy / (anisotropy + 1.0)  # unused below; kept for potential future use

        # Upper bound of the weight distribution.
        # When data complexity is low (AMR → 1), the AEL term vanishes → bound ≈ k.
        # When data is geometrically rich (AMR → 0), AEL contributes more → wider init.
        efficient_distributed_energy = k + AEL * (1.0 - AMR)
        if np.isnan(efficient_distributed_energy) or np.isinf(efficient_distributed_energy):
            efficient_distributed_energy = (1 - AMR) + eps

        floating_context = rng.uniform(0, efficient_distributed_energy, size=(input_size, output_size)) 
        self.floating_context = floating_context

        return floating_context

    def weight_shaping(self, x, type=None):
        '''
        Public entry-point for GWS.  Validates the input array (converts lists,
        flattens >2-D tensors, replaces constant inputs with uniform noise to
        avoid zero-variance covariance) and then delegates to
        abstract_weight_shaping().

        Falls back to a ones matrix if abstract_weight_shaping produces NaN or
        non-finite values (e.g. due to the known trC division-by-zero edge case).

        Parameters
        ----------
        x    : array-like — the training batch for the layer being initialised.
        type : unused placeholder for future type-specific shaping strategies.

        Returns
        -------
        ndarray of shape (input_size, output_size) — geometry-scaled weights.
        '''
        if isinstance(x, list):
            x = np.asarray(x)

        if x.ndim > 2:
            x = x.reshape(x.shape[0], -1)

        if np.std(x) == 0:
            x = np.random.uniform(0, 1, size=x.shape)

        floating_context = self.abstract_weight_shaping(x)
        if np.isnan(floating_context).any() or not np.isfinite(floating_context).any():
            floating_context = np.ones_like(x)

        return floating_context



class Activation:
    '''
    Stateless collection of activation functions and their derivatives.
    All methods are @staticmethod so no instance is needed.

    Functions provided
    ------------------
    relu / relu_derivative     : Standard rectified linear unit.
    sigmoid / sigmoid_derivative : Logistic sigmoid; derivative re-uses
                                   the forward pass value for efficiency.
    softmax                    : Numerically stable (max-subtraction) softmax.
                                 Handles both 1-D vectors and 2-D batches.
    '''
    @staticmethod
    def relu(x):
        return np.maximum(0, x)

    @staticmethod
    def relu_derivative(x):
        return (x > 0).astype(float)

    @staticmethod
    def sigmoid(x):
        eps = 1e-5
        return 1 / (1 + np.exp(-x))

    @staticmethod
    def sigmoid_derivative(x):
        eps = 1e-5
        s = Activation.sigmoid(x)
        return s * (1.0 - s)

    @staticmethod
    def softmax(x):
        # numerical stability
        if x.ndim > 1:
            exp_x = np.exp(x - np.max(x, axis=1, keepdims=True))
            return exp_x / np.sum(exp_x, axis=1, keepdims=True)
        else:
            exp_x = np.exp(x - np.max(x, keepdims=True))
            return exp_x / np.sum(exp_x, keepdims=True) 

class Loss:
    '''
    Stateless loss functions for multi-class classification.

    categorical_crossentropy
        Standard cross-entropy over one-hot targets.  Clips predictions to
        [eps, 1-eps] to avoid log(0).  Falls back to a slice of the smaller
        axis when y_true and y_pred have mismatched class counts (can occur
        during hybrid-feature training when the MLP and Transformer have
        different output dimensions).

    softmax_crossentropy_derivative
        Analytic gradient of softmax + cross-entropy combined:
        dL/dlogits = (softmax(logits) - y_true) / batch_size.
        Using this combined form is numerically more stable than computing the
        two gradients separately.
    '''
    @staticmethod
    def categorical_crossentropy(y_true, y_pred):
        eps = 1e-9
        y_pred = np.clip(y_pred, eps, 1 - eps)
        try:
            loss = -np.mean(np.sum(y_true * np.log(y_pred), axis=1))
        except:
            subnet_y_pred = y_pred[:, :y_true.shape[1]]
            subnet_y_true = y_true[:, :subnet_y_pred.shape[1]]

            loss = -np.mean(np.sum(subnet_y_true * np.log(subnet_y_pred + eps), axis=1))
        
        return loss

    @staticmethod
    def softmax_crossentropy_derivative(y_true, y_pred):
        try:
            cross_ent = (y_pred - y_true) / y_true.shape[0]
        except:
            subnet_y_pred = y_pred[:, :y_true.shape[1]]
            subnet_y_true = y_true[:, :subnet_y_pred.shape[1]]

            cross_ent = (subnet_y_pred - subnet_y_true) / subnet_y_true.shape[0]
        return cross_ent


class Transformer:
    """
    A single-block Transformer classifier designed for low-sample environments.
 
    Key design philosophy:
    - Dynamic alpha gating: blends fixed (stable) and learned (flexible) attention
      projections based on data complexity, measured by AME (Abstract Modelling Energy).
      Early in training alpha ~ 0, so attention stays fixed and gradients are stable.
      As training progresses alpha → 1, allowing full dynamic attention.
    - GWS (Geometric Weight Shaping): initializes W_o using data geometry rather than
      random noise, giving the output projection a head start aligned with the input
      distribution's geometric complexity.
    - All improvements (gradient clipping, lr scheduling, padding masks, alpha-aware
      dropout, weight decay, label smoothing) are coordinated around the alpha warmup
      so they don't fight each other during early training.
    """
 
    def __init__(self, vocab_size, d_model=8, n_heads=2, num_classes=7,
                 learning_rate=0.01, attn_dropout=0.0, ffn_dropout=0.0, weight_decay=1e-4):
        """
        Args:
            vocab_size:     Number of unique tokens in the vocabulary.
            d_model:        Embedding dimension. Keep small (8-32) for low-sample data
                            to avoid overparameterization.
            n_heads:        Number of attention heads. d_model must be divisible by n_heads.
            num_classes:    Number of output classes for classification.
            learning_rate:  Base learning rate — actual lr is scheduled via get_lr().
            attn_dropout:   Dropout rate on attention output. Scaled by alpha at runtime,
                            so effective rate = attn_dropout * alpha.
            ffn_dropout:    Dropout rate on FFN activations (after ReLU). Also alpha-scaled.
            weight_decay:   L2 regularization coefficient applied at each weight update.
                            Does NOT apply to biases, embeddings, or layer norm params.
        """
        self.d_model = d_model
        self.n_heads = n_heads
        self.attn_dropout_rate = attn_dropout
        self.ffn_dropout_rate  = ffn_dropout
        self.transformer_lr    = learning_rate
        self.weight_decay      = weight_decay
 
        # Token embedding table: maps token ids → d_model vectors
        # Small init scale (0.02) prevents large logits at start
        self.token_embedding = np.random.randn(vocab_size, d_model) * 0.02
 
        # Positional embeddings: adds word-order signal to token embeddings
        # Supports sequences up to length 100
        self.pos_embedding = np.random.randn(100, d_model) * 0.02
 
        # Multi-head attention projections: shape (n_heads, d_model, d_model // n_heads)
        # Each head gets its own Q/K/V slice of dimension d_model // n_heads
        self.W_q = np.random.randn(n_heads, d_model, d_model // n_heads) * 0.02
        self.W_k = np.random.randn(n_heads, d_model, d_model // n_heads) * 0.02
        self.W_v = np.random.randn(n_heads, d_model, d_model // n_heads) * 0.02
 
        # Fixed copies of QKV projections — used for alpha blending.
        # When alpha=0: W_q_mix = W_q_fixed (no updates flow to QKV).
        # When alpha=1: W_q_mix = W_q (fully dynamic).
        # This gives stability in early training without permanently sacrificing flexibility.
        self.W_q_fixed = self.W_q.copy()
        self.W_k_fixed = self.W_k.copy()
        self.W_v_fixed = self.W_v.copy()
 
        # Output projection: concatenated head outputs → d_model
        # This is the only weight initialized by GWS — geometric init only helps
        # in fixed output projections, not in the QKV matrices.
        self.W_o = np.random.randn(d_model, d_model) * 0.02
 
        # Flag to ensure GWS shaping only runs once at the start of train()
        self.encoded = False
 
        # Feed-forward network: two-layer MLP with ReLU, hidden dim = d_model * 4
        # FFN provides non-linear transformation after attention
        self.ffn1 = np.random.randn(d_model, d_model * 4) * 0.02
        self.ffn2 = np.random.randn(d_model * 4, d_model) * 0.02
 
        # Layer norm parameters: scale (gamma) and shift (beta)
        # ln1 normalizes after attention + residual
        # ln2 normalizes after FFN + residual
        self.ln1_scale = np.ones(d_model)
        self.ln1_shift = np.zeros(d_model)
        self.ln2_scale = np.ones(d_model)
        self.ln2_shift = np.zeros(d_model)
 
        # Classification head: pooled d_model vector → num_classes logits
        self.output      = np.random.randn(d_model, num_classes) * 0.02
        self.output_bias = np.zeros(num_classes)
 
        # Intermediate activations stored here during forward pass for use in backward
        self.cache = {}
 
 
    # ─────────────────────────────────────────────
    # Core math utilities
    # ─────────────────────────────────────────────
 
    def layer_norm(self, x, scale, shift):
        """
        Layer normalization: normalizes across the last dimension (d_model).
        Stabilizes training by keeping activations at unit variance.
        eps=1e-5 prevents division by zero on zero-variance inputs.
        """
        mean = np.mean(x, axis=-1, keepdims=True)
        var  = np.var(x,  axis=-1, keepdims=True)
        return scale * (x - mean) / np.sqrt(var + 1e-5) + shift
 
 
    def apply_update(self, param, grad, lr):
        """
        L2 weight decay update: param -= lr * (grad + decay * param)
        Equivalent to adding decay * param to the gradient before stepping.
        Shrinks weights toward zero each step, discouraging large weights.
        NOTE: never call this on biases, embeddings, or layer norm params.
        """
        return param - lr * (grad + self.weight_decay * param)
 
 
    def dropout(self, x, rate=0.1, training=True, alpha=None):
        """
        Inverted dropout with alpha-aware effective rate.
 
        Standard dropout randomly zeros activations during training.
        Inverted scaling (divide by 1-rate) means no scaling is needed at inference.
 
        Alpha scaling: effective_rate = rate * alpha
        - When alpha ~ 0 (early training, fixed attention): near-zero dropout
          → clean gradients when the model is most fragile
        - When alpha ~ 1 (late training, dynamic attention): full dropout rate
          → regularization kicks in when the model has enough capacity to benefit
 
        Returns (dropped_x, mask) during training, (x, None) at inference.
        """
        if not training or rate == 0.0:
            return x, None
 
        effective_rate = rate * alpha if alpha is not None else rate
 
        if effective_rate == 0.0:
            return x, None
 
        mask = (np.random.rand(*x.shape) > effective_rate).astype(np.float32)
        return x * mask / (1.0 - effective_rate), mask
 
 
    def softmax(self, x):
        """
        Numerically stable softmax: subtracts max before exp to prevent overflow.
        Works on any ndim — keepdims ensures correct broadcasting.
        """
        shifted = x - np.max(x, axis=-1, keepdims=True)
        exp_x   = np.exp(shifted)
        return exp_x / np.sum(exp_x, axis=-1, keepdims=True)
 
 
    # ─────────────────────────────────────────────
    # Attention
    # ─────────────────────────────────────────────
 
    def attention(self, Q, K, V, mask=None):
        """
        Scaled dot-product attention.
 
        scores = QK^T / sqrt(d_k)  — scaling prevents softmax saturation
                                      in high-dimensional spaces
        mask:  (B, 1, 1, T) padding mask — positions where mask==0 get -1e9
               so they become ~0 after softmax (padding tokens ignored)
        clip:  scores clipped to [-50, 50] for numerical stability before softmax
 
        Returns attention output (B, heads, T, d_k) and weights (B, heads, T, T).
        """
        d_k    = Q.shape[-1]
        scores = np.matmul(Q, K.transpose(0, 1, 3, 2)) / np.sqrt(d_k)
        scores = np.clip(scores, -50, 50)
 
        if mask is not None:
            scores = np.where(mask == 0, -1e9, scores)
 
        weights = self.softmax(scores)
        output  = np.matmul(weights, V)
        return output, weights
 
 
    def multi_head_attention(self, x, mask=None, alpha=None):
        """
        Multi-head attention with dynamic alpha blending.
 
        Alpha blending: W_mix = (1 - alpha) * W_fixed + alpha * W_learned
        - alpha=0: uses frozen initial projections → stable, no QKV gradient flow
        - alpha=1: uses fully learned projections → maximum flexibility
        - intermediate: smooth interpolation between the two
 
        Heads allow the model to attend to different representation subspaces
        simultaneously. Each head operates on a d_model // n_heads slice.
 
        Flow: x → Q,K,V projections → scaled dot-product attention
              → concatenate heads → W_o projection → output
        """
        batch_size, seq_len, d_model = x.shape
 
        # Blend fixed and learned projections based on current alpha
        W_q_mix = (1 - alpha) * self.W_q_fixed + alpha * self.W_q
        W_k_mix = (1 - alpha) * self.W_k_fixed + alpha * self.W_k
        W_v_mix = (1 - alpha) * self.W_v_fixed + alpha * self.W_v
 
        # Project input to Q, K, V for all heads simultaneously via einsum
        # 'bsd,hdm->bhsm': batch, seq, d_model × heads, d_model, head_dim
        Q = np.einsum('bsd,hdm->bhsm', x, W_q_mix)
        K = np.einsum('bsd,hdm->bhsm', x, W_k_mix)
        V = np.einsum('bsd,hdm->bhsm', x, W_v_mix)
 
        # Cache Q, K, V for backward pass gradient computation
        self.cache['Q'] = Q
        self.cache['K'] = K
        self.cache['V'] = V
        self.cache['x_attn_input'] = x
 
        attn_output, attn_weights = self.attention(Q, K, V, mask)
        self.cache['attn_weights'] = attn_weights
        self.cache['attn_output']  = attn_output
 
        # Merge heads: (B, heads, T, head_dim) → (B, T, d_model)
        attn_output = attn_output.transpose(0, 2, 1, 3).reshape(batch_size, seq_len, -1)
        self.cache['attn_concat'] = attn_output
 
        # Final linear projection mixes information across heads
        output = np.matmul(attn_output, self.W_o)
        self.cache['attn_out'] = output
 
        return output, attn_weights
 
 
    # ─────────────────────────────────────────────
    # Forward pass
    # ─────────────────────────────────────────────
 
    def forward(self, input_ids, embedded=False, pad_token_id=0,
                training=True, attn_dropout=0.1, ffn_dropout=0.1):
        """
        Full forward pass: tokens → probabilities.
 
        Two input modes:
        - embedded=False (default): input_ids are integer token indices (B, T)
          → looked up in token_embedding, positional embedding added
        - embedded=True: input_ids are already float embeddings (B, T, D)
          → skip embedding lookup, no padding mask available
 
        Alpha computation:
        1. AME_Encoder measures input complexity → raw alpha signal
        2. Sigmoid maps to (0, 1)
        3. After attention, EMA blends with attention_quality_computing score:
           alpha = 0.95 * alpha + 0.05 * quality_score
           This makes alpha track both input complexity AND attention quality.
 
        Masked mean pooling:
        - Averages only over valid (non-padding) token positions
        - Prevents padding zeros from diluting the pooled representation
        - Backward pass must use the same mask and lengths for correct gradients
        """
        if embedded:
            x = np.asarray(input_ids, dtype=np.float32)
            if x.ndim == 2:
                x = x[np.newaxis, ...]
            batch_size, seq_len, _ = x.shape
            self.cache['embedded_input'] = x
            self.cache['input_ids']      = None
            mask = None
        else:
            input_ids = np.asarray(input_ids, dtype=np.int32)  # guard against float input
            if input_ids.ndim == 1:
                input_ids = input_ids[np.newaxis, :]
 
            x         = self.token_embedding[input_ids]          # (B, T, D)
            x         = x + self.pos_embedding[:x.shape[1]]      # add positional signal
            batch_size, seq_len = input_ids.shape
            self.cache['embedded_input'] = None
            self.cache['input_ids']      = input_ids
            mask = self.padding_mask_utility(input_ids, pad_token_id)  # (B, 1, 1, T)
 
        self.cache['mask']       = mask if not embedded else None
        self.cache['seq_len']    = seq_len
        self.cache['batch_size'] = batch_size
        self.cache['x_token']    = x
        self.cache['x_pos']      = x
 
        # Compute alpha from input complexity before attention
        # AME measures gradient energy × magnitude — proxy for data complexity
        AME   = self.AME_Encoder(x)
        alpha = 1.0 / (1.0 + np.exp(-AME))  # sigmoid → (0, 1)
 
        attn_out, attn_weights = self.multi_head_attention(x, mask=mask, alpha=alpha)
 
        # Apply alpha-scaled dropout to attention output
        # current_alpha from cache (may differ from freshly computed alpha above
        # during the first step when cache is empty)
        current_alpha = self.cache.get('alpha', 0.0)
        attn_out, attn_drop_mask = self.dropout(
            attn_out, rate=self.attn_dropout_rate,
            training=training, alpha=current_alpha
        )
        self.cache['attn_drop_mask'] = attn_drop_mask
 
        # Refine alpha with attention quality signal (EMA update)
        # quality_computing returns a scalar in (0,1) based on attention entropy,
        # max attention, and anisotropy — higher = more structured attention
        alpha = 0.95 * alpha + 0.05 * self.attention_quality_computing(attn_weights, mask=mask)
        self.alpha        = alpha
        self.cache['alpha'] = alpha
 
        # Attention sub-layer: residual connection + layer norm
        self.cache['x_ln1_input'] = x + attn_out
        x = self.layer_norm(x + attn_out, self.ln1_scale, self.ln1_shift)
        self.cache['x_after_ln1'] = x
 
        # FFN sub-layer: two linear layers with ReLU activation
        self.cache['ffn_input'] = x
        ffn_pre  = np.matmul(x, self.ffn1)
        self.cache['ffn_pre'] = ffn_pre
 
        ffn_act = np.maximum(0, ffn_pre)   # ReLU: zero out negative pre-activations
 
        # Apply alpha-scaled dropout to FFN activations (after ReLU, before ffn2)
        ffn_act, ffn_drop_mask = self.dropout(
            ffn_act, rate=self.ffn_dropout_rate,
            training=training, alpha=current_alpha
        )
        self.cache['ffn_act']      = ffn_act
        self.cache['ffn_drop_mask'] = ffn_drop_mask
 
        ffn_out = np.matmul(ffn_act, self.ffn2)
        self.cache['ffn_out'] = ffn_out
 
        # FFN sub-layer: residual connection + layer norm
        self.cache['x_ln2_input'] = x + ffn_out
        x = self.layer_norm(x + ffn_out, self.ln2_scale, self.ln2_shift)
        self.cache['x_after_ln2'] = x
 
        # Masked mean pooling: average across valid token positions only
        # Padding positions (mask=0) are zeroed out before summing
        if mask is not None:
            token_mask = mask[:, 0, 0, :, np.newaxis]              # (B, T, 1)
            x_masked   = x * token_mask                            # zero padding
            lengths    = token_mask.sum(axis=1)                    # (B, 1) valid counts
            x_pooled   = x_masked.sum(axis=1) / (lengths + 1e-6)  # (B, D)
        else:
            x_pooled = np.mean(x, axis=1)                         # (B, D)
 
        self.cache['x_pooled'] = x_pooled
 
        # Classification head: pooled vector → class logits → probabilities
        logits = np.matmul(x_pooled, self.output) + self.output_bias
        self.cache['logits'] = logits
 
        probs = self.softmax(logits)
        self.cache['probs'] = probs
 
        return probs, attn_weights
 
 
    # ─────────────────────────────────────────────
    # Backward passes
    # ─────────────────────────────────────────────
 
    def layer_norm_backward(self, d_out, x, scale, shift):
        """
        Analytic backward through layer normalization.
 
        Computes dx given upstream gradient d_out and the original pre-norm input x.
        Three gradient terms:
        1. dx_hat / std          — direct path through normalization
        2. dvar * 2(x-mean)/N   — path through variance
        3. dmean / N             — path through mean
 
        Note: the dvar * mean(-2*(x-mean)) term found in some implementations
        is always zero (mean of deviations from the mean = 0) and is omitted here.
        """
        eps  = 1e-5
        mean = np.mean(x, axis=-1, keepdims=True)
        var  = np.var(x,  axis=-1, keepdims=True)
        std  = np.sqrt(var + eps)
        N    = x.shape[-1]
 
        dx_hat = d_out * scale
        dvar   = np.sum(dx_hat * (x - mean) * -0.5 * std**-3, axis=-1, keepdims=True)
        dmean  = np.sum(dx_hat * (-1.0 / std), axis=-1, keepdims=True)
 
        dx = dx_hat / std + dvar * 2 * (x - mean) / N + dmean / N
        return dx
 
 
    def fixed_attention_backward(self, d_logits, lr=0.01, max_norm=1.0):
        """
        Backward pass that does NOT update Q, K, V projections.
 
        Used when mode='fixed_backward'. Gradients stop at W_o — the QKV
        projections remain frozen at their initial values. This sacrifices
        flexibility for maximum stability, useful when data is very scarce
        or when you want the attention pattern to stay fixed while only
        the FFN and output head adapt.
 
        Gradient flow (top to bottom):
        logits → output head → pooling → layer_norm_2 → FFN → layer_norm_1
        → attention output (W_o only, no further)
        """
        d_output = d_logits
 
        # Output head gradients
        d_Wo     = np.dot(self.cache['x_pooled'].T, d_output)
        d_bo     = np.sum(d_output, axis=0, keepdims=True)
        d_pooled = np.dot(d_output, self.output.T)
 
        # Expand pooled gradient back to all token positions uniformly
        d_x = np.repeat(
            d_pooled[:, np.newaxis, :] / self.cache['seq_len'],
            self.cache['seq_len'], axis=1
        )
 
        # Layer norm 2 backward
        d_x = self.layer_norm_backward(d_x, self.cache['x_ln2_input'],
                                        self.ln2_scale, self.ln2_shift)
 
        # FFN backward
        d_ffn  = d_x
        d_ffn2 = np.sum(np.matmul(self.cache['ffn_act'].transpose(0, 2, 1), d_ffn), axis=0)
 
        d_ffn_act = np.matmul(d_ffn, self.ffn2.T)
 
        # FFN dropout backward: re-apply the same mask used in forward,
        # then rescale by 1/(1-rate) to undo the inverted scaling
        ffn_drop_mask = self.cache.get('ffn_drop_mask')
        if ffn_drop_mask is not None:
            d_ffn_act = d_ffn_act * ffn_drop_mask / (1.0 - self.ffn_dropout_rate)
 
        # ReLU backward: zero gradient where pre-activation was negative
        d_ffn_pre = d_ffn_act * (self.cache['ffn_pre'] >= 0)
 
        d_prev = np.matmul(d_ffn_pre, self.ffn1.T)
        d_ffn1 = np.sum(np.matmul(self.cache['ffn_input'].transpose(0, 2, 1), d_ffn_pre), axis=0)
 
        # Layer norm 1 backward
        # Note: subtracts attn_out because d_x currently includes the FFN residual path
        d_x = self.layer_norm_backward(
            d_x - self.cache['attn_out'],
            self.cache['x_ln1_input'],
            self.ln1_scale, self.ln1_shift
        )
 
        d_ffn          = d_x
        d_residual_ffn = d_ffn
        dx             = d_prev + d_residual_ffn
        d_attn         = dx
 
        # Attention dropout backward
        attn_drop_mask = self.cache.get('attn_drop_mask')
        if attn_drop_mask is not None:
            d_attn = d_attn * attn_drop_mask / (1.0 - self.attn_dropout_rate)
 
        # W_o gradient only — gradient stops here (no QKV updates)
        d_Wo_attn = np.sum(
            np.matmul(self.cache['attn_concat'].transpose(0, 2, 1), d_attn), axis=0
        )
 
        # Collect, clip, then apply updates with weight decay
        grads = {
            'output': d_Wo,
            'ffn2':   d_ffn2,
            'ffn1':   d_ffn1,
            'W_o':    d_Wo_attn,
        }
        grads, norm = self.clip_gradients(grads, max_norm)
 
        self.output = self.apply_update(self.output, grads['output'], lr)
        self.output_bias -= lr * d_bo.squeeze()   # bias: no weight decay
        self.ffn2   = self.apply_update(self.ffn2, grads['ffn2'], lr)
        self.ffn1   = self.apply_update(self.ffn1, grads['ffn1'], lr)
        self.W_o    = self.apply_update(self.W_o,  grads['W_o'],  lr)
 
        return d_x
 
 
    def dynamic_backward(self, d_logits, lr=0.01, max_norm=1.0):
        """
        Full backward pass including Q, K, V projection updates.
 
        Used when mode='dynamic_backward' (default). QKV gradients are
        alpha-scaled before clipping — when alpha is low, QKV updates are
        small, preserving stability during early training.
 
        Token embedding updates use np.add.at (scatter-add) rather than
        fancy indexing to correctly accumulate gradients for repeated tokens.
        Embeddings and positional embeddings are clipped separately from the
        main gradient dict because they are variable-shape scatter updates.
 
        Gradient flow (top to bottom):
        logits → output head → masked pooling → layer_norm_2 → FFN
        → layer_norm_1 → W_o → attention heads → Q, K, V projections
        → token embeddings + positional embeddings
        """
        d_output = d_logits
        alpha    = self.cache.get('alpha', 1.0)
 
        # Output head gradients
        d_Wo     = np.dot(self.cache['x_pooled'].T, d_output)
        d_bo     = np.sum(d_output, axis=0)
        d_pooled = np.dot(d_output, self.output.T)
 
        # Masked pooling backward: gradient flows only to valid (non-padding) positions
        # Divides by per-sequence valid token count, matching the forward mean
        mask = self.cache['mask']
        if mask is not None:
            token_mask = mask[:, 0, 0, :, np.newaxis]              # (B, T, 1)
            lengths    = token_mask.sum(axis=1, keepdims=True)     # (B, 1, 1)
            d_x        = (d_pooled[:, np.newaxis, :] / (lengths + 1e-6)) * token_mask
        else:
            d_x = np.repeat(
                d_pooled[:, np.newaxis, :] / self.cache['seq_len'],
                self.cache['seq_len'], axis=1
            )
 
        # Layer norm 2 backward
        d_x = self.layer_norm_backward(d_x, self.cache['x_ln2_input'],
                                        self.ln2_scale, self.ln2_shift)
 
        # FFN backward
        d_ffn  = d_x
        d_ffn2 = np.sum(np.matmul(self.cache['ffn_act'].transpose(0, 2, 1), d_ffn), axis=0)
 
        d_ffn_act = np.matmul(d_ffn, self.ffn2.T)
 
        # FFN dropout backward
        ffn_drop_mask = self.cache.get('ffn_drop_mask')
        if ffn_drop_mask is not None:
            d_ffn_act = d_ffn_act * ffn_drop_mask / (1.0 - self.ffn_dropout_rate)
 
        # ReLU backward
        d_ffn_pre = d_ffn_act * (self.cache['ffn_pre'] >= 0)
 
        d_prev = np.matmul(d_ffn_pre, self.ffn1.T)
        d_ffn1 = np.sum(np.matmul(self.cache['ffn_input'].transpose(0, 2, 1), d_ffn_pre), axis=0)
 
        # Layer norm 1 backward
        d_ln1     = self.layer_norm_backward(d_x, self.cache['x_ln1_input'],
                                              self.ln1_scale, self.ln1_shift)
        d_residual = d_ln1
        d_attn     = d_ln1
        dx         = d_prev + d_residual
 
        # Attention dropout backward
        attn_drop_mask = self.cache.get('attn_drop_mask')
        if attn_drop_mask is not None:
            d_attn = d_attn * attn_drop_mask / (1.0 - self.attn_dropout_rate)
 
        # W_o gradient
        d_Wo_attn     = np.sum(
            np.matmul(self.cache['attn_concat'].transpose(0, 2, 1), d_attn), axis=0
        )
 
        # Attention backward: split concatenated head gradient back into per-head tensors
        d_attn_concat = np.matmul(d_attn, self.W_o.T)
        batch, seq_len, _ = d_attn_concat.shape
        d_head = self.n_heads
        d_dim  = self.d_model // self.n_heads
 
        # Reshape (B, T, D) → (B, heads, T, head_dim) to match Q/K/V layout
        d_attn_heads = d_attn_concat.reshape(batch, seq_len, d_head, d_dim).transpose(0, 2, 1, 3)
 
        V      = self.cache['V']
        K      = self.cache['K']
        Q      = self.cache['Q']
        weight = self.cache['attn_weights']
 
        # Gradient through softmax attention weights
        d_V       = np.matmul(weight.transpose(0, 1, 3, 2), d_attn_heads)
        d_weights = np.matmul(d_attn_heads, V.transpose(0, 1, 3, 2))
 
        # Softmax backward: d_scores = weights * (d_weights - sum(d_weights * weights))
        d_scores  = weight * (d_weights - np.sum(d_weights * weight, axis=-1, keepdims=True))
        d_scores /= np.sqrt(Q.shape[-1])  # undo the sqrt(d_k) scaling
 
        d_Q = np.matmul(d_scores, K)
        d_K = np.matmul(d_scores.transpose(0, 1, 3, 2), Q)
 
        x = self.cache['x_attn_input']
 
        # QKV projection gradients via einsum (inverse of forward einsum)
        d_W_q = np.einsum('bsd,bhsm->hdm', x, d_Q)
        d_W_k = np.einsum('bsd,bhsm->hdm', x, d_K)
        d_W_v = np.einsum('bsd,bhsm->hdm', x, d_V)
 
        # Input gradients from Q, K, V paths (sum all three contributions)
        d_x_q = np.einsum('bhsm,hdm->bsd', d_Q, self.W_q)
        d_x_k = np.einsum('bhsm,hdm->bsd', d_K, self.W_k)
        d_x_v = np.einsum('bhsm,hdm->bsd', d_V, self.W_v)
 
        d_x_attn_input = d_x_q + d_x_k + d_x_v
        d_x_total      = d_x_attn_input + d_residual
 
        # Collect main weight gradients, alpha-scale QKV, clip globally
        grads = {
            'output': d_Wo,
            'ffn2':   d_ffn2,
            'ffn1':   d_ffn1,
            'W_o':    d_Wo_attn,
            'W_q':    alpha * d_W_q,   # alpha-scaled: small updates when attention is mostly fixed
            'W_k':    alpha * d_W_k,
            'W_v':    alpha * d_W_v,
        }
        grads, norm = self.clip_gradients(grads, max_norm)
 
        self.output = self.apply_update(self.output, grads['output'], lr)
        self.output_bias -= lr * d_bo.squeeze()   # bias: no weight decay
        self.ffn2   = self.apply_update(self.ffn2, grads['ffn2'], lr)
        self.ffn1   = self.apply_update(self.ffn1, grads['ffn1'], lr)
        self.W_o    = self.apply_update(self.W_o,  grads['W_o'],  lr)
        self.W_q    = self.apply_update(self.W_q,  grads['W_q'],  lr)
        self.W_k    = self.apply_update(self.W_k,  grads['W_k'],  lr)
        self.W_v    = self.apply_update(self.W_v,  grads['W_v'],  lr)
 
        input_ids = self.cache.get('input_ids')
 
        if input_ids is not None:
            # Embedding and positional embedding updates clipped separately
            # (variable shape, scatter update — can't go in the main grads dict)
            emb_norm  = np.linalg.norm(d_x_total)
            emb_coef  = min(1.0, max_norm / (emb_norm + 1e-6))
 
            flat_ids   = input_ids.flatten()                              # (B*T,)
            flat_grads = d_x_total.reshape(-1, self.d_model) / self.cache['seq_len']  # (B*T, D)
 
            # np.add.at correctly accumulates gradients for repeated token ids
            # (fancy indexing would silently drop duplicates)
            np.add.at(self.token_embedding, flat_ids, -lr * emb_coef * flat_grads)
            self.pos_embedding[:seq_len] -= lr * emb_coef * d_x_total.mean(axis=0)
        else:
            self.pos_embedding[:seq_len] -= lr * d_x_total.mean(axis=0)
            norm = d_x_total
 
        return norm
 
 
    # ─────────────────────────────────────────────
    # Training utilities
    # ─────────────────────────────────────────────
 
    def smoothing_labels_utility(self, y_true, smoothing=0.1):
        """
        Label smoothing: softens one-hot targets to prevent overconfidence.
 
        Hard target: [0, 0, 1, 0, 0, 0, 0]
        Smoothed:    [0.014, 0.014, 0.914, 0.014, 0.014, 0.014, 0.014]
 
        Formula: y_smooth = y * (1 - smoothing) + smoothing / num_classes
        The model is penalized less for wrong classes and less rewarded for
        being maximally confident on the correct class. Helps generalization
        especially on small datasets where the model tends to overfit hard labels.
        """
        num_classes = y_true.shape[1]
        return y_true * (1.0 - smoothing) + smoothing / num_classes
 
 
    def learning_rate_warm_up(self, epoch, epochs, lr_base,
                               schedule='cosine_warmup', warmup_frac=0.1):
        """
        Learning rate scheduling with optional linear warmup.
 
        cosine_warmup (recommended):
        - Linear warmup for first warmup_frac * epochs epochs
        - Cosine decay from peak back toward 0 for the remainder
        - Coordinates naturally with alpha warmup: low lr while alpha is low,
          peak lr as alpha reaches ~0.1-0.3, then both decay together
 
        step:
        - Halves lr every 30% of training — simpler, less smooth
 
        constant:
        - No scheduling — useful for debugging or very short runs
        """
        warmup_epochs = int(epochs * warmup_frac)
 
        if schedule == 'cosine_warmup':
            if epoch < warmup_epochs:
                return lr_base * (epoch + 1) / warmup_epochs
            else:
                progress = (epoch - warmup_epochs) / (epochs - warmup_epochs)
                return lr_base * 0.5 * (1 + np.cos(np.pi * progress))
 
        elif schedule == 'step':
            step = int(epochs * 0.3)
            return lr_base * (0.5 ** (epoch // step))
 
        elif schedule == 'constant':
            return lr_base
 
        return lr_base
 
 
    def padding_mask_utility(self, input_ids, pad_token_id=0):
        """
        Creates a broadcast-ready padding mask from token ids.
 
        Positions where input_ids == pad_token_id are marked 0 (ignore),
        all other positions are marked 1 (attend).
 
        Output shape (B, 1, 1, T) broadcasts correctly against attention
        scores of shape (B, heads, T_query, T_key) — the 1s expand automatically
        across the heads and query dimensions without copying memory.
        """
        mask = (input_ids != pad_token_id).astype(np.float32)
        return mask[:, np.newaxis, np.newaxis, :]   # (B, 1, 1, T)
 
 
    def clip_gradients(self, grads: dict, max_norm: float = 1.0):
        """
        Global gradient norm clipping.
 
        Computes the L2 norm across ALL gradients in the dict combined,
        then scales all gradients down proportionally if the norm exceeds max_norm.
        Only scales DOWN — never amplifies small gradients.
 
        Global (not per-parameter) clipping is important here because
        alpha-scaled QKV gradients are already small; per-parameter clipping
        would amplify them relative to the FFN gradients.
 
        Returns (clipped_grads, total_norm) — monitor total_norm in training
        logs to detect gradient explosions or overly aggressive clipping.
        """
        total_norm = np.sqrt(sum(np.sum(g ** 2) for g in grads.values()))
        clip_coef  = max_norm / (total_norm + 1e-6)
 
        if clip_coef < 1.0:
            grads = {k: g * clip_coef for k, g in grads.items()}
 
        return grads, total_norm
 
 
    def batch_padding_utility(self, sequences, pad_token_id=0):
        """
        Pads a list of variable-length token sequences to the same length.
 
        Finds the longest sequence in the batch, then right-pads all shorter
        sequences with pad_token_id. The padding mask in forward() will
        ensure these positions are ignored during attention and pooling.
 
        Args:
            sequences:    list of 1-D int arrays of varying lengths
            pad_token_id: token id used for padding (default 0)
        Returns:
            padded array of shape (B, max_len) dtype int32
        """
        max_len = max(len(s) for s in sequences)
        padded  = np.full((len(sequences), max_len), pad_token_id, dtype=np.int32)
        for i, s in enumerate(sequences):
            padded[i, :len(s)] = s
        return padded   # (B, T)
 
 
    def train_step(self, input_ids, epoch, y_true, lr=0.01, mode=None,
                   embedded=False, max_norm=1.0, pad_token_id=0):
        """
        Single training step: forward → loss → backward → weight update.
 
        Label smoothing is applied to y_true before loss computation,
        but accuracy is measured against the original hard labels so the
        metric remains interpretable throughout training.
 
        mode='fixed_backward': only FFN, W_o, and output head update
        mode=None (default):   full dynamic_backward including QKV and embeddings
        """
        if not embedded and input_ids.ndim == 1:
            input_ids = input_ids[np.newaxis, :]
        if y_true.ndim == 1:
            y_true = y_true[np.newaxis, :]
 
        probs, attn_weights = self.forward(
            input_ids, embedded=embedded, pad_token_id=pad_token_id,
            training=True, attn_dropout=self.attn_dropout_rate,
            ffn_dropout=self.ffn_dropout_rate
        )
 
        # Smooth labels for loss and gradient computation
        y_true_smooth = self.smoothing_labels_utility(y_true, smoothing=0.1)
 
        # Shape alignment guard (handles edge cases in multi-class setups)
        if y_true_smooth.shape[0] and y_true_smooth.shape[1] != probs.shape[0] and probs.shape[1]:
            if y_true_smooth.shape[1] > probs.shape[1]:
                y_true_smooth = y_true_smooth[:, :probs.shape[1]]
            else:
                y_true_smooth = np.pad(y_true_smooth, ((0,0),(0, probs.shape[1]-y_true_smooth.shape[1])), mode='constant')
 
        if y_true.shape[0] and y_true.shape[1] != probs.shape[0] and probs.shape[1]:
            if y_true.shape[1] > probs.shape[1]:
                y_true = y_true[:, :probs.shape[1]]
            else:
                y_true = np.pad(y_true, ((0,0),(0, probs.shape[1]-y_true.shape[1])), mode='constant')
 
        # Cross-entropy loss on smoothed labels
        loss = -np.mean(np.sum(y_true_smooth * np.log(probs + 1e-8), axis=1))
 
        # Gradient of cross-entropy loss w.r.t. logits: (probs - y_true) / batch_size
        d_logits = (probs - y_true_smooth) / y_true_smooth.shape[0]
 
        if mode == 'fixed_backward':
            self.fixed_attention_backward(d_logits, lr, max_norm=max_norm)
        else:
            self.dynamic_backward(d_logits, lr, max_norm=max_norm)
 
        # Accuracy uses hard labels (not smoothed) for interpretable reporting
        preds = np.argmax(probs, axis=1)
        true  = np.argmax(y_true, axis=1)
        acc   = np.mean(preds == true)
 
        return loss, acc
 
 
    def train(self, input_ids_list, y_true_list, epochs=100, mode=None,
              lr=0.01, embedded=False, max_norm=1.0, schedule='cosine_warmup',
              pad_token_id=0, batch_size=None):
        """
        Full training loop with GWS initialization, lr scheduling, and optional batching.
 
        GWS (Geometric Weight Shaping):
        - Runs once at the start via self.shaping.weight_shaping()
        - Replaces the random W_o init with one derived from the data's geometry
        - self.encoded=True prevents re-running on subsequent train() calls
        - Note: W_o drifts during training — GWS effect is strongest early on
 
        Batching:
        - batch_size=None: original behavior, one sample per step
        - batch_size=N: sequences are grouped and padded before training starts
          All padding happens once upfront, not per-epoch
 
        Alpha warmup: self.alpha = min(1.0, epoch / 100)
        - Runs in parallel with lr schedule
        - Both start low and rise together, then lr decays while alpha stays at 1.0
        """
        losses, accs = [], []
        d_model = self.d_model
 
        # GWS: geometric initialization of W_o from data structure
        if not self.encoded:
            self.shaping = GeometricWeightShaping(d_model, d_model)
            if embedded:
                shaping_input = np.vstack([
                    x.reshape(-1, x.shape[-1]) if x.ndim >= 2 else x
                    for x in input_ids_list
                ])
            else:
                shaping_input = input_ids_list
            self.W_o      = self.shaping.weight_shaping(shaping_input)
            self.encoded  = True
 
        # Pre-pad into batches once before training (not per-epoch)
        if batch_size is not None and not embedded:
            input_ids_list = [
                self.batch_padding_utility(input_ids_list[i:i+batch_size], pad_token_id)
                for i in range(0, len(input_ids_list), batch_size)
            ]
            y_true_list = [
                np.stack(y_true_list[i:i+batch_size])
                for i in range(0, len(y_true_list), batch_size)
            ]
 
        print(f"[==] Starting comprehensive training for {epochs} epochs "
              f"with mode: {mode}, learning rate: {lr}, schedule: {schedule}")
 
        for epoch in range(epochs):
            epoch_losses, epoch_accs = [], []
            current_lr   = self.learning_rate_warm_up(epoch, epochs, lr, schedule)
            self.alpha   = min(1.0, epoch / 100)   # alpha warmup: 0 → 1 over 100 epochs
 
            for input_ids, y_true in zip(input_ids_list, y_true_list):
                if input_ids.ndim == 1:
                    input_ids = input_ids[np.newaxis, :]
                if y_true.ndim == 1:
                    y_true = y_true[np.newaxis, :]
 
                loss, acc = self.train_step(
                    input_ids, epoch, y_true, current_lr, mode,
                    embedded=embedded, max_norm=max_norm, pad_token_id=pad_token_id
                )
                epoch_losses.append(loss)
                epoch_accs.append(acc)
 
            avg_loss = np.mean(epoch_losses)
            avg_acc  = np.mean(epoch_accs)
            losses.append(avg_loss)
            accs.append(avg_acc)
 
            if epoch % 10 == 0:
                print(f"[=] Epoch {epoch} | loss: {avg_loss:.4f} | Acc: {avg_acc:.2%}"
                      f" | lr: {current_lr:.6f} | alpha: {self.alpha:.3f}")
 
        return losses, accs
 
 
    def predict(self, input_ids, embedded=False):
        """
        Inference pass — dropout disabled, gradients not computed.
 
        input_ids cast to int32 defensively in case upstream processing
        returned float arrays (e.g. from np.stack on mixed-type lists).
        """
        if not embedded:
            input_ids = np.asarray(input_ids, dtype=np.int32)
            if input_ids.ndim == 1:
                input_ids = input_ids[np.newaxis, :]
 
        probs, attn_weights = self.forward(
            input_ids, embedded=embedded,
            training=False, attn_dropout=0.0, ffn_dropout=0.0
        )
        preds = np.argmax(probs, axis=1)
        return preds, probs, attn_weights
 
 
    # ─────────────────────────────────────────────
    # Alpha / complexity measurement
    # ─────────────────────────────────────────────
 
    def AME_Encoder(self, x):
        """
        Abstract Modelling Energy (AME): measures input complexity.
 
        Combines two signals:
        - X_mag: mean L2 norm of the input — how large the activations are
        - grad_energy: mean norm of the gradient along the last axis
                       — how rapidly the signal changes across the sequence
 
        AME = log(1 + X_mag) * log(1 + grad_energy)
 
        log1p keeps the value stable near zero and prevents explosion.
        The product means BOTH magnitude AND variation must be high for
        a large AME — prevents either signal alone from dominating.
 
        Used as the pre-sigmoid input for alpha: high AME → alpha closer to 1
        (complex input → allow more dynamic attention adaptation).
        """
        X          = np.asarray(x)
        gradient   = np.gradient(x, axis=-1)
        grad_energy = np.mean(np.linalg.norm(gradient, axis=-1))
        X_mag      = np.mean(np.linalg.norm(X, axis=-1))
        return np.log1p(X_mag) * np.log1p(grad_energy)
 
 
    def anisotropy_measurement(self, x):
        """
        Measures directional variation (anisotropy) in the input.
 
        Anisotropy = std(gradient_norms) / mean(gradient_norms)
 
        High anisotropy: gradient norms vary a lot across positions
                         → structured, position-dependent signal
        Low anisotropy:  gradient norms are uniform → flat or isotropic signal
 
        Used as a secondary signal in attention_quality_computing to weight
        the contribution of attention variance to the quality score.
        eps prevents division by zero when all gradient norms are identical.
        """
        eps = 1e-5
        try:
            gradient = np.gradient(x, axis=-1)
        except:
            subset   = x[:, 0, 0]
            gradient = np.gradient(subset)
 
        val        = [np.linalg.norm(v) for v in gradient]
        anisotropy = np.std(val) / np.mean(val) + eps
        return anisotropy
 
 
    def attention_quality_computing(self, attn_weights, mask=None):
        """
        Computes a quality score (0-1) for the current attention distribution.
        Used to refine alpha via EMA in forward(): alpha = 0.95*alpha + 0.05*quality
 
        Four components combined into a single scalar:
 
        1. norm_entropy: 1 - normalized_entropy
           High score when attention is sharp (concentrated on few tokens).
           Low score when attention is uniform (spread across all tokens).
           Uniform attention = model hasn't learned meaningful patterns yet.
 
        2. avg_max: mean of per-position attention max values
           High when each query position has one clearly dominant key.
           Complements entropy — both should be high for focused attention.
 
        3. anisotropy * norm_var: attention variance weighted by anisotropy
           Rewards attention patterns that vary meaningfully across positions.
           Prevents reward for random high-variance (noise) attention.
 
        4. AMR (Abstract Modelling Rate): sigmoid(AME) of the attention weights
           qualified = (1 - AMR) + eps * anisotropy
           Acts as a global scaling factor — when attention weights themselves
           show high complexity (high AME), the quality score is down-weighted,
           preventing reward for chaotic attention.
 
        Mask handling: padding positions are zeroed and rows renormalized
        before computing any statistics, so padding doesn't inflate entropy
        or distort the quality estimate.
        """
        eps = 1e-5
        batch, heads, seq_len, _ = attn_weights.shape
 
        if mask is not None:
            mask_expanded = np.broadcast_to(mask, (batch, heads, seq_len, seq_len))
            attn_weights  = attn_weights * mask_expanded
            row_sums      = attn_weights.sum(axis=-1, keepdims=True) + eps
            attn_weights  = attn_weights / row_sums   # renormalize over valid tokens
 
        AME        = self.AME_Encoder(attn_weights)
        anisotropy = self.anisotropy_measurement(attn_weights)
 
        entropy      = -np.sum(attn_weights * np.log(attn_weights + eps), axis=-1)
        max_entropy  = np.log(seq_len)
        norm_entropy = 1.0 - (np.mean(entropy) / max_entropy)
 
        max_attn = np.max(attn_weights, axis=-1)
        avg_max  = np.mean(max_attn)
 
        var_attn = np.var(attn_weights)
        norm_var = np.clip(var_attn * seq_len, 0, 1)
 
        AMR       = 1.0 / (1.0 + np.exp(-AME))
        qualified = (1.0 - AMR) + eps * anisotropy
 
        quality_score = qualified * norm_entropy + qualified * avg_max + anisotropy * norm_var
        return np.clip(quality_score, 0, 1.0)


class Dense:
    '''
    A single fully-connected layer with GWS-initialised weights.

    Weight initialisation
    ---------------------
    Weights are drawn from GeometricWeightShaping.weight_shaping(x) where x is
    the first training batch.  This aligns the initial weight scale with the
    geometric complexity of the actual data rather than using a fixed constant.

    Activation
    ----------
    Pass the name of any method in the Activation class (e.g. 'relu', 'sigmoid').
    If None, the layer is linear (identity activation).

    Shape mismatch tolerance
    ------------------------
    multi_modal_linear_transformation() implements a three-level shape recovery
    cascade so the layer can be called with inputs that differ in feature count
    from the original training batch.  This is intentional: the pipeline reuses
    the same Dense layer instance during training, evaluation, and inference
    where TF-IDF vocabulary size can vary slightly.
    '''
    def __init__(self, x, input_size, output_size, activation=None):

        self.special_weight = GeometricWeightShaping(input_size, output_size)
        self.W = self.special_weight.weight_shaping(x)

        self.b = np.zeros((1, output_size))
        self.activation_name = activation
       

        if activation:
            self.activation = getattr(Activation, activation)
            self.activation_derivative = getattr(Activation, activation + "_derivative")
        else:
            self.activation = None
            self.activation_derivative = None

    def multi_modal_linear_transformation(self, x):
        # Standard linear layer z = xW + b, but with a multi-level shape-mismatch
        # recovery cascade.  This is needed because the GWS weight matrix W is shaped
        # at construction time from the training data, and at inference time the input
        # may have a different number of features (e.g. after vocabulary drift or
        # when calling the model with embedded TF-IDF vectors vs raw token IDs).
        #
        # Recovery hierarchy (outermost try wins):
        #   Level 1 (primary): normal dot(x, W) + b.
        #   Level 2 (first fallback): column-slice W to match x.shape[1], then add
        #             a matching slice of b.
        #   Level 3 (deep fallback): slice both x and W along whichever dimension fits,
        #             then add a b slice.  Covers edge cases where both x and W need trimming.
        #
        # The guard at the top reshapes W in-place if shapes are obviously mismatched
        # (x.shape[1] != W.shape[0]), preferring slicing over re-initialisation.
        if len(x.shape) > 1 and x.shape[1] != self.W.shape[0]:
            V1, V2 = x.shape[0], x.shape[1]            
            try:
                # Trim W's rows to match the feature dimension of x.
                self.W = self.W[:V2, :]
            except:
                # If trimming fails (W is already smaller), re-initialise with correct dims.
                self.special_weight = GeometricWeightShaping(V2, V1)
                self.W = self.special_weight.weight_shaping(x)
        try:
            try:
                z = np.dot(x, self.W) + self.b
            except:
                # W has more rows than x has columns; trim and add matching bias slice.
                subnet_W = self.W[:x.shape[1], :x.shape[0]]

                sub_z = np.dot(x, subnet_W)
                sub_b = self.b[:sub_z.shape[1], :sub_z.shape[0]]

                z = sub_z + sub_b

        except:
            try:
                subnet_W = self.W[:x.shape[1]:, :x.shape[0]]
                sub_z = np.dot(x, subnet_W)
            except:
                # Last resort: trim x to fit W or vice versa, whichever succeeds first.
                weight = self.W

                try:
                    subnet_x = x[:, :weight.shape[0]]
                    subnet_W = weight[:x.shape[1], :]                    
                except:
                    subnet_x = x[:weight.shape[0]]
                    subnet_W = weight[:x.shape[0]]

                sub_z = np.dot(subnet_x, subnet_W)

            try:
                subnet_B = self.b[:sub_z.shape[0], :sub_z.shape[1]]
            except:
                subnet_B = self.b[:sub_z.shape[0]]
                
            z = sub_z + subnet_B      

        return z


    def forward(self, x):
        self.x = x
        self.z = self.multi_modal_linear_transformation(x)

        if self.activation:
            self.a = self.activation(self.z)
        else:
            self.a = self.z

        return self.a


    def backward(self, da, lr):
        eps = 1e-5

        if self.activation_derivative: 
            dz = da * self.activation_derivative(self.z)
        else:
            dz = da

        dW = np.dot(self.x.T, dz)
        db = np.sum(dz, axis=0, keepdims=True)
        dx = np.dot(dz, self.W.T)

        self.W -= lr * dW 
        self.b -= lr * db 
      
        return dx
        

    	
    	
class SoftmaxOutput:
    def forward(self, x):
        self.out = Activation.softmax(x)
        return self.out

    def backward(self, dL_dZ):
        # gradient already computed as y_pred - y_true
        return dL_dZ


# Enhanced MLP with focused forward and backward passes for better handling of
# data with varying geometric complexity, complementing the Transformer in the
# ensemble method.  The "focused" path (feed_layers) allows the MLP to
# concentrate on a subset of layers during fine-tuning, providing a
# complementary learning dynamic alongside the Transformer.
#
# Geometric weight research: https://github.com/Micro-Novelty/Specialized-MLP-for-noise-robustness

class MLP:
    '''
    Multi-layer perceptron composed of Dense (GWS-initialised) layers.

    Two execution paths
    -------------------
    Standard path  : self.layers     — used for primary training and prediction.
    Focused path   : self.feed_layers — a secondary stack that can be trained
                     independently via focused_forward / focused_backward.
                     Useful when you want to fine-tune only specific layers
                     without affecting the rest of the network.

    Both paths share the same SoftmaxOutput layer at the end.

    Usage
    -----
        mlp = MLP()
        mlp.add(Dense(X_train, input_dim, hidden_dim, activation='relu'))
        mlp.add(Dense(X_train, hidden_dim, num_classes))
        mlp.train(X_train, y_one_hot, epochs=1000, lr=0.1)
        probs = mlp.predict_proba(X_test)
    '''
    def __init__(self):
        self.layers = []
        self.layers2 = []
        self.lr = 0.1
        self.feed_layers = []
    
        self.softmax = SoftmaxOutput()
      

    def feed_add(self, layer):
        self.feed_layers.append(layer)

    def add(self, layer):
        self.layers.append(layer)

    def focused_forward(self, x):
        for layer in self.feed_layers:
            x = layer.forward(x)
            
        return self.softmax.forward(x) 

    def forward(self, x):
        for layer in self.layers:
            x = layer.forward(x)
            
        return self.softmax.forward(x)
        
    def focused_backward(self, grad, lr):
        grad = self.softmax.backward(grad)
        for layer in reversed(self.feed_layers):
            grad = layer.backward(grad, lr)
        return grad  

    def backward(self, grad, lr):
        grad = self.softmax.backward(grad)
        for layer in reversed(self.layers):
            grad = layer.backward(grad, lr)
        return grad
            
    def predict(self, X, y, epochs=1000, verbose=True):
        for epoch in range(epochs):
            y_pred = self.forward(X)
            loss = Loss.categorical_crossentropy(y, y_pred)    		
            if verbose and epoch % 100 == 0:
                acc = np.mean(np.argmax(y_pred, axis=1) == np.argmax(y, axis=1))
                self.acc2.append(acc)
                print(f"[=] Epoch {epoch} | loss:{loss:.4f} | Acc: {acc:.2f}")

	   
    def prediction(self, X):
        y_pred = self.forward(X)   
        return y_pred      


    def score(self, X, y):
        y_pred = self.prediction(X)
        acc = np.mean(np.argmax(y_pred, axis=1) == np.argmax(y, axis=1))
        return acc         
         
    def AME_Encoder(self, x):
        X = np.asarray(x)

        if x.shape[1] == 1:
            x = x.T
            x= x.flatten()

        gradient = np.gradient(x, axis=-1)
        grad_energy = np.mean(np.linalg.norm(gradient, axis=-1))       
        X_mag = np.mean(np.linalg.norm(X, axis=-1))

        AME = np.log1p(X_mag) * np.log1p(grad_energy) 
        return AME


    def anisotropy_measurement(self, x):
        eps = 1e-5
        try:
            gradient = np.gradient(x, axis=-1)
        except:
            subset = x[:, 0, 0]
            gradient = np.gradient(subset)

        val = [np.linalg.norm(v) for v in gradient]
        anisotropy = np.std(val) / np.mean(val) + eps

        return anisotropy


    def train(self, X, y, epochs=1000, lr=0.01, verbose=True):
        # Decide whether to use the "focused" sub-network (feed_layers) or the
        # standard full network (layers) for this training run.
        #
        # focused_fit_condition is True when ALL three hold:
        #   1. feed_layers is non-empty  — a focused sub-network exists
        #   2. anisotropy > 0.25         — data has sufficient directional variation
        #                                  (flat/isotropic data doesn't benefit from focus)
        #   3. AME > 0.25               — combined magnitude × gradient energy is above
        #                                  a minimum threshold (data is complex enough)
        #
        # When True, only feed_layers are updated via focused_forward/focused_backward,
        # letting the model concentrate its learning capacity on high-complexity data
        # without disrupting the full network's previously learned representations.
        focused_fit_condition = len(self.feed_layers) > 0 and self.anisotropy_measurement(X) > 0.25 and self.AME_Encoder(X) > 0.25
        print(f'[+] Focused fit condition: {focused_fit_condition} || Anisotropy: {self.anisotropy_measurement(X):.4f} || AME: {self.AME_Encoder(X):.4f}')
        for epoch in range(epochs):
            if not focused_fit_condition:
                y_pred = self.forward(X)
            else:
                y_pred = self.focused_forward(X)

            loss = Loss.categorical_crossentropy(y, y_pred)
            grad = Loss.softmax_crossentropy_derivative(y, y_pred)
            _ = self.backward(grad, self.lr)

            if verbose and epoch % 100 == 0:
                acc = np.mean(np.argmax(y_pred, axis=1) == np.argmax(y, axis=1))
                print(f"[=] Epoch {epoch} | Loss: {loss:.4f} | Acc: {acc:.2f}")
              

# weighted ensemble predictor that dynamically adjusts the weights of the transformer and MLP based on the input data's geometric complexity and the attention quality>
# allowing it to leverage the strengths of both models for improved performance across a wider range of data complexities.
class WeightedEnsemblePredictor:
    '''
    Combines MLP and Transformer predictions using dynamically tuned weights,
    with an attention-based memory cache and an integrated ExplainabilityModule.

    Ensemble weights
    ----------------
    transformer_weight + mlp_weight = 1.0 (maintained by the caller).
    Initial split is 50/50.  find_optimal_ensemble_weights() searches over a
    grid of weight values and picks the split that maximises accuracy on a
    provided validation set.

    Attention memory gate
    ---------------------
    attention_memory_gate() checks self.memory for a previously seen input
    whose TF-IDF cosine similarity to the current input is ≥ 0.85.  If found,
    the cached attention outputs are returned directly (skipping the forward
    pass), acting as a lightweight associative memory for repeated inputs.

    Explainability
    --------------
    self.explainer (ExplainabilityModule) is used to generate human-readable
    prediction explanations that surface the dominant TF-IDF features,
    attention focus words, and the MLP vs Transformer arbitration logic.

    Parameters
    ----------
    pipeline      : IntegratedPipeline instance.
    distribution  : AgentDistributedInference instance (for peer calibration).
    memory_name   : DB scope for storing attention snapshots.
    '''
    def __init__(self, pipeline, distribution, memory_name):
        self.pipeline = pipeline
        self.storage = ModelStorage(pipeline, memory_name, db_path='activity_log.db')
        self.inference = distribution
        self.query_node = QueryNode(pipeline, memory_name, self.storage)

        self.transformer_weight = 0.5  # Initial equal weight
        self.mlp_weight = 0.5 # initial equal mlp weight
        self.calibration_history = []
        self.explainer = ExplainabilityModule(pipeline, self)
        self.memory_name = memory_name
        self.db_path = 'activity_log.db'

        self.self_attn_weights = None

        if not self.storage.memory_exists(self.memory_name, type='Transformer'):
            self.memory = {}
        else:
            self.memory = self.storage.memory_retrieval(self.memory_name, type_func='Transformer', verbose=True)


    def _get_lstm_probs(self, input_ids, X_mlp, label_bins=None, confidence_level=0.90):
        """
        Convert LSTMEngine prediction output into a probability
        distribution compatible with trans_probs and mlp_probs
        for use in _dynamic_weighted_ensemble.

        Returns:
            lstm_probs : np.ndarray (batch_size, n_classes) or None if engine not ready
            lstm_weight_hint : float — calibrated confidence scalar for weighting
        """
        engine = self.pipeline.lstm_engine

        # guard — engine must be calibrated before predict() is callable
        if engine is None or engine.residual_std is None:
            print('[-] LSTM engine not ready, skipping LSTM probs')
            return None, 0.0

        # X_mlp is (batch, features) — LSTM expects (T, input_size) per sample
        # treating each feature vector as a single timestep sequence
        if X_mlp.ndim == 1:
            X_mlp = X_mlp.reshape(1, -1)

        batch_size = X_mlp.shape[0]
        n_classes = self.pipeline.model2.output.shape[1]  # align with transformer output

        lstm_probs = np.zeros((batch_size, n_classes))
        overall_confidences = []

        for i in range(batch_size):
            # shape each sample into (T=1, input_size) — single timestep
            x_seq = X_mlp[i].reshape(1, -1)

            try:
                result = engine.predict(
                    x_seq,
                    label_bins=label_bins,
                )
            except AssertionError:
                # calibrate() not called yet — skip gracefully
                print(f'[-] LSTM engine not calibrated for sample {i}, skipping')
                return None, 0.0

            # result['prediction'] is (T,) — take last timestep as scalar score
            raw_score = float(result['prediction'][-1])
            overall_confidences.append(result['overall'])

            # convert scalar score to class probabilities
            # label_confidence gives {label: prob} if label_bins were passed
            if result['label_confidence'] is not None:
                # map label_bins order to class indices
                label_probs = list(result['label_confidence'].values())
                n_label = len(label_probs)

                row = np.zeros(n_classes)
                row[:min(n_label, n_classes)] = label_probs[:n_classes]

                # renormalize in case n_label != n_classes
                row_sum = row.sum()
                if row_sum > 0:
                    row /= row_sum
                else:
                    row[0] = 1.0  # fallback — assign all mass to class 0

            else:
                # no label_bins — use mc_confidence at last timestep as a
                # soft signal: spread probability mass using mc_mean as logit
                mc_mean_last = float(result['mc_mean'][-1])
                mc_conf_last = float(result['mc_confidence'][-1])

                # build a soft peaked distribution using the score as a logit
                logits = np.full(n_classes, -mc_conf_last)
                target_class = int(np.clip(round(raw_score), 0, n_classes - 1))
                logits[target_class] = mc_conf_last

                # softmax
                logits -= logits.max()
                row = np.exp(logits)
                row /= row.sum()

            lstm_probs[i] = row

        # weight hint — average overall confidence across batch
        # lower residual_std = engine is well calibrated = higher weight earned
        mean_overall = float(np.mean(overall_confidences))
        lstm_weight_hint = mean_overall / (1.0 + engine.residual_std)

        return lstm_probs, lstm_weight_hint

    def attention_memory_gate(self, probs, x):
        # Fast-path cache lookup: checks whether a previously seen input (stored under
        # prefix 'TA' in self.memory) is geometrically similar to the current input x.
        # Similarity is measured by cosine similarity ≥ 0.85 (tight threshold to avoid
        # false hits on unrelated inputs that happen to share some features).
        #
        # If a match is found, the cached attention outputs (texts, x2, x3, x4) are
        # returned directly, skipping a full forward pass through the transformer.
        # This also acts as a continual memory mechanism: the pipeline "remembers"
        # past attention patterns and reuses them for similar future inputs.
        #
        # Cache miss path:
        #   - If self_attn_weights was set by a prior call, return it as a warm fallback.
        #   - Otherwise return (None, None, None, None) signalling a full inference needed.
        memory = self.memory
        cache_attn_memory = [key for key, (_, inp, _, _, _) in memory.items() if key.startswith('TA') and self.pipeline.cosine_similarity(x, inp) >= 0.85]

        if cache_attn_memory:
            print('[+] Found matching attention memory!')
            for memo in cache_attn_memory:
                texts, _, x2, x3, x4 = memory[memo]

            return texts, x2, x3, x4

        else:
            print('🔄 NoMatching Attention Weights!')
            if self.self_attn_weights is not None:
                print('|| Using current attention weights because of no matches found.')
                attn_weights = self.self_attn_weights
                return None, None, None, attn_weights

            return None, None, None, None

           

    def modular_attention_saving(self, text, X, X2, X3, X4):
        memory_name = self.memory_name

        self.memory['TA'] = X, text, X2, X3, X4

        self.storage.save_model_dict(memory_name, self.memory, type='Transformer', model_type='attention')

        print('🚀 Memory Probability Added!')




    def explainability_prediction_batch(self, texts, mlp_probs, trans_probs, attn_weights, show_explanation=False):
        results = []
        for i, text in enumerate(texts):
            text_mlp_probs = mlp_probs[i] if i < len(mlp_probs) else mlp_probs
            text_trans_probs = trans_probs[i] if i < len(trans_probs) else trans_probs
            text_attn_weights = attn_weights[i] if i < len(attn_weights) else attn_weights

            result = self.predict_single(text, text_mlp_probs, text_trans_probs, text_attn_weights, show_explanation)
            results.append(result)
            explanation = result['explanation']
            print(f'[+] Explanation: {explanation}')
        
        return results
    

    def credibility_summarized_prediction(self, input_ids, mlp_probs, trans_probs, attn_weights, type=None):
        if type == 'Transformer':
            texts, mlp_probs, trans_probs, attn_weights = self.attention_memory_gate(input_ids)
            if not texts:
                texts = self.pipeline.texts
        else:
            texts = self.pipeline.texts

        results = self.explainability_prediction_batch(texts, mlp_probs, trans_probs, attn_weights)

        # Calculate summary
        predictions = [r['prediction'] for r in results]
        confidences = [r['confidence'] for r in results]
        
        from collections import Counter
        distribution = Counter(predictions)
        
        print("\n📊 Batch Summary:")
        print(f"   Total: {len(results)} predictions")
        print(f"   Avg Confidence: {np.mean(confidences):.1%}")
        print(f"   Distribution: {dict(distribution)}")
        
        self.modular_attention_saving(input_ids, texts, mlp_probs, trans_probs, attn_weights )


    def explain_past_memory(self, probs, input_ids):
        _, mlp_probs, trans_probs, attn_weights = self.attention_memory_gate(probs, input_ids)
        self.self_attn_weights = attn_weights

        self_attn_weights = self.self_attn_weights

        if trans_probs is not None:
            print('[+] Attention memory retrieved! ')
            method = 'memory_retrieval'

            self.credibility_summarized_prediction(input_ids, mlp_probs, trans_probs, attn_weights, type='pipeline')
            ensemble_probs = self._dynamic_weighted_ensemble(
                trans_probs, mlp_probs, attn_weights, input_ids
            )

            return ensemble_probs
        else:
            print("[-] Ambiguity present, Requesting peer assistance... ")
        
            try:
                probs = self.inference._handle_peer_agent_request(probs, self_attn_weights, input_ids, type='DevicePeer', agreement=False)
                return probs
            except Exception as e:
                print(f'|| Error initiating peer request: {e}, returning regular probs.')
                self.inference.report_failure(id(self), 'processing', reason=f'{e}')                        

                return probs

    def predict_single(self, text, mlp_probs, trans_probs, attn_weights, show_explanation=True, batch_size=2):
        # small batch size is used to prevent memory overflow in explanation module when processing large attention weights, as it computes detailed explanations that can be memory intensive.
        cache = self.pipeline.cache
        if cache is not None and "lstm_result" in cache:
            lstm_result = self.pipeline.cache['lstm_result']
            result, explanation = self.explainer._get_prediction_details(text, mlp_probs, trans_probs, attn_weights, lstm_result=lstm_result, batch_size=batch_size)
        else:
            result, explanation = self.explainer._get_prediction_details(text, mlp_probs, trans_probs, attn_weights, batch_size=batch_size)            
        return {
            'prediction': result['final_label'],
            'confidence': result['final_confidence'],
            'explanation': explanation,
            'details': result
        }



    def explainability_prediction_batch(self, texts, mlp_probs, trans_probs, attn_weights, show_explanation=False):
        results = []
        for text in texts:
            result = self.predict_single(text, mlp_probs, trans_probs, attn_weights, show_explanation)
            results.append(result)
            explanation = result['explanation']
            print(f'[+] Explanation: {explanation}')
        
        return results
    

     

    def predict_ensemble(self, input_ids, X_mlp, y_true, method='dynamic', embedded=False):
        trans_probs, attn_weights = self.pipeline.model2.forward(input_ids, embedded=embedded)
        mlp_probs = self.pipeline.mlp.forward(X_mlp)
        established_agreement = self.query_node._establish_node_connection("PredictEnsemble")
        
        if method == 'equal':
            # Simple average
            ensemble_probs = (trans_probs + mlp_probs) / 2
            
        elif method == 'confidence':
            # Weight by confidence (max probability)
            trans_conf = np.max(trans_probs, axis=1, keepdims=True)
            mlp_conf = np.max(mlp_probs, axis=1, keepdims=True)
            
            # Normalize weights
            total_conf = trans_conf + mlp_conf + 1e-8
            trans_weight = trans_conf / total_conf
            mlp_weight = mlp_conf / total_conf
            
            ensemble_probs = trans_weight * trans_probs + mlp_weight * mlp_probs
            
        elif method == 'dynamic':
            # Dynamic weighting based on agreement and attention
            ensemble_probs = self._dynamic_weighted_ensemble(
                trans_probs, mlp_probs, attn_weights, input_ids
            )
            
        elif method == 'attention':
            # Use attention to weight transformer vs MLP
            ensemble_probs = self._attention_weighted_ensemble(
                trans_probs, mlp_probs, attn_weights
            )
            
        elif method == 'meta':
            # Meta-learner that decides weights
            ensemble_probs = self._meta_ensemble(
                trans_probs, mlp_probs, attn_weights, X_mlp
            )
        
        elif method == 'calibration':
            calibrated_weight = self.calibrate_weights(input_ids, X_mlp, y_true, step=3)  
            ensemble_probs = self._attention_weighted_ensemble(
                trans_probs, mlp_probs, calibrated_weight
            )
                                    
        else:
            print(f"Unknown method: {method}")

        
        if established_agreement and self.pipeline.show_explainability_details:
            print('[✅] Agreement established, generating explainability features.')
            try:
                print('=== COMPLETE EXPLAINABILITY PREDICTION ==') 
                self.credibility_summarized_prediction(input_ids, mlp_probs, trans_probs, attn_weights, type='pipeline')
            except Exception as e:
                print(f'[-] Cant get explainability features! : {e}')
        else:
            print('[-] No agreement established, skipping explainability features.')


        try:
            ensemble_probs = ensemble_probs / ensemble_probs.sum(axis=1, keepdims=True)
        except:
            ensemble_probs = ensemble_probs / ensemble_probs.sum()

        if ensemble_probs is None or np.isnan(ensemble_probs).any() or np.isinf(ensemble_probs).any():
            print('[-] Ensemble probs is invalid , using MLP probs as.')
            return mlp_probs, {
            'transformer': trans_probs,
            'mlp': mlp_probs,
            'ensemble': mlp_probs,
            'method': None              
            }   

        return ensemble_probs, {
            'transformer': trans_probs,
            'mlp': mlp_probs,
            'ensemble': ensemble_probs,
            'method': method
        }
        
    def anisotropy_measurement(self, x):
        eps = 1e-5
        gradient = np.gradient(x)

        val = [np.linalg.norm(v) for v in gradient]
        anisotropy = np.std(val) / np.mean(val) + eps
        return anisotropy

    def _dynamic_weighted_ensemble(self, trans_probs, mlp_probs, attn_weights, input_ids,
                                    lstm_weight_hint):
        # Per-sample dynamic weighting of Transformer and MLP predictions.
        # paired with LSTM proof of credibility and prediction boost to calibrate ensemble weight
        # Unlike the static self.transformer_weight / self.mlp_weight used in
        # calibrate_weights(), this method derives weights on-the-fly from three signals:
        #
        #   trans_conf_factor  — derived from attention statistics:
        #                         attn_focus    = std of the attention map (0 = flat, high = peaked)
        #                         attn_growth   = sigmoid(attn_focus) — bounded confidence signal
        #                         attn_limit    = (1 - attn_focus + attn_growth) * anisotropy
        #                         factor        = attn_growth + attn_limit * attn_focus
        #                        Intuitively: the transformer earns more weight when its attention
        #                        is peaked (focused) AND the distribution is geometrically varied.
        #
        #   mlp_conf_factor    — derived from MLP output entropy:
        #                         lower entropy → sharper distribution → higher confidence → higher weight.
        #                         formula: 1 / (1 + entropy)
        #
        #   agreement          — 1.0 if both models predict the same class, else 0.3.
        #                        Acts as a confidence multiplier: agreement boosts both weights
        #                        proportionally, disagreement dampens the overall contribution.
        #
        # Both factors are multiplied by (1 + agreement) / 2, then normalised so they sum to 1.
        # The final ensemble for sample i is: trans_weight * trans_row + mlp_weight * mlp_row + lstm_weight * lstm_row
        batch_size = trans_probs.shape[0]
      
        try:
            n_trans_classes = trans_probs.shape[1]
            n_mlp_classes = mlp_probs.shape[1]
            n_lstm_classes = lstm_probs.shape[1]
        except:
            n_trans_classes = trans_probs.shape[-1]
            n_mlp_classes = mlp_probs.shape[-1]   
            n_lstm_classes = lstm_probs.shape[-1]     

        n_classes = max(n_trans_classes, n_mlp_classes)
        
        print(f"🔄 Aligning classes: {n_trans_classes} and {n_mlp_classes} → {n_classes}")
        ensemble = np.zeros((batch_size, n_classes))
        for i in range(batch_size):
            trans_row = np.zeros(n_classes)
            mlp_row = np.zeros(n_classes)
            
            trans_row[:n_trans_classes] = trans_probs[i]
            mlp_row[:n_mlp_classes] = mlp_probs[i]
            
            trans_row = trans_row / (trans_row.sum() + 1e-8)
            mlp_row = mlp_row / (mlp_row.sum() + 1e-8)
            
            trans_pred = np.argmax(trans_probs[i])
            mlp_pred = np.argmax(mlp_probs[i])
            agreement = 1.0 if trans_pred == mlp_pred else 0.3

            if attn_weights is not None and i < len(attn_weights):
                print('🔄 Sophisticated confidence assembling')
                attn = attn_weights[i]
                anisotropy = self.anisotropy_measurement(attn) 

                attn_focus = np.std(attn) if attn.size > 0 else 0.5
                attn_growth = 1.0 / (1.0 + np.exp(-attn_focus))
                attn_limit = (1.0 - attn_focus + attn_growth) * anisotropy

                trans_conf_factor = attn_growth + attn_limit * attn_focus 
            else:
                attn_growth = 1.0 / (1.0 + np.exp(-attn_weights))
                anisotropy = self.anisotropy_measurement(attn_weights)
                trans_conf_factor = attn_growth * anisotropy

            mlp_entropy = -np.sum(mlp_probs[i] * np.log(mlp_probs[i] + 1e-8))
            mlp_conf_factor = 1.0 / (1.0 + mlp_entropy)  # Lower entropy = higher confidence
            
            trans_weight = trans_conf_factor * (1.0 + agreement) / 2
            mlp_weight = mlp_conf_factor * (1.0 + agreement) / 2

            if lstm_probs is not None:
                lstm_row = np.zeros(n_classes)
                lstm_row[:n_lstm_classes] = lstm_probs[i]
                lstm_row = lstm_row / (lstm_row.sum() + 1e-8)

                # lstm_weight_hint already encodes residual_std confidence
                lstm_pred   = np.argmax(lstm_probs[i])
                lstm_agreement = 1.0 if lstm_pred == trans_pred or lstm_pred == mlp_pred else self.pipeline.confidence_threshold
                lstm_weight = lstm_weight_hint * (1.0 + lstm_agreement) / 2

                total = trans_weight + mlp_weight + lstm_weight + 1e-8
                trans_weight /= total
                mlp_weight   /= total
                lstm_weight  /= total

                ensemble[i] = trans_weight * trans_row + mlp_weight * mlp_row + lstm_weight * lstm_row
            else:
                # original two-model path — unchanged
                total = trans_weight + mlp_weight + 1e-8
                trans_weight /= total
                mlp_weight   /= total
                ensemble[i] = trans_weight * trans_row + mlp_weight * mlp_row
    
        return ensemble
    
    def _attention_weighted_ensemble(self, trans_probs, mlp_probs, attn_weights):

        if attn_weights is None:
            return (trans_probs + mlp_probs) / 2
        
        batch_size = trans_probs.shape[0]
        ensemble = np.zeros_like(trans_probs)

        n_trans_classes = trans_probs.shape[1]        
        n_mlp_classes = mlp_probs.shape[1]
        n_classes = max(n_trans_classes, n_mlp_classes)

        for i in range(batch_size):
            trans_row = np.zeros(n_classes)
            mlp_row = np.zeros(n_classes)
            
            trans_row[:n_trans_classes] = trans_probs[i]
            mlp_row[:n_mlp_classes] = mlp_probs[i]
            
            trans_row = trans_row / (trans_row.sum() + 1e-8)
            mlp_row = mlp_row / (mlp_row.sum() + 1e-8)

            if i < len(attn_weights):
                attn = attn_weights[i]
                anisotropy = self.anisotropy_measurement(attn)                
                # Attention entropy: lower entropy = more focused = trust transformer more
                if attn.size > 0:
                    attn_flat = attn.flatten()
                    attn_entropy = -np.sum(attn_flat * np.log(attn_flat + 1e-8)) / np.log(len(attn_flat))
                    trans_trust = 1.0 - attn_entropy  # 0 to 1
                else:
                    attn_focus = 1.0 / (1.0 + np.exp(-attn))
                    trans_trust = attn_focus * anisotropy
            else:
                attn_focus = 1.0 / (1.0 + np.exp(-attn))
                attn_limit = 1.0 - np.exp(-attn_focus)
                trans_trust = attn_limit * (1.0 - anisotropy)
            
            # MLP gets the rest
            mlp_trust = 1.0 - trans_trust

            try:
                ensemble[i] = trans_trust * trans_row + mlp_trust * mlp_row
            except:
                ensemble = trans_trust * trans_row + mlp_trust * mlp_row
        
        return ensemble
    
    def _meta_ensemble(self, trans_probs, mlp_probs, attn_weights, X_mlp):
        # Second-level ("stacking") ensemble.  Instead of computing weights from raw
        # attention or entropy signals, it builds a meta-feature vector for each sample
        # that summarises both models' outputs and their relationship, then derives
        # sample-specific weights from those features.
        #
        # Meta-features per sample (up to 7 values):
        #   [0] max(trans_row)             — transformer peak confidence
        #   [1] max(mlp_row)               — MLP peak confidence
        #   [2] std(trans_row)             — transformer output spread (uncertainty proxy)
        #   [3] std(mlp_row)               — MLP output spread
        #   [4] 1.0 if both agree, else 0  — inter-model agreement flag
        #   [5] std(attn[i])               — attention map spread (if available)
        #   [6] max(attn[i])               — peak attention value (if available)
        #
        # Weight derivation:
        #   base_weight = (threshold_feature + AME_sigmoid) * agreement  → lower base_weight (disagree) higher base_weight (agree) 
        #   the agree or disagreement happens before multiplication with agreement, meaning the subtitution provides a clear signal of data
        #   while multiplication with agreement means absolute,it will either absolutely agree or disgree, this part is used for amplification.
        #   Whichever model has higher confidence gets base_weight;
        #   the other gets 1 - base_weight.
        #
        # NOTE: there is a scoping bug here — trans_row / mlp_row from the loop above
        # are used outside the loop in the weight application (line ~1582).  On the last
        # iteration they hold values for sample batch_size-1, but for earlier iterations
        # the wrong row is applied.  Flagged in code review.
        batch_size = trans_probs.shape[0]
        n_classes = trans_probs.shape[1]
        threshold_feature = 0.1 + self.pipeline.confidence_threshold

        n_trans_classes = trans_probs.shape[1]        
        n_mlp_classes = mlp_probs.shape[1]
        n_classes = max(n_trans_classes, n_mlp_classes)

        # Create meta features
        meta_features = []
        for i in range(batch_size):
            trans_row = np.zeros(n_classes)
            mlp_row = np.zeros(n_classes)
            
            trans_row[:n_trans_classes] = trans_probs[i]
            mlp_row[:n_mlp_classes] = mlp_probs[i]
            
            # Re-normalise after zero-padding to maintain valid probability distributions.
            trans_row = trans_row / (trans_row.sum() + 1e-8)
            mlp_row = mlp_row / (mlp_row.sum() + 1e-8)

            features = [
                np.max(trans_row),           # Transformer confidence
                np.max(mlp_row),              # MLP confidence
                np.std(trans_row),             # Transformer spread
                np.std(mlp_row),               # MLP spread
                1.0 if np.argmax(trans_row) == np.argmax(mlp_row) else 0.0,  # Agreement
            ]
            
            # Add attention stats if available
            if attn_weights is not None and i < len(attn_weights):
                attn = attn_weights[i]
                if attn.size > 0:
                    features.append(np.std(attn))
                    features.append(np.max(attn))
                else:
                    features.extend([threshold_feature, threshold_feature])
            else:
                features.extend([threshold_feature, threshold_feature])
            
            meta_features.append(features)
        
        meta_features = np.array(meta_features) 
        featured_AME = self.pipeline.AME_Encoder(meta_features) 
        AME_sigmoid = 1.0 / (1.0 + np.exp(-featured_AME))

        ensemble = np.zeros_like(trans_probs)
        
        for i in range(batch_size):
            # Calculate weight based on meta features
            trans_conf = meta_features[i, 0]
            mlp_conf = meta_features[i, 1]
            agreement = meta_features[i, 4]
            
            # Boost weight when models agree
            base_weight = threshold_feature + AME_sigmoid * agreement
            
            
            # Adjust based on relative confidence
            if trans_conf > mlp_conf:
                trans_weight = base_weight
                mlp_weight = 1.0 - base_weight
            else:
                trans_weight = 1.0 - base_weight
                mlp_weight = base_weight

            try:
                ensemble[i] = trans_weight * trans_row + mlp_weight * mlp_row
            except:
                ensemble = trans_weight * trans_row + mlp_weight * mlp_row                
        
        return ensemble
    
    def calibrate_weights(self, input_ids, X_mlp, y_true, step=3):
        print("\n🔧 Calibrating ensemble weights...")

        # Weight calibration methods
        best_weight = 0.1 + self.pipeline.confidence_threshold
        best_accuracy = 0
        
        # Try different weights
        for w in np.linspace(0, 1, 11):
            self.transformer_weight = w
            self.mlp_weight = 1 - w
            
            correct = 0
            total = 0
            for i in range(step):
                trans_probs, _ = self.pipeline.model2.forward(input_ids)
                mlp_probs = self.pipeline.mlp.forward(X_mlp)
                
                ensemble = w * trans_probs + (1-w) * mlp_probs
                preds = np.argmax(ensemble, axis=1)
                true = np.argmax(y_true, axis=1)
                
                correct += np.sum(preds == true)
                total += len(preds)
            
            accuracy = correct / total
            print(f" || Weight: {w:.1f}: Accuracy: {accuracy:.2%}")
            
            if accuracy > best_accuracy:
                best_accuracy = accuracy
                best_weight = w

        self.transformer_weight = best_weight
        self.mlp_weight = 1.0 - best_weight

        print(f"\n✅ Optimal weights: Transformer: {best_weight:.2f}, MLP={1-best_weight:.2f}")
        print(f"[-] Validation accuracy: {best_accuracy:.2%}")
        
        return best_weight

# Cross-session automation module: export/import sessions, sync with another device,
# and list available sessions for continuity across environments.
class CrossSessionAutomation:
    '''
    Serialises and restores the full pipeline state across process restarts or
    different machines.

    A "session" is a JSON snapshot that includes:
      - Pipeline memory dict (TW/MW/TP/MP/TA keys and cached probabilities).
      - Model weights (TF-IDF vocab, MLP layer weights, Transformer weights).
      - Label map and vocabulary.
      - Metadata (timestamp, session name, pipeline memory_name).

    Methods
    -------
    export_session(session_name)
        Serialises the current pipeline state to a JSON file named
        <session_name>.json in the working directory.

    import_session(filepath)
        Loads a previously exported session from disk and restores all weights
        into the live pipeline instance.

    sync_with_device(host, port)
        Sends the current session over a raw TCP socket to a listening peer,
        enabling cross-machine model synchronisation without a shared DB.

    list_sessions()
        Returns the list of .json session files in the current directory.
    '''
    def __init__(self, pipeline):
        self.pipeline = pipeline
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    def export_session(self, session_name=None):
        if session_name is None:
            session_name = f"session_{self.session_id}"
        
        session_data = {
            'session_id': self.session_id,
            'session_name': session_name,
            'timestamp': datetime.now().isoformat(),
            'memories': self.pipeline.memory.copy(),
        }
        
        filename = f"{session_name}.json"
        with open(filename, 'w') as f:
            json.dump(session_data, f, default=str)
        
        print(f"💾 Session exported to: {filename}")
        return filename
    
    def import_session(self, filename):
        with open(filename, 'r') as f:
            session_data = json.load(f)
        
        print(f"\n📥 Importing session: {session_data['session_name']}")
        print(f"   Created: {session_data['timestamp']}")
        print(f"   Memories: {len(session_data['memories'])}")
        
        # Merge memories
        for key, value in session_data['memories'].items():
            if key not in self.pipeline.memory:
                self.pipeline.memory[key] = value
        
        print(f"✅ Session imported! Total memories: {len(self.pipeline.memory)}")
    
    def sync_with_another_device(self, device_ip, port=5000):
        import socket
        import pickle
        
        # Export current session
        temp_file = self.export_session(f"sync_{self.session_id}")
        
        try:
            with self.ssl_context.wrap_socket(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
                s.connect((device_ip, port))
                with open(temp_file, 'rb') as f:
                    s.sendall(f.read())
                print(f"📡 Synced to {device_ip} || {port}")
                print('🚀 Succesfully sync and export memory session to another device! ')                 
        except Exception as e:
            print(f"❌ Sync failed: {e}")
            pass
        

    
    def list_sessions(self, name):
        import glob

        sessions = glob.glob(f"{name}*.json")
        
        print(f"\n📚 Available Sessions: {sessions}")
        if sessions:
            for session in sessions:
                with open(session, 'r') as f:
                    data = json.load(f)
                    print(f"   • {session}: {data['session_name']} ({len(data['memories'])} memories)")

        else:          
            print('[-] No available sessions! ')
        
        return sessions


# Explainability module that provides detailed explanations for predictions, allows learning from user feedback, and maintains a history of decisions for transparency and continuous improvement of the model.
class ExplainabilityModule:
    '''
    Generates human-readable explanations for pipeline predictions and
    implements an optional supervised-learning feedback loop.

    Explanation output
    ------------------
    explain() returns two values:
      details     — dict with keys: final_label, final_confidence, mlp (pred+conf),
                    transformer (pred+conf), attention_focus (top-3 words),
                    geometric_features (anisotropy, AME, dominant TF-IDF terms),
                    attention_quality.
      explanation — formatted multi-line string printed in a "reasoning chain"
                    style (MLP geometric reasoning → Transformer context → final
                    decision with confidence bar).

    Supervised feedback loop
    ------------------------
    When self.supervised_learning = True and a prediction falls below
    uncertainty_threshold (default 0.2), the module asks the user for the
    correct label via _ask_for_feedback(), then calls _learn_from_feedback()
    to perform a one-shot online weight update on the MLP.

    Feedback is buffered (buffer_size = 10) before triggering a batch backward
    pass, reducing oscillation from single-sample updates.

    consolidate_supervised_memories() can be called explicitly to merge all
    buffered feedback into a full training cycle.

    Parameters
    ----------
    pipeline   : IntegratedPipeline instance (used for feature extraction and
                 model forward passes).
    predictor  : WeightedEnsemblePredictor instance (provides ensemble weights
                 and peer calibration access).
    '''
    def __init__(self, pipeline, predictor):
        self.pipeline = pipeline
        self.decision_history = []     

        self.decision_history = []     
        
        self.uncertainty_threshold = 0.2
        self.pending_queries = []
        self.learned_from_feedback = []   
        self.feedback_buffer = []  # Store feedback for batch training
        self.buffer_size = 10  # Train after every 10 feedbacks

        self.supervised_learning = True


    def data_preparation(self, titles, labels):
        datasets = []
        raw = []
        for title in titles:
            tupled_title = (str(title))
            datasets.append(tupled_title)
            raw.append(str(title))

        for label in labels:
            tupled_label = (str(label))
            datasets.append(tupled_label)
            raw.append(str(label))

        self.pipeline.initialize_fitting(raw)
        X_raw = self.pipeline.tfidf.transform(raw).toarray()
        X_raw = self._refit_sparse_data(X_raw, raw)

        return datasets, X_raw

    
    def draw_bar(self, value, max_width=20):
        value = max(0, min(1, value))  # Ensure value is between 0 and 1
        filled = int(value * max_width)
        return '█' * filled + '░' * (max_width - filled)

    def _learn_from_feedback(self, text, correct_label, wrong_result):
        eps = 1e-5
        print(f"\n[📚] Learning: '{text}' → {correct_label}...")
        
        # 1. Convert to features
        X_intents = self.pipeline.tfidf.transform(self.pipeline.intents).toarray()
        X_input = self.pipeline.tfidf.transform([text]).toarray()
        X_raw = np.dot(X_intents, X_input.T).T

        if np.allclose(X_raw, 0.0) or self.pipeline.anisotropy_measurement(X_raw) < 0.3 or np.isnotfinite(X_raw).any():
            checksum = int(hashlib.md5(text.encode()).hexdigest(), 16) % 1000 / 10000
            X_raw[0, 0] = checksum + eps
            
        X = X_raw.copy()
    
        try:
            print('[🔄] Verifying if similar correct_label is already in pipeline supervised memory...')

            memory_key = f'supervised_memory'
            retrieved = [key for key, (corr_label) in self.pipeline.memory.items() if key.startswith(memory_key) and correct_label == corr_label]
            if retrieved:
                for retrieve in retrieved:
                    _, correct_label = self.pipeline.memory[retrieve]

                print(f'[✅] retrieved similar correct label: {correct_label}')
                print(f'[=] This proves consistency over time necessary for gradual supervised learning loop to provide transparency')
            else:
                print('[-] No similar matching correct label')
                print('[=] This suggests that the model has never learned this previous input in supervised learning')

        except Exception as e:
            print(f'[=] Cant save to and retrieve memory due to {e} error.')

        # 2. Convert label to one-hot
        label_idx = self.pipeline.intents[correct_label] if correct_label in self.pipeline.intents else 0
        if label_idx is None:
            label_idx = len(self.pipeline.intents)
            self.pipeline.intents[correct_label] = label_idx
        
        y_onehot = np.zeros((1, len(self.pipeline.intents)))
        y_onehot[0, label_idx] = 1
        if y_onehot.shape[1] != X.shape[1]:
            if y_onehot.shape[1] < X.shape[1]:
                y_onehot = np.pad(y_onehot, ((0, 0), (0, X.shape[1] - y_onehot.shape[1])), mode='constant')
            else:
                X = np.pad(X, ((0, 0), (0, y_onehot.shape[1] - X.shape[1])), mode='constant')
        
        # 3. IMMEDIATE TRAINING (single step with higher Learning Rate)
        anisotropy = self.pipeline.anisotropy_measurement(X)

        # Derive a geometry-aware learning rate for the correction step.
        # anisotropy_dist: sigmoid of anisotropy — saturates to 1 for strongly directional data.
        # deviation:       inverse of std; near 1 when features are tightly clustered (low spread).
        # AEL (Adaptive Error Level): high when data is variable (low deviation) AND anisotropic.
        #   AEL → 1  ⟹  corrective LR = 2/(1+1) = 1.0  (fast correction on complex data)
        #   AEL → 0  ⟹  corrective LR = 2/(1+0) = 2.0  (even faster on flat/simple data)
        # This intentionally boosts the correction LR above the normal training LR so
        # a single wrong prediction can be overridden quickly without many epochs.
        anisotropy_dist = 1.0 / (1.0 + np.exp(-anisotropy))
        deviation = 1.0 / (1.0 + np.std(X))
        AEL = (1.0 - deviation) * anisotropy_dist + eps

        old_lr = self.pipeline.mlp.lr
        self.pipeline.mlp.lr = 2 / (1.0 + AEL) # use stable learning rate that match the environment complexity for correction
        print(f"[=] Training MLP on corrected example with boosted LR: {self.pipeline.mlp.lr}...")

        # Train on this single example for a few epochs
        self.pipeline.focused_mlp.train(X, y_onehot, epochs=1000, lr=self.pipeline.mlp.lr, verbose=True)
        time.sleep(5)

        self.pipeline.mlp.lr = old_lr  # Restore LR
        
        # 4. train transformer for efficient processing later tho.
        if self.pipeline.model2:
            input_ids = np.array([self.pipeline.encode(text, self.pipeline.vocab)])
            for _ in range(5):
                self.pipeline.model2.train_step(input_ids, 0, y_onehot, lr=0.1, mode='fixed_backward')
        
        # 5. Store in memory gate for fast retrieval
        self.pipeline.modular_prediction_saving(
            self.pipeline.encode(text, self.pipeline.vocab),
            X,
            correct_label
        )
        
        # 6. Add to buffer for batch consolidation later.
        self.feedback_buffer.append((X, y_onehot, text, correct_label))
        
        # 7. Batch train when buffer is full
        if len(self.feedback_buffer) >= self.buffer_size:
            print(f"\n[🔄] Buffer full with {len(self.feedback_buffer)} feedback examples. Starting batch training...")
            self._batch_train_from_feedback()
        
        print(f"[✅] Learned: '{text}' → {correct_label} (model weights updated)")

        supervised_memory = {
            'input': text,
            'label': correct_label,
            'original_prediction': wrong_result['final_label'], 
            'original_confidence': wrong_result['final_confidence'],
            'timestamp': datetime.now(),
            'learned': True

        }

        self.learned_from_feedback.append(supervised_memory)
        if hasattr(self.pipeline, 'memory'):
            print('[🔄] Applying correct label to pipelines memory')
            memory_key = f'supervised_memory'
            self.pipeline.memory[memory_key] = (X, correct_label)

        if len(self.learned_from_feedback) % 10 == 0:
            self.consolidate_supervised_memories()

        return X
    
    def _batch_train_from_feedback(self):
        if not self.feedback_buffer:
            return
        
        print(f"\n🔄 Batch training on {len(self.feedback_buffer)} feedback examples...")
        
        # Collect all feedback
        # Determine max dimensions

        max_x_dim = max(fb[0].shape[1] for fb in self.feedback_buffer)
        current_y_dim = len(self.pipeline.intents)
        
        # Collect all feedback with padding
        X_list = []
        y_list = []
        for fb in self.feedback_buffer:
            X = fb[0]
            y = fb[1]
            if X.shape[1] < max_x_dim:
                X = np.pad(X, ((0, 0), (0, max_x_dim - X.shape[1])), mode='constant')
            if y.shape[1] < current_y_dim:
                y = np.pad(y, ((0, 0), (0, current_y_dim - y.shape[1])), mode='constant')
            X_list.append(X)
            y_list.append(y)
        
        X_batch = np.vstack(X_list)
        y_batch = np.vstack(y_list)

        # Train MLP on batch
        old_lr = self.pipeline.mlp.lr
        self.pipeline.mlp.lr = old_lr * 2
        for epoch in range(20):
            y_pred = self.pipeline.mlp.forward(X_batch)
            loss = Loss.categorical_crossentropy(y_batch, y_pred)
            grad = Loss.softmax_crossentropy_derivative(y_batch, y_pred)
            self.pipeline.mlp.backward(grad, self.pipeline.mlp.lr)

        self.pipeline.mlp.lr = old_lr
        
        # Clear buffer
        self.feedback_buffer = []
        print("[✅] Batch training complete")

    
    def _ask_for_feedback(self, text, result, explanation):
        print("\n" + "="*60)
        print(f"[🤔] I'm confused about this detail: '{text}'")
        print(f"[=] I thought: {result['final_label']} ({result['final_confidence']:.1%})")
        if 'final_label' in result and 'final_confidence' in result:    
            confidence = result['final_confidence']
            bar = self.draw_bar(confidence)   
            print(f"[+] Confidence: [{bar}] {confidence:.1%}")  

        # Show top 3 predictions
        if 'details' in result and 'all_probs' in result['details']:
            probs = result['details']['all_probs']
            top3 = np.argsort(probs)[-3:][::-1]            
            print("\n[+] Top possibilities:")
            for idx in top3:
                label = self.pipeline.intents.get(idx, f"class_{idx}")
                print(f"[=]  • {label}: {probs[idx]:.1%}")
        
        print("\n[📚] Options:")
        print("  1. Enter correct label")
        print("  2. Skip")
        print("  3. Show explanation")
        print('  4. Get decision history')
        
        choice = input("\n [=] What is the correct label? (ex: break/work): ").strip()
        
        if choice.lower() == 'skip':
            return None
        elif choice.lower() == 'explain':
            print(explanation)
            return self._ask_for_feedback(text, result, explanation)
        elif choice == '4':
            history = self.get_decision_history(limit=10)  
            for entry in history:
                print(f" [?] {entry['input']} → {entry['label']}")
        elif choice:
            print('[==] Assigning Training for correct label: ')
            return choice
        return None

    def analyze_with_feedback(self, details, input_text, mlp_probs, trans_probs, attn_weights, explanation, auto_ask=True):
        uncertain = self.pipeline.confidence_threshold

        input_ids = np.array([self.pipeline.encode(input_text, self.pipeline.vocab)])
        if isinstance(input_ids, list):
            input_ids = np.array(input_ids)

        if uncertain == 0.0:
            uncertain = self.uncertainty_threshold

        is_uncertain = details['final_confidence'] < uncertain
        
        if is_uncertain and self.supervised_learning:
            feedback = self._ask_for_feedback(input_text, details, explanation)
            if feedback:
                print(f"[📚] Received feedback: '{input_text}' should be '{feedback}'")
                print('[=] Supervised learning took many trials to get right. This is normal. Please be patient as the model updates continously each label request...')

                evaluated_input = self._learn_from_feedback(input_text, feedback, details)
                self.supervised_learning = False  # Prevent infinite loop
                return False
        
        return False
    
    def consolidate_supervised_memories(self):
        if not self.learned_from_feedback:
            return
        
        print(f"\n🔄 Consolidating {len(self.learned_from_feedback)} supervised memories...")
        
        # Extract all supervised examples
        texts = [m['input'] for m in self.learned_from_feedback]
        labels = [m['label'] for m in self.learned_from_feedback]

        dataset, _ = self.data_preparation(texts, labels)

        self.initialize_fitting(labels)            
        X = self.tfidf.transform(labels).toarray()   
        X = self._refit_sparse_data(X, texts)
        self.pipeline.transformer_utilities(dataset, X)
        
        print("✅ Supervised memories consolidated!")
    
    def get_uncertain_predictions(self, result):
        uncertain = []
        if result['final_confidence'] < self.uncertainty_threshold:
            uncertain.append({
                    'text': result['input_text'],
                    'prediction': result['final_label'],
                    'confidence': result['final_confidence'],
                    'attention_quality': result['attention_quality']
            })
        
        # Sort by most uncertain first
        uncertain.sort(key=lambda x: x['confidence'])
        
        print(f"\n🔍 Found {len(uncertain)} uncertain predictions:")
        for u in uncertain[:10]:
            print(f"   • '{u['text']}' → {u['prediction']} ({u['confidence']:.1%})")
        
        return uncertain
 

    def _get_prediction_details(self, input_text, mlp_probs, trans_probs, attn_weights, lstm_result=None, batch_size=2):
        show_details = self.pipeline.show_explainability_details
        if trans_probs.ndim == 1:
            trans_probs = trans_probs.reshape(1, -1)

        trans_pred = np.argmax(trans_probs[0])
        trans_conf = trans_probs[0][trans_pred]
        
        # Handle mlp_probs - ensure it's 2D
        try:
            if mlp_probs.ndim == 1:
                mlp_probs = mlp_probs.reshape(1, -1)
            mlp_pred = np.argmax(mlp_probs)
            mlp_conf = mlp_probs[mlp_pred]
        except:
            if isinstance(mlp_probs, float):
                mlp_pred = int(mlp_probs)
                mlp_conf = 0.15
            else:
                mlp_pred = np.argmax(mlp_probs[0])
                mlp_conf = mlp_probs[0][mlp_pred]

        if isinstance(mlp_conf, np.ndarray):
            mlp_conf = np.clip(np.mean(mlp_conf), 0, 1)
        if isinstance(trans_conf, np.ndarray):
            trans_conf = np.clip(np.mean(trans_conf), 0, 1)

        reverse_map = self.pipeline.reverse_map
        
        final_pred, final_conf = self._get_final_output(
            mlp_pred, mlp_conf, trans_pred, trans_conf, attn_weights
        )
        
        # Extract attention focus
        focus_words = self._get_attention_focus(attn_weights, input_text)
        
        # Extract geometric features
        geometric_features = self._get_geometric_features(input_text)

        details = {
            'input_text': input_text,
            'final_label': reverse_map.get(final_pred, f"class_{final_pred}"),
            'final_confidence': final_conf,
            'final_class': final_pred,
            'mlp': {
                'label': reverse_map.get(mlp_pred, f"class_{mlp_pred}"),
                'confidence': mlp_conf,
                'class': mlp_pred
            },
            'transformer': {
                'label': reverse_map.get(trans_pred, f"class_{trans_pred}"),
                'confidence': trans_conf,
                'class': trans_pred,
                'attention_words': focus_words,
                'attention_weights': attn_weights
            },
            'lstm': self._get_lstm_explanation(lstm_result) if lstm_result is not None else None,
            'geometric_features': geometric_features,
            'agreement': mlp_pred == trans_pred,
            'anisotropy': self._compute_anisotropy(attn_weights) if attn_weights is not None else None,
            'attention_quality': self._compute_attention_quality(attn_weights) if attn_weights is not None else None
        }

        explanation, confidence, comparison = self._generate_explanation(details)
        
        self.decision_history.append({
            'timestamp': datetime.now(),
            'input': input_text,
            'prediction': details['final_label'],
            'confidence': details['final_confidence'],
            'explanation': explanation,
            'details': details
        })
        
        if show_details:
            self._display_explanation(explanation)
            self._display_explanation(confidence)
            self._display_explanation(comparison)
            self.get_uncertain_predictions(details)
      
            if details['final_confidence'] < 0.15 and not self.pipeline.autonomous:
                self.analyze_with_feedback(details, input_text, mlp_probs, trans_probs, attn_weights, explanation, batch_size=2)
 
        confidence = self.explain_confidence(details)
        if final_conf:
            print('[||] Final confidence set to: ', final_conf)
            self.pipeline.final_conf_score = final_conf

        return details, explanation


    def _refit_sparse_data(self, X_features, texts, threshold=0.3):
        """Refit TF-IDF if zero-row ratio exceeds threshold."""
        X_features = np.asarray(X_features, dtype=np.float32)
        if X_features.ndim == 1:
            X_features = X_features.reshape(1, -1)        
            X_features = np.asarray(X_features)
                    
        zero_rows = np.where(X_features.sum(axis=1) == 0)[0]
        zero_ratio = len(zero_rows) / len(X_features)
        
        if zero_ratio > threshold:
            print(f'[!] {len(zero_rows)} zero rows ({zero_ratio:.0%}), refitting TF-IDF on current batch')
            self.tfidf.fit(texts)
            X_features = self.tfidf.transform(texts).toarray()
            
            # second pass — fill remaining zeros with checksum fingerprint
            zero_rows = np.where(X_features.sum(axis=1) == 0)[0]
            for i in zero_rows:
                text = texts[i] if isinstance(texts[i], str) else str(texts[i])
                checksum = int(hashlib.md5(text.encode()).hexdigest(), 16)
                rng = np.random.default_rng(checksum)
                X_features[i] = rng.uniform(0.01, 0.1, size=X_features.shape[1])
                print(f'[!] Row {i} still zero after refit, checksum fallback applied')
        
        return X_features   

    def _get_lstm_explanation(self, lstm_result: dict) -> Any:
        """
        Extract readable signals from LSTMEngine.predict() output.
        lstm_result is the raw dict returned by engine.predict().
        """
        if lstm_result is None:
            return None

        mc_conf_last     = float(lstm_result['mc_confidence'][-1])
        gate_unc_last    = float(lstm_result['gate_uncertainty'][-1])
        overall          = float(lstm_result['overall'])
        interval_low     = float(lstm_result['interval_low'][-1])
        interval_high    = float(lstm_result['interval_high'][-1])
        mc_std_last      = float(lstm_result['mc_std'][-1])

        # gate stability — inverse of uncertainty, easier to read
        gate_stability   = 1.0 - gate_unc_last

        # dominant label from label_confidence if available
        label_conf       = lstm_result.get('label_confidence')
        dominant_label   = None
        dominant_prob    = 0.0
        if label_conf:
            dominant_label = max(label_conf, key=label_conf.get)
            dominant_prob  = label_conf[dominant_label]

        return {
            'mc_confidence'   : mc_conf_last,     # how tight MC dropout samples are
            'gate_stability'  : gate_stability,    # 1 = stable memory, 0 = actively overwriting
            'gate_uncertainty': gate_unc_last,     # raw gate signal
            'overall'         : overall,           # combined scalar
            'interval'        : (interval_low, interval_high),  # prediction interval
            'mc_std'          : mc_std_last,       # spread of MC samples
            'dominant_label'  : dominant_label,    # top label_bin if bins were passed
            'dominant_prob'   : dominant_prob,
            'label_confidence': label_conf
        }


    
    def _get_final_output(self, mlp_pred, mlp_conf, trans_pred, trans_conf, attn_weights):
        # Resolves the final prediction when the two models disagree.
        # When they agree, the higher-confidence model's score is taken directly.
        # When they disagree, an "Abstract Attention Transformation" (AAT) scalar
        # is computed to determine which model to trust more:
        #
        #   sliced_anisotropy — directional variation in the first attention slice;
        #                        high → attention is non-uniform / informative.
        #   deviation         — 1/(1 + std(attn_weights)); near 1 when attention is tightly
        #                        concentrated, near 0 when it is spread out.
        #   attn_quality      — overall quality score from attention_quality_computing.
        #   AAT               — deviation * (1 - sliced_anisotropy):
        #                        high when attention is concentrated (low anisotropy) AND
        #                        tightly distributed (low spread); this configuration favours
        #                        the transformer's focused contextual prediction.
        #
        # Confidence blending on disagreement:
        #   If MLP wins:         final_conf = mlp_conf * (1 - trans_conf) * (1 - AAT)
        #       → lower AAT (diffuse attention) → MLP gets more room to dominate.
        #   If Transformer wins: final_conf = trans_conf * (1 - mlp_conf) * AAT
        #       → higher AAT (focused attention) → transformer earns a larger share.
        eps = 1e-5
        if isinstance(mlp_conf, np.ndarray):
            mlp_conf = np.clip(np.mean(mlp_conf), 0, 1)
        if isinstance(trans_conf, np.ndarray):
            trans_conf = np.clip(np.mean(trans_conf), 0, 1)

        if mlp_pred == trans_pred:
            final_pred = mlp_pred
            final_conf = max(mlp_conf, trans_conf)
        else:
            sliced_attention_weight = attn_weights[0]
            if isinstance(sliced_attention_weight, np.ndarray):
                sliced_attention_weight = sliced_attention_weight[:, 0]
                sliced_attention_weight = sliced_attention_weight[0]
               
            sliced_anisotropy = self.pipeline.anisotropy_measurement(sliced_attention_weight) 
            sigmoid_growth = 1.0 / (1.0 + np.exp(-sliced_attention_weight))
            attn_quality = self._compute_attention_quality(attn_weights)

            # Abstract attention transformation
            AAT = sigmoid_growth * (1.0 - sliced_anisotropy) + eps 
            # lower AAT means transformer is less reliable because abstraction is underserved/nonoptimal in this env.
            # Higher AAT means transformer is more focused and reliable and is near optimal.

            if mlp_conf > trans_conf:
                final_pred = mlp_pred
                final_conf = mlp_conf * (1.0 - trans_conf) * (1.0 - np.mean(AAT)) + eps
            else:
                final_pred = trans_pred
                final_conf = trans_conf * (1.0 - mlp_conf) * np.mean(AAT) + eps

            print('='*50)
            print('===== ABSTRACTION LAYER ======')
            print('='*50)
            print(f'[= ABSTRACTION =] Consistency of abstraction transformation: {np.std(AAT)}')
            print(f'[= ABSTRACTION =] Attention Quality: {attn_quality}')
            print(f'[= ABSTRACTION =] Sigmoid growth of Attention weight consistency: {np.std(sigmoid_growth)}')
            print('[=] Note: Very little Consistency meaning Transformer attention quality is Healthy and focused')

        if isinstance(final_conf, np.ndarray):
            final_conf = 1.0 / (1.0 + np.std(final_conf))
            # growth deviation of arrayed final confidence helped to distinguish noise from unnecessary distribution, 
            # with real covariance of distribution from the data.

        if np.isnan(final_conf).any() or np.isinf(final_conf).any():
            final_conf = self.pipeline.confidence_threshold

        return final_pred, final_conf
    
    def _get_attention_focus(self, attn_weights, text):
        # get focus of attention words in transformer
        if attn_weights is None or len(attn_weights) == 0:
            return text.split()[:3]
        
        words = text.lower().split()
        attn = attn_weights[0].mean(axis=0) if len(attn_weights[0].shape) > 1 else attn_weights[0]
        top_indices = np.argsort(attn)[-3:][::-1]
        if attn.ndim > 1:
            attn = attn.flatten()

        # top most focused words
        top_indices = np.argsort(attn)[-3:][::-1]
        
        focus_words = []
        for idx in top_indices:
            if hasattr(idx, 'item'):
                idx = idx.item()
            
            if isinstance(idx, (int, np.integer)) and idx >= 0 and idx < len(words):
                focus_words.append(words[idx])
        
        return focus_words if focus_words else words[:3]
    
    def _get_geometric_features(self, text):
        # get geometric features of MLP and transformer to explain its decisions.
        X_tfidf = self.pipeline.tfidf.transform([text]).toarray()
        
        if hasattr(self.pipeline, 'geometric_shaping'):
            anisotropy = self.pipeline.model2.geometric_shaping.anisotropy_measurement(X_tfidf)
            ame = self.pipeline.model2.geometric_shaping.AME_Encoder(X_tfidf)
        else:
            # Fallback: compute simple statistics
            anisotropy = np.std(X_tfidf) / (np.mean(X_tfidf) + 1e-8)
            ame = self.AME_Encoder(X_tfidf)
     
        # Extract dominant features
        feature_names = self.pipeline.tfidf.get_feature_names_out()
        non_zero = X_tfidf[0] > 0
        dominant_features = [feature_names[i] for i in np.where(non_zero)[0][:3]]
        
        return {
            'anisotropy': float(anisotropy),
            'AME': float(ame),
            'dominant_features': dominant_features,
            'feature_energy': float(np.sum(X_tfidf ** 2))
        }
    
    def AME_Encoder(self, x):
        # function that calculates abstract modelling rate
        X = np.asarray(x)

        try:
            gradient = np.gradient(x, axis=-1)
        except:
            subset = x[:]
            gradient = np.gradient(subset)

        grad_energy = np.mean(np.linalg.norm(gradient, axis=-1))       
        X_mag = np.mean(np.linalg.norm(X, axis=-1))
        AME = np.log1p(X_mag) * np.log1p(grad_energy) 

        return AME

    def _compute_anisotropy(self, attn_weights):
        # function to compute anisotropy
        if attn_weights is None or len(attn_weights) == 0:
            return 0.5
        
        try:
    
            if hasattr(self.pipeline, 'anisotropy_measurement'):
                return self.pipeline.anisotropy_measurement(attn_weights.flatten())
            
            # Fallback calculation
            attn_flat = attn_weights.flatten()
            gradient = np.gradient(attn_flat)
            val = [np.linalg.norm(v) for v in gradient]
            return np.std(val) / (np.mean(val) + 1e-8)

        except:
            return 0.5
    
    def _compute_attention_quality(self, attn_weights):
        eps = 1e-5
        if attn_weights is None or len(attn_weights) == 0:
            return 0.5
        
        try:

            if hasattr(self.pipeline.model2, 'attention_quality_computing'):
                return self.pipeline.model2.attention_quality_computing(attn_weights)
            
            # Fallback calculation
            eps = 1e-5
            batch, heads, seq_len, _ = attn_weights.shape
            
            entropy = -np.sum(attn_weights * np.log(attn_weights + eps), axis=-1)
            max_entropy = np.log(seq_len)
            norm_entropy = 1.0 - (np.mean(entropy) / max_entropy)
            
            max_attn = np.max(attn_weights, axis=-1)
            avg_max = np.mean(max_attn)
            
            var_attn = np.var(attn_weights)
            norm_var = np.clip(var_attn * seq_len, 0, 1)
            
            AME = self.AME_Encoder(attn_weights)
            AMR = 1.0 / (1.0 + np.exp(-AME) + eps)

            quality = norm_entropy * (1.0 - AMR) + avg_max * AMR + norm_var * AMR
            return np.clip(quality, 0, 1)
        except:
            print("[-] Error occurred while computing attention quality.")
            AMR = 0.1
            if attn_weights is not None:
                print(f"[-] Attention weights shape: {attn_weights.shape}")
                AME = self.AME_Encoder(attn_weights)
                AMR = 1.0 / (1.0 + np.exp(-AME) + eps)            
            return AMR
    
    def _generate_explanation(self, details):
        parts = []
        
        # Final decision
        parts.append(f"📌 Decision: I think my prediction is: **{details['final_label']}**")
        parts.append(f"[=] Confidence Degree: {details['final_confidence']}\n")
        
        # MLP's geometric reasoning
        parts.append("🧠 Geometric MLP Reasoning:")
        parts.append(f"   • Detected Detail: {', '.join(details['geometric_features']['dominant_features'][:3])}")
        parts.append(f"   • Geometric complexity signature: {details['geometric_features']['anisotropy']:.3f}")
        parts.append(f"   • Energy: signature {details['geometric_features']['feature_energy']:.3f}")
        parts.append(f"   • Confidence Focus: {details['mlp']['confidence']:.1%} to → {details['mlp']['label']}")

        if details.get('lstm') is not None:
            lstm = details['lstm']
            parts.append("\n⏳ LSTM Memory Reasoning:")
            parts.append(f"   • MC Dropout Confidence: {lstm['mc_confidence']:.1%} "
                        f"(spread: ±{lstm['mc_std']:.4f})")
            parts.append(f"   • Gate Stability: {lstm['gate_stability']:.1%} "
                        f"({'stable memory' if lstm['gate_stability'] > 0.6 else 'actively rewriting memory — uncertain transition'})")
            parts.append(f"   • Prediction Interval: [{lstm['interval'][0]:.4f}, {lstm['interval'][1]:.4f}]")
            parts.append(f"   • Overall LSTM Confidence: {lstm['overall']:.1%}")
            if lstm['dominant_label']:
                parts.append(f"   • Strongest Sequence Signal: {lstm['dominant_label']} "
                            f"({lstm['dominant_prob']:.1%})") 

        # Transformer's contextual reasoning
        if self.pipeline.use_transformer:
            parts.append("\n🌀 Transformer Reasoning:")
            if details['transformer']['attention_words']:
                parts.append(f"   • Focused on: '{', '.join(details['transformer']['attention_words'])}'")
            parts.append(f"   • Attention quality: {details.get('attention_quality', 0.5)}")
            parts.append(f"   • Attention anisotropy: {details.get('anisotropy', 0.5):.3f}")
            parts.append(f"   • Confidence Focus: {details['transformer']['confidence']:.1%} to → {details['transformer']['label']}")

        # Agreement analysis
        lstm = details.get('lstm')
        if details['agreement']:
            parts.append("\n✅ Models Agreed:")
            parts.append("   Both geometric and contextual analysis point to the same conclusion")
            if lstm and lstm['gate_stability'] > 0.6:
                parts.append("[=+=] LSTM memory is stable — sequence history supports this decision")
            else:
                parts.append("[!] LSTM Uncertain - Sequence history does not supports this decision")
        else:
            if self.pipeline.use_transformer:
                parts.append("\n⚠️ Models Disagreed:")
                parts.append(f"   Geometric MLP Focusing on → {details['mlp']['label']} detail")
                parts.append(f"   Transformer Focusing on → {details['transformer']['label']} detail")
                if lstm:
                    stability_note = "reinforces" if lstm['gate_stability'] > 0.6 else "is uncertain about"
                    parts.append(f"   LSTM {stability_note} the sequence context "
                                f"(gate stability: {lstm['gate_stability']:.1%})")
                parts.append(f"   I weighted them with {details['final_confidence']:.1%} "
                            f"confident in {details['final_label']}")                
            else:
                parts.append("🌀 Supporting Argument From LSTM:")
                if lstm:
                    stability_note = "reinforces" if lstm['gate_stability'] > 0.6 else "is uncertain about"
                    parts.append(f"   LSTM {stability_note} the sequence context "
                                f"(gate stability: {lstm['gate_stability']:.1%})")                
                parts.append(f"   Geometric MLP Focusing on → {details['mlp']['label']} detail")
                parts.append(f"   I weighted them with {details['final_confidence']:.1%} confident in {details['final_label']}")

        # 5. Uncertainty assessment
        if details['final_confidence'] < 0.6:
            parts.append("\n🤔 Uncertainty Note:")
            parts.append(f"   I'm not very confident about this prediction || Confidence: {details['final_confidence']}")
            parts.append("   • This pattern is unusual in my training data")
            parts.append("   • More same examples would help me learn enough pattern")
        
        # 6. Geometric signature 
        parts.append("\n🔬 Geometric Signature:")
        parts.append(f"   • AME Signature: {details['geometric_features']['AME']:.4f}")
        parts.append(f"   • Anisotropy Signature: {details['geometric_features']['anisotropy']:.4f}")

        confidence = self.explain_confidence(details) 
        comparison = self.compare_decisions() 

        return '\n'.join(parts), confidence, comparison
    

    def _display_explanation(self, explanation):
        print("\n" + "="*80)
        print("🤖 AI EXPLANATION")
        print("="*80)
        print(explanation)
        print("="*80)
        pass
    
    def explain_decision(self, idx=-1):
        if abs(idx) <= len(self.decision_history):
            return self.decision_history[idx]['explanation']
        return "Decision not found"
    
    def compare_decisions(self, idx1=-1, idx2=-2):
        if len(self.decision_history) < 2:
            return "Need at least two decisions to compare"
        
        comparison = []
        d1 = self.decision_history[idx1]
        d2 = self.decision_history[idx2]
        
        comparison.append(f"🔄 Decision Comparison")
        comparison.append("====================================")
        
        comparison.append("[<] Earlier Decision:")
        comparison.append(f"[+] Input: {d1['input']}")
        comparison.append(f"[+] Detail Focus: {d1['prediction']} ({d1['confidence']:.1%})")
        
        comparison.append("🧠 Later Decision:")
        comparison.append(f"[=] Input: {d2['input']}")
        comparison.append(f"[=] Detail Focus: {d2['prediction']} ({d2['confidence']:.1%})")
        
        comparison.append("🔬 Learning Progress: ")
        comparison.append(f"• Confidence {'increased' if d2['confidence'] > d1['confidence'] else 'decreased'} from {d1['confidence']} to {d2['confidence']}")
        comparison.append(f"• The model is becoming {'more' if d2['confidence'] > d1['confidence'] else 'less'} certain")
        
        return '\n'.join(comparison)
    
    def explain_confidence(self, details):

        factors = []
        
        # Check MLP confidence
        if details['mlp']['confidence'] > 0.8:
            factors.append(f"✅ MLP is very confident ({details['mlp']['confidence']:.1%}) due to strong geometric patterns")
        elif details['mlp']['confidence'] < 0.5:
            factors.append(f"🤔 MLP is uncertain ({details['mlp']['confidence']:.1%}) due to ambiguous geometric patterns")
        
        # Check transformer confidence
        if details['transformer']['confidence'] > 0.8:
            factors.append(f"✅ Transformer is confident ({details['transformer']['confidence']}) with focused attention")
        elif details['transformer']['confidence'] < 0.5:
            factors.append(f"🤔 Transformer is uncertain ({details['transformer']['confidence']}) due to scattered attention")
        
        # Check agreement
        if details['agreement']:
            factors.append("[✅] Both Models agree, reinforcing confidence")
        else:
            factors.append("[⚠️] Both Models disagree, reducing overall confidence")
        
        # Attention quality
        if details.get('attention_quality', 0) > 0.7:
            factors.append(f"[✅] High attention quality ({details['attention_quality']}) indicates clear consistent patterns!")
        elif details.get('attention_quality', 0) < 0.3:
            factors.append(f"[-] Low Attention Quality! : ({details['attention_quality']}) Indicates noisy unnecessary patterns on seen data!")
        
        return '\n'.join(factors)
    
    def get_decision_history(self, limit=10):
        history = []
        for i, dec in enumerate(self.decision_history[-limit:]):
            history.append({
                'id': i,
                'timestamp': dec['timestamp'],
                'input': dec['input'],
                'prediction': dec['prediction'],
                'confidence': dec['confidence']
            })

            print('=== DECISION HISTORY REPORT ===')
            print(f'[=] ID: {history['id']}')
            print(f'[=] Timestamp: {history['timestamp']}')
            print(f'[=] Processed Input: {history['input']}')
            print(f'[=] Prediction: {history['prediction']}')
            print(f'[=] Confidence: {history['confidence']}')

        return history

# Model storage module that handles saving and loading of trained models, their versions, and associated metadata to a database for persistence and future retrieval.
class ModelStorage:
    '''
    SQLite-backed persistence layer for all model artefacts.

    Database tables
    ---------------
    model_storage      : MLP and pipeline weights stored as JSON strings.
    model_attn_storage : Transformer attention weights (JSON).
    node_storage       : QueryNode registry entries (JSON).
    agent_attn_storage : Per-agent attention snapshots and prediction targets.

    Versioning pattern (active-record)
    ------------------------------------
    Every save() inserts a new row marked is_active=1 and immediately sets
    is_active=0 on all older rows for the same memory_name.  Reads always
    query WHERE is_active=1, so only the most recent save is "live".
    This gives a simple append-only audit trail while keeping reads O(1).

    Numpy serialisation
    -------------------
    Numpy arrays are recursively converted to Python lists via
    _prepare_for_serialization() before json.dumps, and converted back via
    _convert_to_arrays() on load.  This avoids the need for pickle in the JSON
    tables, making stored data human-inspectable.

    EXE / frozen-app support
    ------------------------
    get_database_path() detects whether the process is a PyInstaller bundle
    (sys.frozen) and adjusts the DB path to sys._MEIPASS accordingly.

    Parameters
    ----------
    memory_name : Logical name used to scope all read/write operations.
    db_path     : SQLite file path (default: 'activity_log.db').
    '''
    def __init__(self, pipeline, memory_name, db_path='activity_log.db'):
        self.pipeline = pipeline        
        self.db_path = db_path

        self.setup_storage_table()
        self.setup_explainable_table()
        self.setup_agent_table()
        self.setup_node_table()
        self.setup_weight_table()

        self.memory_name = memory_name

        if not self.memory_exists(self.memory_name, type='Peer'):
            self.id_history = []
        else:
            print(f'|| Found Matched ID from memory: {self.memory_name}!')
            self.id_history = self.load_agent_id(self.memory_name)

    def get_database_path(self):
        db_filename= self.db_path
        if getattr(sys, 'frozen', False):
            application_path = sys._MEIPASS
            print(f"Running as EXE, temp path: {application_path}")
        else:
            application_path = os.path.dirname(os.path.abspath(__file__))
            print(f"Running as script, path: {application_path}")
    
        db_path = os.path.join(application_path, db_filename)
        print(f"Looking for database at: {db_path}")
        print(f"Database exists: {os.path.exists(db_path)}")
    
        return db_path

    def setup_explainable_table(self):
        try:
            try:
                db_path = self.get_database_path()            
                conn = sqlite3.connect(db_path)
            except:
                conn = sqlite3.connect(self.db_path)

            c = conn.cursor()
    
            c.execute('''CREATE TABLE IF NOT EXISTS model_attn_storage
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      memory_name TEXT,
                      model_type TEXT,
                      model_data TEXT,
                      is_active INTEGER DEFAULT 0,                      
                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        
            conn.commit()
            conn.close()
            print('|| Update Attention Saved to database! ')

        except Exception as e:
            print(f'|| Cant Update Database: {e}')
            filepath = input('|| Insert Database filepath: ')
            if filepath:
                conn = sqlite3.connect(filepath)
            else:
                print('|| Skipping Database Modification...')
                pass
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS model_attn_storage
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      memory_name TEXT,
                      model_type TEXT,
                      model_data TEXT,
                      is_active INTEGER DEFAULT 0,
                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        
            conn.commit()
            conn.close()



    def setup_storage_table(self):
        try:
            try:
                db_path = self.get_database_path()            
                conn = sqlite3.connect(db_path)
            except:
                conn = sqlite3.connect(self.db_path)

            c = conn.cursor()
    
            c.execute('''CREATE TABLE IF NOT EXISTS model_storage
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      memory_name TEXT,
                      model_version TEXT,
                      model_type TEXT,
                      model_data TEXT,  -- JSON string for dict
                      model_binary BLOB,  -- For pickle files
                      trained_on TEXT,
                      metadata TEXT,  -- JSON for extra info
                      is_active INTEGER DEFAULT 0,
                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        
            conn.commit()
            conn.close()
            print('|| Update Saved to database! ')

        except Exception as e:
            print(f'|| Cant Update Database: {e}')
            filepath = input('|| Insert Database filepath: ')
            if filepath:
                conn = sqlite3.connect(filepath)
            else:
                print('|| Skipping Database Modification...')
                pass
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS model_storage
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      memory_name TEXT,
                      model_version TEXT,
                      model_type TEXT,
                      model_data TEXT,  -- JSON string for dict
                      model_binary BLOB,  -- For pickle files
                      trained_on TEXT,
                      metadata TEXT,  -- JSON for extra info
                      is_active INTEGER DEFAULT 0,
                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        
            conn.commit()
            conn.close()

    def get_database_path(self):
        db_filename= self.db_path
        if getattr(sys, 'frozen', False):
            application_path = sys._MEIPASS
            print(f"Running as EXE, temp path: {application_path}")
        else:
            application_path = os.path.dirname(os.path.abspath(__file__))
            print(f"Running as script, path: {application_path}")
    
        db_path = os.path.join(application_path, db_filename)
        print(f"Looking for database at: {db_path}")
        print(f"Database exists: {os.path.exists(db_path)}")
    
        return db_path

    def setup_explainable_table(self):
        try:
            try:
                db_path = self.get_database_path()            
                conn = sqlite3.connect(db_path)
            except:
                conn = sqlite3.connect(self.db_path)

            c = conn.cursor()
    
            c.execute('''CREATE TABLE IF NOT EXISTS model_attn_storage
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      memory_name TEXT,
                      model_type TEXT,
                      model_data TEXT,
                      is_active INTEGER DEFAULT 0,                      
                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        
            conn.commit()
            conn.close()
            print('|| Update Attention Saved to database! ')

        except Exception as e:
            print(f'|| Cant Update Database: {e}')
            filepath = input('|| Insert Database filepath: ')
            if filepath:
                conn = sqlite3.connect(filepath)
            else:
                print('|| Skipping Database Modification...')
                pass
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS model_attn_storage
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      memory_name TEXT,
                      model_type TEXT,
                      model_data TEXT,
                      is_active INTEGER DEFAULT 0,
                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        
            conn.commit()
            conn.close()

    def setup_node_table(self):
        try:
            try:
                db_path = self.get_database_path()            
                conn = sqlite3.connect(db_path)
            except:
                conn = sqlite3.connect(self.db_path)

            c = conn.cursor()
    
            c.execute('''CREATE TABLE IF NOT EXISTS node_storage
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      memory_name TEXT,
                      model_type TEXT,
                      node_data TEXT,
                      node_id TEXT,
                      is_active INTEGER DEFAULT 0,                      
                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        
            conn.commit()
            conn.close()
            print('|| Update Node Saved to database! ')

        except Exception as e:
            print(f'|| Cant Update Database: {e}')
            filepath = input('|| Insert Database filepath: ')
            if filepath:
                conn = sqlite3.connect(filepath)
            else:
                print('|| Skipping Database Modification...')
                pass
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS node_storage
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      memory_name TEXT,
                      model_type TEXT,
                      node_data TEXT,
                      node_id TEXT,
                      is_active INTEGER DEFAULT 0,
                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        
            conn.commit()
            conn.close()


    def setup_agent_table(self):
        try:
            try:
                db_path = self.get_database_path()            
                conn = sqlite3.connect(db_path)
            except:
                conn = sqlite3.connect(self.db_path)

            c = conn.cursor()
    
            c.execute('''CREATE TABLE IF NOT EXISTS agent_attn_storage
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      memory_name TEXT,
                      model_type TEXT,
                      model_attn_data TEXT,
                      model_target_pred TEXT,
                      agent_id TEXT,
                      is_active INTEGER DEFAULT 0,
                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''') 
        
            conn.commit()
            conn.close()
            print('|| Update Agent Saved to database! ')

        except Exception as e:
            print(f'|| Cant Update Database: {e}')
            filepath = input('|| Insert Database filepath: ')
            if filepath:
                conn = sqlite3.connect(filepath)
            else:
                print('|| Skipping Database Modification...')
                pass
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS agent_attn_storage
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      memory_name TEXT,
                      model_type TEXT,
                      model_attn_data TEXT,
                      model_target_pred TEXT,
                      agent_id TEXT,
                      is_active INTEGER DEFAULT 0,
                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        
        
            conn.commit()
            conn.close()


    def save_model_dict(self, memory_name, model_dict, type=None, model_type='mlp'):
        # Persists a model's in-memory dict to SQLite using an "active record" versioning
        # pattern: each save inserts a new row marked is_active=1, then immediately
        # deactivates all other rows for the same memory_name via a secondary UPDATE.
        # This means only the most recent save is "live" — reads always fetch is_active=1.
        #
        # Two destination tables depending on the `type` argument:
        #   type == 'Transformer' → model_attn_storage  (stores attention-related weights)
        #   else                  → model_storage        (stores MLP / pipeline weights)
        #
        # numpy arrays inside model_dict are recursively converted to Python lists
        # by _prepare_for_serialization() before json.dumps, ensuring they round-trip
        # correctly when loaded back via _convert_to_arrays().
        try:
            db_path = self.get_database_path()            
            conn = sqlite3.connect(db_path)
        except:
            conn = sqlite3.connect(self.db_path)
                    
        c = conn.cursor()

        serializable_dict = self._prepare_for_serialization(model_dict)
        model_json = json.dumps(serializable_dict, default=str)
        if type == 'Transformer':
            try:
                c.execute("""
                    INSERT INTO model_attn_storage 
                    (memory_name, model_type, model_data, is_active)
                    VALUES (?, ?, ?, ?)
                """, (memory_name, model_type, model_json, 1))
        
                # Deactivate all other rows for this memory_name (soft-delete old versions).
                c.execute("""
                    UPDATE model_attn_storage 
                    SET is_active = 0 
                    WHERE memory_name = ? AND id != last_insert_rowid()
                """, (memory_name,))

            except Exception as e:
                print(f'[-] Cant save model memory due to: {e}') 
                pass             
        else:
            try:
                c.execute("""
                    INSERT INTO model_storage
                    (memory_name, model_type, model_data, is_active)
                    VALUES (?, ?, ?, ?)
                """, (memory_name, model_type, model_json, 1))
        
                # Deactivate all other rows for this memory_name (soft-delete old versions).
                c.execute("""
                    UPDATE model_storage 
                    SET is_active = 0 
                    WHERE memory_name = ? AND id != last_insert_rowid()
                """, (memory_name,)) 

            except Exception as e:
                print(f'[-] Cant save model memory due to: {e}') 
                pass          
        
        conn.commit()
        model_id = c.lastrowid        
        conn.close()
        
        print(f"✅ Memory '{memory_name}' saved as dict (ID: {model_id})")
        return model_id

    def _prepare_for_serialization(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, dict):
            return {k: self._prepare_for_serialization(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple)):
            return [self._prepare_for_serialization(item) for item in obj]
        return obj


    def _convert_to_arrays(self, data):
        """
        Recursively convert data to numpy arrays where possible.
        Safe for ARM64 and handles all data types.
        """
        if data is None:
            return None
        
        if isinstance(data, dict):
            result = {}
            for key, value in data.items():
                converted = self._convert_value(value)
                if converted is not None:
                    result[key] = converted
            return result
        
        elif isinstance(data, (list, tuple)):
            return [self._convert_value(item) for item in data]
        
        else:
            return self._convert_value(data)

    def setup_weight_table(self):
        # function that handles lstm weights
        try:
            try:
                db_path = self.get_database_path()            
                conn = sqlite3.connect(db_path)
            except:
                conn = sqlite3.connect(self.db_path)

            c = conn.cursor()
    
            c.execute('''CREATE TABLE IF NOT EXISTS weight_storage
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      memory_name TEXT,
                      model_type TEXT,
                      weights TEXT,
                      is_active INTEGER DEFAULT 0,
                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''') 
        
            conn.commit()
            conn.close()
            print('|| Update Agent Saved to database! ')

        except Exception as e:
            print(f'|| Cant Update Database: {e}')
            filepath = input('|| Insert Database filepath: ')
            if filepath:
                conn = sqlite3.connect(filepath)
            else:
                print('|| Skipping Database Modification...')
                pass
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS weight_storage
                      (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      memory_name TEXT,
                      model_type TEXT,
                      weights TEXT,
                      is_active INTEGER DEFAULT 0,
                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''') 
        
        
            conn.commit()
            conn.close()


    def _convert_value(self, value):
        """
        Convert a single value to appropriate type.
        Returns original value if conversion fails.
        """
        if value is None:
            return None
        
        # Already numpy array - keep as is
        if isinstance(value, np.ndarray):
            return value
        
        # Handle lists recursively
        if isinstance(value, (list, tuple)):
            return [self._convert_value(item) for item in value]
        
        # Handle dicts recursively
        if isinstance(value, dict):
            return self._convert_to_arrays(value)
        
        # Handle string that might represent an array
        if isinstance(value, str):
            return self._parse_array_string(value)
        
        # Return as-is for other types (int, float, bool, etc.)
        return value


    def _parse_array_string(self, s):
        # Attempts to recover a numpy array from a string representation that may have
        # been serialised in one of several formats (JSON, Python literal, space-separated,
        # or comma-separated).  This is necessary because model weights and probability
        # vectors are stored in SQLite as JSON strings and must be reconstructed precisely.
        #
        # Strategy order (first success wins):
        #   1. JSON array  — handles standard serialisation from json.dumps.
        #   2. ast.literal_eval — handles Python repr output, e.g. "[0.1, 0.2, ...]".
        #   3. Space/bracket-separated floats — covers numpy __str__ output like
        #      "[ 0.1  0.2  0.3]" (spaces instead of commas, optional brackets).
        #   4. Comma-separated floats — fallback for CSV-style strings.
        #
        # Returns the original string unchanged if all strategies fail, letting the
        # caller handle the type mismatch rather than silently producing garbage data.
        if not isinstance(s, str) or not s:
            return s
        
        # Normalise whitespace before parsing — strip newlines, tabs, collapse spaces.
        s = s.replace('\n', '').replace('\r', '').replace('\t', '')
        s = ' '.join(s.split()).strip()
        
        if not s:
            return s
        
        # parsing as JSON array first
        if s.startswith('[') and s.endswith(']'):
            try:
                parsed = json.loads(s)
                if isinstance(parsed, list):
                    return np.array(parsed, dtype=np.float32)
            except (json.JSONDecodeError, ValueError):
                pass
            
            # Try parsing with ast.literal_eval
            try:
                parsed = ast.literal_eval(s)
                if isinstance(parsed, (list, tuple)):
                    return np.array(parsed, dtype=np.float32)
            except (ValueError, SyntaxError, TypeError):
                pass
        
        # parsing space-separated numbers
        if re.fullmatch(r'[\[\]\s\d\.\,\-\+E]+', s):        
            parts = s.replace('[', ' ').replace(']', ' ').split()
            if parts:
                try:
                    float_values = [float(x) for x in parts]
                    return np.array(float_values, dtype=np.float32)
                except ValueError:
                    pass
        
        # Handle comma-separated values
        if ',' in s:
            cleaned = s.replace('[', '').replace(']', '').strip()
            parts = [p.strip() for p in cleaned.split(',') if p.strip()]
            try:
                float_values = [float(x) for x in parts]
                return np.array(float_values, dtype=np.float32)
            except ValueError:
                pass
        
        # Return original string if nothing worked
        return s


    def _convertables_utility(self, memory_name, data, data2, type_func=None, verbose=False):
        """
        Convert and display memory data safely.
        Returns tuple (result, result2) always for consistent return type.
        """
        name = memory_name
        
        # Initialize results
        result = None
        result2 = None
        
        # Convert data based on type_func
        if type_func == "TwoPass" and data2 is not None:
            print('|| Two pass utility converting.')
            result = self._convert_to_arrays(data)
            result2 = self._convert_to_arrays(data2)
        else:
            result = self._convert_to_arrays(data)
        
        # Verify result is a dictionary before calling .items()
        if verbose and result is not None:
            print(f"Retrieved memory: {name}")
            
            # ✅ SAFE: Check if result is a dict before iterating
            if isinstance(result, dict):
                for key, value in result.items():
                    self._print_memory_value(key, value)
            else:
                print(f"  Result is not a dict: {type(result)}")
                print(f"  Result length: {len(result) if hasattr(result, '__len__') else 'N/A'}")
        
        # Handle TwoPass verbose output
        if verbose and data2 is not None and result2 is not None:
            print(f"Retrieved secondary memory: {name}_secondary")
            if isinstance(result2, dict):
                for key, value in result2.items():
                    self._print_memory_value(key, value)
            else:
                print(f"  Secondary result is not a dict: {type(result2)}")
        
        # ✅ ALWAYS return consistent types
        if data2 is not None:
            return result, result2
        else:
            return result


    def _print_memory_value(self, key, value):
        # Helper method to print memory values safely
        if isinstance(value, list):
            print(f"  {key}: list of {len(value)} items")
            for i, v in enumerate(value[:5]):  # Limit to first 5 items
                if isinstance(v, np.ndarray):
                    print(f"    [{i}]: array shape {v.shape}")
                else:
                    print(f"    [{i}]: {type(v)}")
            if len(value) > 5:
                print(f"    ... and {len(value) - 5} more items")
        
        elif isinstance(value, np.ndarray):
            print(f"  {key}: array shape {value.shape}, dtype={value.dtype}")
        
        elif isinstance(value, dict):
            print(f"  {key}: dict with {len(value)} keys")
        
        else:
            print(f"  {key}: {type(value)}")

    def memory_retrieval(self, memory_name=None, type_func=None, verbose=False):  
        name = memory_name

        if type_func == 'Transformer':
            data = self.load_transformer_dict(name)
        elif type_func == 'Peer':
            id_history = self.id_history
          
            first_data, second_data = self.load_peer_request_dict(name, id_history) 
            result, result2 = self._convertables_utility(name, first_data, second_data, type_func='TwoPass', verbose=verbose)
            return result, result2
        elif type_func == 'Node':
            data = self._load_node_dict(name)            
        else:
            data = self.load_model_dict(name)
        
        if data is None:
            print(f"[-] No memory found: {name}")
            return {}

        result = self._convertables_utility(name, data, None, type_func=type_func, verbose=verbose)

        return result

    def _load_node_dict(self, memory_name):
        try:
            try:
                db_path = self.get_database_path()            
                conn = sqlite3.connect(db_path)
            except:
                conn = sqlite3.connect(self.db_path)

            c = conn.cursor()
        
            c.execute("""
            SELECT node_data FROM node_storage 
            WHERE memory_name = ? AND is_active = 1
            """, (memory_name,))
        
            result = c.fetchone()
            conn.close()
        
            if result:
                return json.loads(result[0])
        except Exception as e:
            print(f'Error handling node dict: {e}')
        return None

    def save_nodes_dict(self, memory_name, node_memory, node_id, model_type='Node'):
        try:
            db_path = self.get_database_path()
            conn = sqlite3.connect(db_path)
        except:
            conn = sqlite3.connect(self.db_path)

        c = conn.cursor()

        node_json = json.dumps(node_memory, default=str)

        try:
            c.execute("""
                INSERT INTO node_storage 
                (memory_name, model_type, node_data, node_id, is_active)
                VALUES (?, ?, ?, ?, ?)
            """, (memory_name, model_type, node_json, node_id, 1))
        
            c.execute("""
                UPDATE node_storage 
                SET is_active = 0 
                WHERE memory_name = ? AND id != last_insert_rowid()
            """, (memory_name,)) 

            conn.commit()
            conn.close()

            print('[||] Node data dictionary saved!')

        except Exception as e:
            print(f'[-] Cant save Node memory due to: {e}')
            pass        



    def load_transformer_dict(self, memory_name):
        try:
            try:
                conn = sqlite3.connect(self.db_path)
            except:
                db_path = self.get_database_path()
                conn = sqlite3.connect(db_path)   
                     
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
        
            c.execute("""
            SELECT model_data FROM model_attn_storage 
            WHERE memory_name = ? AND is_active = 1
            """, (memory_name,))
        
            result = c.fetchone()
            conn.close()
        
            if result:
                return json.loads(result[0])
        except Exception as e:
            print(f'[!] Error handling attention dict: {e}')

        return None   

    def _load_weights(self, memory_name, type=None):
        try:
            try:
                db_path = self.get_database_path()            
                conn = sqlite3.connect(db_path)
            except:
                conn = sqlite3.connect(self.db_path)

            c = conn.cursor()
 
            c.execute("""
            SELECT weights FROM weight_storage 
            WHERE memory_name = ? AND is_active = 1
            """, (memory_name,))               
        
            result = c.fetchone()
            conn.close()
        
            if result:
                return json.loads(result[0])
        except Exception as e:
            print(f'[!] Error handling Weight dict: {e}')
        return None


    def weight_retrieval(self, memory_name=None, type=None, verbose=False):  
        name = memory_name

        data = self._load_weights(memory_name, type=type)
        if data is None:
            print(f"[-] No Saved Weight found: {name}")
            return None

        result = self._convertables_utility(name, data, None, type_func='firstpass', verbose=verbose)

        return result       


    def save_peer_needs_dict(self, memory_name, model_dict, target_pred, agent_id, model_type='Pipeline'):
        try:
            db_path = self.get_database_path()
            conn = sqlite3.connect(db_path)
        except:
            conn = sqlite3.connect(self.db_path)

        c = conn.cursor()

        model_json = json.dumps(model_dict, default=str)
        target_json = json.dumps(target_pred, default=str)
        agent_id_converted = json.dumps(agent_id, default=str)

        try:
            c.execute("""
                INSERT INTO agent_attn_storage 
                (memory_name, model_type, model_attn_data, model_target_pred, agent_id, is_active)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (memory_name, model_type, model_json, target_json, agent_id_converted, 1))
        
            c.execute("""
                UPDATE agent_attn_storage 
                SET is_active = 0 
                WHERE memory_name = ? AND id != last_insert_rowid()
            """, (memory_name,)) 

            conn.commit()
            conn.close()

            print('|| Peer data Needs dictionary saved!')

        except Exception as e:
            print(f'[-] Cant save model memory due to: {e}') 
            pass        

    def load_peer_request_dict(self, memory_name, agent_id):
        # Retrieves a peer agent's stored prediction request from agent_attn_storage,
        # excluding rows whose agent_id matches any ID in the provided list.
        # The exclusion prevents an agent from retrieving its own previously stored
        # request, ensuring it only receives data from *other* agents in the network.
        #
        # The IN clause is constructed dynamically with one '?' placeholder per agent_id
        # entry, which is safe against SQL injection via parameterised queries.
        # Returns (model_attn_data, model_target_pred) parsed from JSON, or (None, None).
        print(f'|| Peer request with Agent')
        try:
            try:
                db_path = self.get_database_path()
                conn = sqlite3.connect(db_path)   
            except:
                conn = sqlite3.connect(self.db_path)

            c = conn.cursor()
            placeholders = ",".join(["?"] * len(agent_id))

            query = f"""
            SELECT model_attn_data, model_target_pred FROM agent_attn_storage 
            WHERE memory_name = ? AND is_active = 1 AND agent_id NOT IN ({placeholders})
            """
            params = [memory_name] + agent_id
        
            c.execute(query, params)  
        
            result = c.fetchone()
            conn.close()
            print(f"|| Retrieved Peer Request memory: {memory_name} for agent_id: {agent_id}: result: {result}")
 
            if result:
                return json.loads(result[0]), json.loads(result[1])
            return None, None
        except Exception as e:
            print(f'|| Cant load peer request memory due to: {e}') 
            return None, None  


    def load_model_dict(self, memory_name):
        try:
            try:
                conn = sqlite3.connect(self.db_path)
            except:
               db_path = self.get_database_path()
               conn = sqlite3.connect(db_path)  
            c = conn.cursor()
        
            c.execute("""
            SELECT model_data FROM model_storage 
            WHERE memory_name = ? AND is_active = 1
            """, (memory_name,))
        
            result = c.fetchone()
            conn.close()
        
            if result:
                data = json.loads(result[0])
                data = self._validate_and_repair(data)
        except Exception as e:
            print(f'Error handling model dict: {e}')
        return None
        
    def _validate_and_repair(self, data):
        """Validate loaded data and repair if corrupted"""
        
        # If data is an array with wrong shape
        if isinstance(data, list) and len(data) > 0:
            # Check if it's a probability array
            if len(data) != self.pipeline._get_num_classes():  
                print(f'[!] Detected corrupted memory with shape {len(data)}, repairing...')
                # Return empty dict to trigger retraining
                return {}
            
            # Try to convert list to dict format
            if all(isinstance(x, (int, float)) for x in data[:10]):
                print(f'[!] List appears to be probabilities, wrapping')
                return {'_cached_probs': np.array(data)}

        
        # If data is dict, ensure values are correct
        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, list) and len(value) == 133:
                    print(f'[!] Corrupted value for key {key}, removing')
                    data[key] = None
        
        return data

    def fix_corrupted_memory(self, memory_name):
        # Clear corrupted memory entries
        try:
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            
            # Deactivate corrupted entries
            c.execute("""
                UPDATE model_storage 
                SET is_active = 0 
                WHERE memory_name = ? AND is_active = 1
            """, (memory_name,))
            
            c.execute("""
                UPDATE model_attn_storage 
                SET is_active = 0 
                WHERE memory_name = ? AND is_active = 1
            """, (memory_name,))
            
            conn.commit()
            conn.close()
            
            print(f'[✅] Cleared corrupted memory for {memory_name}')
            return True
        except Exception as e:
            print(f'[!] Failed to clear memory: {e}')
            return False


    def load_agent_id(self, memory_name):
        try:

            try:
               db_path = self.get_database_path()
               conn = sqlite3.connect(db_path)  
            except:
                conn = sqlite3.connect(self.db_path)

            c = conn.cursor()
        
            c.execute("""
            SELECT agent_id FROM agent_attn_storage 
            WHERE memory_name = ? AND is_active = 1
            """, (memory_name,))
        
            result = c.fetchone()
            conn.close()

            print(f'[+] Retrieved Agent ID of {memory_name}: result: {result}')
        
            if result:
                return json.loads(result[0])
        except Exception as e:
            print(f'[-] Error handling ID: {e}')

        return None        

    def save_weights(self, memory_name, model_type=None):
        """Save weights to database."""
        try:
            db_path = self.get_database_path()
            conn = sqlite3.connect(db_path)
        except:
            conn = sqlite3.connect(self.db_path)

        c = conn.cursor()

        weights = {
            'lstm_W'  : self.pipeline.network_model.cell.W.tolist(),
            'lstm_b'  : self.pipeline.network_model.cell.b.tolist(),
            'Wy' : self.pipeline.network_model.Wy.tolist() if self.pipeline.network_model.Wy is not None else None,
            'by' : self.pipeline.network_model.by.tolist(),
            'residual_mean': self.pipeline.lstm_engine.residual_mean,
            'residual_std' : self.pipeline.lstm_engine.residual_std,
            'quantiles'    : {str(k): list(v) 
                            for k, v in self.pipeline.lstm_engine.quantiles.items()} 
                            if self.pipeline.lstm_engine.quantiles else {},
            'n_samples'    : self.pipeline.lstm_engine.n_samples,
            'saved_at'     : datetime.now().isoformat(),
        }
        
        weight_json = json.dumps(weights, default=str)
        try:
            c.execute("""
                INSERT INTO weight_storage 
                (memory_name, model_type, weights, is_active)
                VALUES (?, ?, ?, ?)
            """, (memory_name, model_type, weight_json, 1))
        
            c.execute("""
                UPDATE weight_storage 
                SET is_active = 0 
                WHERE memory_name = ? AND id != last_insert_rowid()
            """, (memory_name,)) 

            conn.commit()
            conn.close()

            print('[||] Weights dictionary saved!')

        except Exception as e:
            print(f'[-] Cant save Weights due to: {e}')
            pass          
       
    def load_weights(self, memory_name):
        """Load weights from database. Returns True if found."""
        result = self.weight_retrieval(memory_name)
    
        if not result:
            print(f'[=] No saved weights for {memory_name}')
            return False

        try:
            weights = result
            self.pipeline.network_model.cell.W  = np.array(weights['lstm_W'])
            self.pipeline.network_model.cell.b  = np.array(weights['lstm_b'])
            self.pipeline.network_model.Wy      = np.array(weights['Wy']) if weights['Wy'] else None
            self.pipeline.network_model.by      = np.array(weights['by'])
            self.pipeline.lstm_engine.residual_mean = weights.get('residual_mean', 0.0)
            self.pipeline.lstm_engine.residual_std  = weights.get('residual_std',  1.0)
            self.pipeline.lstm_engine.n_samples     = weights.get('n_samples', self.pipeline.lstm_engine.n_samples)
            self.pipeline.lstm_engine.quantiles     = {float(k): tuple(v) 
                                for k, v in weights.get('quantiles', {}).items()}
        
            print(f'[=] All Weights loaded for {memory_name} '
                f'(saved at {weights.get("saved_at", "unknown")})')
        except Exception as e:
            print(f'[!] Cant load any Weights due to: {e}')
            traceback.print_exc()

    def memory_exists(self, memory_name, type=None):

        conn = None
        try:
            try:
                db_path = self.get_database_path()
                conn = sqlite3.connect(db_path)               
            except:
                conn = sqlite3.connect(self.db_path)
   

            if type == 'Transformer':
                c = conn.cursor()
        
                c.execute("""
                SELECT 1 FROM model_attn_storage 
                WHERE memory_name = ? AND is_active = 1
                LIMIT 1
                """, (memory_name,))
        
                result = c.fetchone()
                exists = result is not None
                print(f"|| Retrieved Attention: {memory_name}")

            elif type == 'Peer':
                c = conn.cursor()
        
                c.execute("""
                SELECT 1 FROM agent_attn_storage 
                WHERE memory_name = ? AND is_active = 1
                LIMIT 1
                """, (memory_name,))
        
                result = c.fetchone()
                exists = result is not None
                print(f"|| Retrieved Peer Memory: {memory_name}")

            else:
                c = conn.cursor()

                c.execute("""
                SELECT 1 FROM model_storage 
                WHERE memory_name = ? AND is_active = 1
                LIMIT 1
                """, (memory_name,))
        
                result = c.fetchone()
                exists = result is not None
                print(f"|| Retrieved Memory: {memory_name}")

            return exists
        
        except sqlite3.OperationalError as e:
            print(f"Database error: {e}")
            return False
            
        except Exception as e:
            print(f"Unexpected error: {e}") 
            return False
        finally:
            if conn:
                conn.close()


    def save_model_binary(self, model_object, memory_name, model_type='mlp'):
        try:
            try:
                conn = sqlite3.connect(self.db_path)
            except:
               db_path = self.get_database_path()
               conn = sqlite3.connect(db_path)          
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
        
            model_binary = joblib.dumps(model_object)
        
            c.execute("""
            INSERT INTO model_storage 
            (memory_name, model_type, model_binary, is_active)
            VALUES (?, ?, ?, ?)
            """, (memory_name, model_type, model_binary, 1))
        
            # Deactivate other versions
            c.execute("""
            UPDATE model_storage 
            SET is_active = 0 
            WHERE memory_name = ? AND id != last_insert_rowid()
            """, (memory_name,))
        
            conn.commit()
            model_id = c.lastrowid
            print(f"✅ Memory '{memory_name}' saved as binary (ID: {model_id})")
        except Exception as e:
            logger.error(f"[-] Error handling: {e}")

        conn.close()

        return model_id
    
    def load_model_binary(self, memory_name):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        c.execute("""
            SELECT model_binary FROM model_storage 
            WHERE memory_name = ? AND is_active = 1
        """, (memory_name,))
        
        result = c.fetchone()
        conn.close()
        
        if result:
            return joblib.loads(result[0])
        return None
    
    def save_complete_pipeline(self, pipeline_name, pipeline_dict):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        # Convert entire pipeline to JSON (for dicts)
        pipeline_json = json.dumps(pipeline_dict, default=str)
        
        c.execute("""
            INSERT INTO model_storage 
            (pipeline_name, model_type, model_data, metadata, is_active)
            VALUES (?, ?, ?, ?, ?)
        """, (pipeline_name, 'pipeline', pipeline_json, 
               json.dumps({'components': list(pipeline_dict.keys())}), 1))
        
        conn.commit()
        model_id = c.lastrowid
        conn.close()
        
        print(f"✅ Integrated pipeline '{pipeline_name}' saved")
        return model_id

@dataclass
class Message:
    # Enhanced message with better tracking and retry logic for async processing
    id: str
    type: str
    sender: str
    recipient: str
    payload: Any
    timestamp: datetime
    priority: MessagePriority = MessagePriority.NORMAL
    callback: Optional[Callable] = None
    retry_count: int = 0
    max_retries: int = 3
    timeout: float = 30.0
    created_at: float = field(default_factory=time.time)
    
    @property
    def age(self) -> float:
        # Age of message in seconds.
        return time.time() - self.created_at
    
    @property
    def is_expired(self) -> bool:
        # Check if message has expired.
        return self.age > self.timeout

class AsyncMessageQueue:
    # async message queue handler.
    
    def __init__(self, max_size=1000, dead_letter_queue_size=100):
        self.queue = asyncio.PriorityQueue(maxsize=max_size)
        self.pending: Dict[str, asyncio.Future] = {}
        self.results: Dict[str, Any] = {}
        self.handlers: Dict[str, Callable] = {}
        self.dead_letter_queue: deque = deque(maxlen=dead_letter_queue_size)
        self._running = False
        self._worker_task: Optional[asyncio.Task] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None   
        self._counter_lock = asyncio.Lock() 
        self._start_lock = asyncio.Lock()            
        self._counter = 0
        self._stats = {
            'messages_processed': 0,
            'messages_failed': 0,
            'messages_retried': 0,
            'messages_expired': 0,
            'avg_latency': 0.0
        }
        
    def register_handler(self, message_type: str, handler: Callable):
        # Register a handler for specific message type
        self.handlers[message_type] = handler
      
        logger.info(f"[=] Registered handler for {message_type}")
    
    async def _ensure_started(self):
        """Start the worker if not already running"""
        if self._running:
            return
        
        async with self._start_lock:
            if self._running:
                return
            
            self._running = True
            self._worker_task = asyncio.create_task(self._worker())
            logger.info("[=] Async message queue worker started")
            
            # Give worker a moment to initialize
            await asyncio.sleep(0.1)
            
            if self._worker_task.done():
                exc = self._worker_task.exception()
                if exc:
                    logger.error(f"[=] Worker failed: {exc}")
                    raise exc
    

    async def publish(self, message: Message) -> Any:
        # Publish a message and wait for response.
        # Generate unique counter
        await self._ensure_started()

        async with self._counter_lock:
            self._counter += 1
            counter = self._counter
        
        if message.is_expired:
            logger.warning(f"[-] Message {message.id} already expired")
            raise TimeoutError(f"[-] Message {message.id} already expired")
            
        future = asyncio.Future()
        self.pending[message.id] = future
        logger.info(f"[=] Publishing message, ID: {message.id} of type {message.type} with priority {message.priority.name}")

        print('=== Queue Status ===')
        logger.info(f"[QueueStatus] Queue size before put: {self.queue.qsize()}")
        logger.info(f"[QueueStatus] Queue maxsize: {self.queue.maxsize}")
        logger.info(f"[QueueStatus] Queue full: {self.queue.full()}")
        logger.info(f"[QueueStatus] Worker running: {self._worker_task is not None and not self._worker_task.done()}")
                
        # Use priority queue (lower number = higher priority)
        await self.queue.put((message.priority.value, counter, message))
        logger.debug(f"[=] Message {message.id} enqueued, waiting for response...")
        
        try:
            logger.debug(f"[=] Awaiting response for message {message.id} with timeout {message.timeout}s")
            result = await asyncio.wait_for(future, timeout=message.timeout)
            logger.debug(f"[=] Received response for message {message.id}: {result}")
            return result
        except asyncio.TimeoutError:
            self.pending.pop(message.id, None)
            self._stats['messages_expired'] += 1
            logger.warning(f"[-] Message {message.id} timed out after {message.timeout}s")
            raise
        except Exception as e:
            self.pending.pop(message.id, None)
            logger.error(f"[-] Error occurred while processing message {message.id}: {e}")
            raise
    
    async def publish_async(self, message: Message, callback: Optional[Callable] = None):
        # Publish without waiting (fire and forget).
        message.callback = callback
        await self.queue.put((message.priority.value, message))
    
    async def _worker(self):
        # Background worker processing messages.
        while self._running:
            try:
                priority, counter, message = await asyncio.wait_for(self.queue.get(), timeout=1.0)
                logger.info(f"[=] Worker picked up message {message.id} (counter: {counter}, priority: {priority})") 

                start_time = time.time()
                
                if message.is_expired:
                    self._stats['messages_expired'] += 1
                    logger.warning(f"[-] Dropping expired message {message.id}")
                    self._handle_orphaned_message(message)
                    continue
                
                if message.type in self.handlers:
                    try:
                        # Execute handler
                        if asyncio.iscoroutinefunction(self.handlers[message.type]):
                            result = await self.handlers[message.type](message)
                        else:
                            result = self.handlers[message.type](message)
                        
                        # Calculate latency
                        latency = time.time() - start_time
                        self._update_stats(latency, success=True)
                        
                        # Handle response
                        if message.id in self.pending:
                            self.pending[message.id].set_result(result)
                        elif message.callback:
                            message.callback(result)
                            
                    except Exception as e:
                        self._stats['messages_failed'] += 1
                        logger.error(f"[-] Handler failed for {message.type}: {e}\n{traceback.format_exc()}")
                        
                        if message.retry_count < message.max_retries:
                            message.retry_count += 1
                            self._stats['messages_retried'] += 1
                            logger.info(f"[-] Retrying message {message.id} (attempt {message.retry_count})")
                            await self.queue.put((message.priority.value, message))
                        else:
                            self._dead_letter_message(message, e)
                            if message.id in self.pending:
                                self.pending[message.id].set_exception(e)
                            elif message.callback:
                                message.callback(e)
                else:
                    logger.warning(f"[-] No handler for message type: {message.type}")
                    self._dead_letter_message(message, Exception(f"No handler for {message.type}"))
                    
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                logger.info("[=] Worker task cancelled")
                break
            except Exception as e:
                logger.error(f"[-] Worker error: {e}\n{traceback.format_exc()}")
                await asyncio.sleep(0.1)
    
    def _update_stats(self, latency: float, success: bool):
        # Update queue statistics
        self._stats['messages_processed'] += 1
        if not success:
            self._stats['messages_failed'] += 1
        
        # Exponential moving average of message latency.
        # alpha = 0.1 means the current measurement contributes 10 % to the running average,
        # providing a smoothed latency estimate that is robust to spikes without requiring
        # a fixed-size history window.
        alpha = 0.1  # Smoothing factor
        self._stats['avg_latency'] = alpha * latency + (1 - alpha) * self._stats['avg_latency']
    
    def _dead_letter_message(self, message: Message, error: Exception):
        # Send failed message to dead letter queue
        self.dead_letter_queue.append({
            'message': message,
            'error': str(error),
            'timestamp': datetime.now(),
            'retry_count': message.retry_count
        })
        logger.error(f"[=] Message {message.id} sent to DLQ after {message.retry_count} retries")
    
    def _handle_orphaned_message(self, message: Message):
        # Handle orphaned messages (no pending future, no callback).
        logger.warning(f"[=] Orphaned message {message.id} of type {message.type}")
        # Could store for manual inspection
        self.dead_letter_queue.append({
            'message': message,
            'error': 'Orphaned message - no handler or callback',
            'timestamp': datetime.now()
        })
    
    def get_stats(self) -> Dict:
        # Get queue statistics.
        return {
            **self._stats,
            'pending_count': len(self.pending),
            'queue_size': self.queue.qsize(),
            'dlq_size': len(self.dead_letter_queue),
            'is_running': self._running
        }
    

    
    async def start(self):
        # Start the async worker (async version).
        if self._running:
            logger.warning("[=] Queue already running")
            return
        
        self._running = True
        self._worker_task = asyncio.create_task(self._worker())
        logger.info("[=] Async message queue started")
          
    
    async def stop(self, timeout: float = 5.0):
        # Stop the message queue worker gracefully.
        logger.info("[=] Stopping message queue...")
        self._running = False
        if self._worker_task:
            try:
                await asyncio.wait_for(self._worker_task, timeout=timeout)
            except asyncio.TimeoutError:
                self._worker_task.cancel()
                logger.warning("[=] Worker task did not stop gracefully")
        logger.info("[=] Async message queue stopped")
    
    def get_dead_letter_queue(self) -> List[Dict]:
        # Get copy of dead letter queue for inspection.
        return list(self.dead_letter_queue)


class ThreadedMessageQueue:
    # Thread-based message queue for synchronous code
    
    def __init__(self, max_size=1000, worker_threads=4):
        self.queue = queue.Queue(maxsize=max_size)
        self.results = {}
        self.handlers = {}
        self._running = False
        self._workers = []
        self._worker_threads = worker_threads
        self._stats = {
            'messages_processed': 0,
            'messages_failed': 0,
            'active_workers': 0
        }
        self._lock = threading.Lock()
        
    def register_handler(self, message_type: str, handler: Callable):
        # Register a handler for specific message type
        self.handlers[message_type] = handler
        logger.info(f"[=] Registered handler for {message_type}")
    
    def publish(self, message: Message, timeout: float = 30.0) -> Any:
        # Publish a message and wait for response
        result_container = {'result': None, 'error': None, 'ready': False}
        
        def callback_wrapper(res):
            result_container['result'] = res
            result_container['ready'] = True
        
        message.callback = callback_wrapper
        self.queue.put(message)
        
        start_time = time.time()
        while not result_container['ready'] and (time.time() - start_time) < timeout:
            time.sleep(0.01)
        
        if not result_container['ready']:
            raise TimeoutError(f"Message {message.id} timed out")
        
        if result_container['error']:
            raise result_container['error']
        
        with self._lock:
            self._stats['messages_processed'] += 1
        
        return result_container['result']
    
    def publish_async(self, message: Message, callback: Optional[Callable] = None):
        # Publish without waiting
        message.callback = callback
        try:
            self.queue.put(message, block=False)
            return True
        except queue.Full:
            logger.error(f"[=] Queue full, cannot publish message {message.id}")
            return False
    
    def _worker(self, worker_id: int):
        # Worker thread processing messages.

        print(f'[=] Worker started: {worker_id}')
        while self._running:
            try:
                message = self.queue.get(timeout=1)
           
                if message.type in self.handlers:
                    try:
                        result = self.handlers[message.type](message)
                        if message.callback:
                            message.callback(result)
                    except Exception as e:
                        logger.error(f"[=] Worker {worker_id} handler failed: {e}")
                        if message.callback:
                            message.callback(e)
                else:
                    logger.warning(f"[=] No handler for message type: {message.type}")
                    
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"[=] Worker {worker_id} error: {e}")
    
    def start(self):
        # Start worker threads.
        if self._running:
            return
            
        self._running = True
        for i in range(self._worker_threads):
            thread = threading.Thread(target=self._worker, args=(i,), daemon=True)
            thread.start()
            self._workers.append(thread)
        
        with self._lock:
            self._stats['active_workers'] = len(self._workers)
        
        logger.info(f"[=] Threaded message queue started with {self._worker_threads} workers")
    
    async def stop(self, timeout: float = 5.0):
        # Stop worker threads gracefully.
        self._running = False
        # cancel and wait for all workers to exit cleanly
        for worker in self._workers:
            worker.cancel()

        if self._workers:
            await asyncio.gather(*self._workers, return_exceptions=True)

        self._workers.clear()

        logger.info("[=] Threaded message queue stopped")
    

    def get_stats(self) -> Dict:
        # Get queue statistics.
        with self._lock:
            return {
                **self._stats,
                'queue_size': self.queue.qsize(),
                'workers': len(self._workers),
                'is_running': self._running
            }

# Integrated inference module that allows multiple agents to connect and share their predictions, attention maps, and confidence scores for ensemble decision making.
# while also providing security features like authentication, rate limiting, and message validation.
class AgentDistributedInference:
    '''
    Peer-to-peer distributed inference layer for IntegratedPipeline.

    Overview
    --------
    Each pipeline instance can optionally start a TCP server on a configurable
    port and exchange prediction requests / probability calibrations with other
    agents on the network.  Communication is secured via:

      - HMAC-SHA256 message signing (_sign_message / _verify_signature)
      - TrustLevel gating (UNTRUSTED → FULL) for all incoming requests
      - Token-based agent authentication (_authenticate_agent)
      - Per-agent request rate limiting (_check_rate_limit)
      - Optional TLS wrapping (ssl_cert_file / ssl_key_file)
      - 10 MB message size cap to prevent memory exhaustion attacks

    Probability calibration flow
    ----------------------------
    When the local model is uncertain (confidence below
    pipeline.peer_assistance_threshold), the agent contacts a remote peer,
    exchanges attention weights and MLP predictions, and blends the peer's
    calibrated probabilities back using _calibrate_peer_probs().  The blend
    magnitude is governed by a "justified" score: agreement between the two
    modalities (MLP vs attention) weighted by anisotropy.

    Async support
    -------------
    When use_async=True the agent creates an AsyncMessageQueue to handle
    incoming socket messages on a dedicated asyncio loop, allowing non-blocking
    request handling alongside the main thread.

    Parameters
    ----------
    pipeline         : Parent IntegratedPipeline instance.
    storage          : ModelStorage instance for reading/writing memories.
    memory_name      : Logical name scoping all DB operations.
    port             : TCP port this agent listens on (default 5555).
    use_async        : Enable AsyncMessageQueue for non-blocking I/O.
    secret_key       : HMAC signing key for outgoing messages.
    ssl_cert_file    : Path to TLS certificate (optional).
    ssl_key_file     : Path to TLS private key (optional).
    shared_auth_token: Shared secret for agent authentication.
    predict_manager  : Optional PipelinePredictionManager for richer
                       prediction requests from remote agents.
    '''
    def __init__(self, pipeline, storage, memory_name, port=5555, use_async=False, secret_key=None, ssl_cert_file=None, ssl_key_file=None, shared_auth_token=None, predict_manager=None):

        self.pipeline = pipeline
        self.memory_name = memory_name
        self.port = port
        self.storage = storage

        self.query_node = QueryNode(pipeline, memory_name, self.storage)        
        
        self.agent_comm_log = {}
        self.connections_log = {}
        self.connections = []  # List of connected sockets
        self.remote_agents = {}  # {agent_id: {'sock': sock, 'host': host, 'port': port, 'trust': 1.0}}
        
        self.running = False
        self.socket = None
        self.temporary_message = None
        self.temporary_agent_id = None  
        self.established_connections = set()  # Track established connections to prevent duplicates      

        self.next_agent_id = 1
        self.connection_timeout = 15

        # for security purposes
        # Security: Authentication token
        self.auth_token = shared_auth_token
        self.secret_key = shared_auth_token 

        # Security: Rate limiting
        self.max_connections_per_minute = 20
        self.connection_timestamps = deque(maxlen=20)
        self.max_requests_per_minute = 40
        self.request_timestamps = defaultdict(lambda: deque(maxlen=40))
        self.secret_key = secret_key

        # Security: Message validation
        self.max_message_size = 10 * 1024 * 1024  # 10MB limit

        # Security: Trusted agents
        self.trusted_agents = {}

        # Security: Audit log
        self.security_log = []        

        self.enable_ssl = False  # Set to True to enable SSL encryption
        # i provided basic cert file and key since there are other layered security other than ssl, and also due to infrequent external connections.
        self.ssl_cert_file = ssl_cert_file
        self.ssl_key_file = ssl_key_file
        self.ssl_context = None

        if self.enable_ssl:
            self._setup_ssl()

        self.allowed_ips = set()  # Add trusted IPs
        self.blocked_ips = set()  # Block malicious IPs

        # Message types
        self.MSG_TYPES = {
            'PREDICT_REQUEST': 1,
            'PREDICT_RESPONSE': 2,
            'MEMORY_SYNC_REQUEST': 3,
            'MEMORY_SYNC_RESPONSE': 4,
            'ENSEMBLE_VOTE_REQUEST': 5,
            'ENSEMBLE_VOTE_RESPONSE': 6,
            'FAILURE_REPORT': 7,
            'TRUST_UPDATE': 8,
            'AGENT_INFO': 9,
            'PING': 10,
            'PONG': 11,
            'DISCONNECT': 12
        }
        
        # message queue
        self.max_retries = 3
        self.retry_delay = 1.0
        self.message_timeout = 30.0 
        self.CHUNK_SIZE = 8192
        self.predict_manager = predict_manager
        self._health_check_interval = 30  # seconds

        self.use_async = use_async
        
        # Register message handlers
        print('[=++=] Initiating message Queue')
        self.message_queue = AsyncMessageQueue()
            
        self.message_queue.register_handler('predict_request', self._handle_predict_request_async)
        self.message_queue.register_handler('memory_sync', self._handle_memory_sync_async)
        self.message_queue.register_handler('ensemble_vote', self._handle_ensemble_vote_async)
        self.message_queue.register_handler('ping', self._handle_ping)
        self.message_queue.register_handler('status', self._handle_status)
                
           
        # Queue for outgoing messages (buffered with retry)
        self.outgoing_queue = deque()
        self.queue_processor_thread = None
        self._last_health_check = time.time()
      
        # Start health checker if async
        if use_async:
            self._start_health_checker()        
            
        # Trust configuration
        self.min_trust_level_for_auto_add = TrustLevel.STANDARD
        self.trusted_agents = {}  # agent_id -> {'token': token, 'trust_level': TrustLevel, 'added_at': datetime} 
        self.highly_trusted_peer = []
        self.socket_owners = {}
        
        self.pending_requests = {}  # request_id -> Future
        self.request_lock = threading.Lock()        
     

    # ============ SECURITY FEATURES ============

    def _check_ip_access(self, ip):
        print(f'|| Checking IP access for: {ip}')
        if ip in self.blocked_ips:
            return False
        if self.allowed_ips and ip not in self.allowed_ips:
            return False
        return True

    def add_allowed_ip(self, ip):
        self.allowed_ips.add(ip)
        self._log_security_event('ip_allowed', {'ip': ip})

    def remove_allowed_ip(self, ip):
        self.allowed_ips.discard(ip)
        self._log_security_event('ip_removed_from_allow', {'ip': ip})

    def add_blocked_ip(self, ip):
        self.blocked_ips.add(ip)
        self._log_security_event('ip_blocked', {'ip': ip})

    def remove_blocked_ip(self, ip):
        self.blocked_ips.discard(ip)
        self._log_security_event('ip_removed_from_block', {'ip': ip})

    def _setup_ssl(self):
        # Setup SSL context for encrypted connections
        try:
            self.ssl_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)      
            if self.ssl_cert_file and self.ssl_key_file:
                self.ssl_context.load_cert_chain(self.ssl_cert_file, self.ssl_key_file)
            else:
                # Generate self-signed certificate for first layer security
                self._generate_self_signed_cert()
                
        except Exception as e:
            print(f"SSL setup failed: {e}")
            self.enable_ssl = False

    def _generate_self_signed_cert(self):
        # Generate self-signed certificate
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        import datetime
        
        # Generate private key
        private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        
        # Creatingcertificate
        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, u"localhost"),
        ])
        
        cert = x509.CertificateBuilder().subject_name(
            subject
        ).issuer_name(
            issuer
        ).public_key(
            private_key.public_key()
        ).serial_number(
            x509.random_serial_number()
        ).not_valid_before(
            datetime.datetime.utcnow()
        ).not_valid_after(
            datetime.datetime.utcnow() + datetime.timedelta(days=365)
        ).add_extension(
            x509.SubjectAlternativeName([x509.DNSName(u"localhost")]),
            critical=False,
        ).sign(private_key, hashes.SHA256())
        
        # Saving certificate and key
        cert_pem = cert.public_bytes(serialization.Encoding.PEM)
        key_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        with open('server.crt', 'wb') as f:
            f.write(cert_pem)
        with open('server.key', 'wb') as f:
            f.write(key_pem)
            
        self.ssl_cert_file = 'server.crt'
        self.ssl_key_file = 'server.key'
        self.ssl_context.load_cert_chain(self.ssl_cert_file, self.ssl_key_file)


    def _generate_auth_token(self):
        return hashlib.sha256(os.urandom(32)).hexdigest()

    def _generate_secret_key(self):
        return hashlib.sha256(os.urandom(48)).hexdigest()

    def _log_security_event(self, event_type, details):
        self.security_log.append({
            'timestamp': datetime.now().isoformat(),
            'event': event_type,
            'details': details
        })
        if len(self.security_log) > 1000:
            self.security_log = self.security_log[-1000:]

    def _sanitize_input(self, text, amount=1000):
        if not isinstance(text, str):
            return str(text)
        sanitized = ''.join(char for char in text if ord(char) >= 32 or char in '\n\r\t')
        return sanitized[:amount]

    def _sanitize_arrays_and_dicts(self, data, amount=1000):
        if isinstance(data, list):
            return [self._sanitize_input(item, amount) for item in data]
        elif isinstance(data, dict):
            return {key: self._sanitize_input(value, amount) for key, value in data.items()}
        else:
            return self._sanitize_input(data, amount)


    def _check_rate_limit(self, agent_id=None):
        start = time.time()
        if not agent_id:
            print('|| No agent ID provided for rate limiting, applying global connection limit.')
            return False

        print(f'|| Checking rate limit for agent: {agent_id}')
        now = time.time()
        self.connection_timestamps = [t for t in self.connection_timestamps if now - t < 10]
        recent_connections = len(self.connection_timestamps)
        if recent_connections > self.max_connections_per_minute:
            self._log_security_event('rate_limit_exceeded', {'type': 'connection', 'agent': agent_id})
            return False
        if agent_id:
            stale = [aid for aid, timestamps in self.request_timestamps.items() if not timestamps or now - timestamps[-1] >= 10]
            for aid in stale:
                del self.request_timestamps[aid]

            self.request_timestamps[agent_id] = [t for t in self.request_timestamps[agent_id] if now - t < 10]
            if time.time() - start > 5:
                print('|| Rate limit check timed out.')
                return False  

            recent_requests = len(self.request_timestamps[agent_id])
            if recent_requests > self.max_requests_per_minute:
                self._log_security_event('rate_limit_exceeded', {'type': 'request', 'agent': agent_id})
                return False
        return True

    def _sign_message(self, message):
        # Create HMAC signature - DOES NOT modify original message
 
        # Created a COPY of the message with timestamp
        signed_message = message.copy()  # ← IMPORTANT: Copy!
        
        # Ensure timestamp is float if present
        if 'timestamp' in signed_message and isinstance(signed_message['timestamp'], str):
            from datetime import datetime
            try:
                dt = datetime.fromisoformat(signed_message['timestamp'].replace('Z', '+00:00'))
                signed_message['timestamp'] = dt.timestamp()
            except:
                signed_message['timestamp'] = time.time()
    
        # Sort keys for consistent serialization
        sorted_message = {k: signed_message[k] for k in sorted(signed_message.keys())}
      
        message_bytes = pickle.dumps(sorted_message, protocol=pickle.HIGHEST_PROTOCOL)
      
        key = self.secret_key.encode() if isinstance(self.secret_key, str) else self.secret_key
        signature = hmac.new(key, message_bytes, hashlib.sha256).hexdigest()

        print(f'|| Signing message with: {len(message)} total of size, with signature: {signature}')  
        logger.info(f"[=] Signing message: {len(message)}")
        return signature



    def _verify_signature(self, message, signature):
        # Verify signature - with timestamp in message
        
        # Create a copy without the signature field
        print(f'|| Verifying message signature total: {len(message)}')
        temp_msg = {k: v for k, v in message.items() if k != 'signature'}

        if 'timestamp' in temp_msg and isinstance(temp_msg['timestamp'], str):
            try:
                dt = datetime.fromisoformat(temp_msg['timestamp'].replace('Z', '+00:00'))
                temp_msg['timestamp'] = dt.timestamp()
            except:
                temp_msg['timestamp'] = time.time()
          
        # Sort keys for consistent serialization
        sorted_msg = {k: temp_msg[k] for k in sorted(temp_msg.keys())}
          
        message_bytes = pickle.dumps(sorted_msg, protocol=pickle.HIGHEST_PROTOCOL)
         
        key = self.secret_key.encode() if isinstance(self.secret_key, str) else self.secret_key
        expected = hmac.new(key, message_bytes, hashlib.sha256).hexdigest()
        
        result = hmac.compare_digest(expected, signature)

        print(f'[=] Comparing result...')
        print(f'|| Signature verification result: {result}')
        logger.info(f"[-] Signature verification result: {result}")

        return result

   
    def add_trusted_agent(self, agent_id, agent_token):
        if agent_id == 'local':
            print(f"[❌] Cannot add 'local' as trusted agent")
            return

        self.trusted_agents[agent_id] = {'token': agent_token, 'added_at': datetime.now()}
        self._log_security_event('trusted_agent_added', {'agent_id': agent_id})

    def _authenticate_agent(self, token, agent_id):
        print(f'|| Authenticating agent: {agent_id} with token: {token}')
        logger.info(f"[==] Authenticating agent: {agent_id} with token: {token}")

        if agent_id in self.highly_trusted_peer:
            print('[=+=] Agent is authenticated and already verified')
            return True

        elif token == self.auth_token:
            print(f"[=✅=] Agent {agent_id} authenticated with SHARED SECRET (FULL trust)")
            
            # Add to trusted list with FULL trust if not exists
            if agent_id not in self.trusted_agents:
                self._add_trusted_agent(agent_id, token, TrustLevel.FULL, source="shared_secret")
            else:
                # Update trust level if higher
                current_level = self.trusted_agents[agent_id].get('trust_level', TrustLevel.BASIC)
                if TrustLevel.FULL > current_level:
                    self.trusted_agents[agent_id]['trust_level'] = TrustLevel.FULL
                    print(f"[=] Upgraded trust level to FULL")
                    self.highly_trusted_peer.append(agent_id)

        elif agent_id in self.trusted_agents:
            stored_token = self.trusted_agents[agent_id]['token']
            stored_trust = self.trusted_agents[agent_id].get('trust_level', TrustLevel.BASIC)
            
            if stored_token == token:
                print(f"[✅] Agent {agent_id} authenticated with {stored_trust.name} trust")
                self.highly_trusted_peer.append(agent_id)
                return True
            else:
                print(f"[❌] Token mismatch for {agent_id}")
                return False

        else:  
            auto_add_threshold = getattr(self, 'min_trust_level_for_auto_add', TrustLevel.STANDARD)
        
            print(f"[-] Agent {agent_id} not in trusted list")
            print(f"[=/=] Auto-add threshold: {auto_add_threshold.name}")
            
            # Only auto-add if you have high trust in the network
            if auto_add_threshold == TrustLevel.FULL:
                # In high-security mode, don't auto-add
                print(f"[-] Auto-add disabled (requires manual approval)")
                return False
            else:
                # Auto-add with BASIC trust
                print(f"[+] Auto-adding agent {agent_id} with BASIC trust")
                self._add_trusted_agent(agent_id, token, TrustLevel.BASIC, source="auto_discovery")
                return True

            print('[==] Agent is not authenticated! ')
            return False

    def _add_trusted_agent(self, agent_id, token, trust_level=TrustLevel.STANDARD, source="manual"):
        """Add a trusted agent with specified trust level"""
        if agent_id == 'local':
            print(f"[❌] Cannot add 'local' as trusted agent")
            return

        self.trusted_agents[agent_id] = {
            'token': token,
            'trust_level': trust_level,
            'added_at': datetime.now(),
            'added_by': source,
            'last_seen': datetime.now(),
            'successful_connections': 0,
            'failed_connections': 0
        }
        
        self._log_security_event('trusted_agent_added', {
            'agent_id': agent_id,
            'trust_level': trust_level.name,
            'source': source
        })
        
        print(f"✅ Added trusted agent: {agent_id} (trust: {trust_level.name})")

    # ============ SERVER METHODS ============
    def start_server(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.bind(('0.0.0.0', self.port))

        self.socket.settimeout(1.0)
        self.socket.listen(5)
        self.running = True
        logger.info(f"[=] Server started on port {self.port} with SSL={'enabled' if self.enable_ssl else 'disabled'}")

        if self.enable_ssl and self.ssl_context:
            self.socket = self.ssl_context.wrap_socket(self.socket, server_side=True)

        print(f"[🤖] Agent listening on port {self.port}")
        
        # Start accepting connections in background
        accept_thread = threading.Thread(target=self._accept_connections, daemon=True)
        accept_thread.start()
        logger.info("[=] Server started and accepting connections...")
        
        return self.socket
    
    def _accept_connections(self):
        while self.running:
            try:
                client, addr = self.socket.accept()
                client.settimeout(self.connection_timeout)
                host = addr[0]
                port = addr[1]

                if host in ['127.0.0.1', 'localhost'] and port == self.port:
                    print(f"[❌] Rejected self-connection from {host}:{port}")
                    client.close()
                    continue
    

                if not self._check_ip_access(host):
                    print(f"[-] Connection attempt from blocked IP: {host}")
                    self._log_security_event('connection_blocked', {'ip': host})
                    client.close()
                    return

                print(f"📡 Connected to agent at {addr}")
                auth_msg = self._receive_message(client)
                if not auth_msg:
                    print(f"[-] No authentication message from {addr}")
                    client.close()
                    continue
                                        

                if not self._authenticate_agent(auth_msg.get('token', ''), f"{addr[0]}:{addr[1]}"):
                    print(f"[-] Authentication failed for agent with address: {addr}")
                    self._log_security_event('authentication_failed', {'agent': f"{addr[0]}:{addr[1]}"})
                    self.report_failure(id(self), 'authentication', reason=f'Failed authentication from {addr}')
                    client.close()
                    return

                # Send agent info to identify
                self._send_agent_info(client)
                
                # Start handler thread
                thread = threading.Thread(target=self._handle_client, args=(client, addr))
                thread.daemon = True
                thread.start()
                
            except Exception as e:
                if self.running:
                    print(f"[-] Accept error: {e}")
                    traceback.print_exc()
                    self.report_failure(id(self), 'processing', reason=f'{e}')
                                        
                break
    
    def _send_agent_info(self, client):
        # sending agent info to client used for authentication and identification
        info = {
            'type': self.MSG_TYPES['AGENT_INFO'],
            'agent_id': id(self),
            'agent_name': self.memory_name,
            'token': self.auth_token,
            'capabilities': ['prediction', 'memory_sync', 'ensemble'],
            'timestamp': time.time()
        }
        self._send_message(client, info)
        print(f"[==] Sent agent info for authentication")
        logger.info("[==] Sent agent info for authentication")


    def stop_server(self):
        # Gracefully stop the server and close all connections here
        self.running = False   
        # Close all connections
        for conn in self.connections:
            try:    
                self._send_message(conn, {'type': self.MSG_TYPES['DISCONNECT']})

                conn.shutdown(socket.SHUT_RDWR)
                conn.close()
            except Exception as e:
                print(f'[= ERROR =] Socket cant be shutdown due to: {e}')
                pass

        self.connections.clear()
        if self.socket:
            try:
                self.socket.close()  
            except Exception as e:
                print(f'[= ERROR =] Socket cant be closed due to: {e}')
                pass

        print("[🛑] Server stopped")
    
    # ============ CLIENT METHODS ============
    def _is_duplicate_connection(self, host, port):
        # Check if this connection attempt is a duplicate in later flow
        for agent_id, info in self.remote_agents.items():
            if info.get('host') == host and info.get('port') == port:
                return True
        return False    


    def connect_to_agent(self, host, port):
        """
        Connect to a peer agent with proper authentication flow.
        """
        if host == 'local':
            print(f"[❌] Cannot connect to 'local'")
            return None 

        if host in ['127.0.0.1', 'localhost', '0.0.0.0']:
            # Check if this is our own port
            if port == self.port or port == 0:
                print(f"[❌] Rejecting self-connection attempt to {host}:{port}")
                return None

        agent_id = f"{host}:{port}"
        print(f'🔗 Attempting to connect to agent: {agent_id}')
        
        # Generate a unique ID for this connection attempt
        connection_id = str(uuid.uuid4())[:8]
        
        try:
            # ========== SECURITY CHECKS ==========
            # Rate limiting 
            if not self._check_rate_limit(agent_id):
                print(f'[❌] Rate limit exceeded for {agent_id}')
                self._log_security_event('rate_limit_exceeded', 
                                        {'type': 'connection_attempt', 'agent': agent_id})
                self.report_failure(agent_id, 'connection_attempt', reason=f'Rate limit exceeded for {agent_id}')

                return None
            
            # IP access check
            if not self._check_ip_access(host):
                print(f"[-] Connection attempt to blocked IP: {host}")
                self._log_security_event('connection_blocked', {'ip': host})
                return None
            
            # ========== CREATE SOCKET ==========
            # Socket creation
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)    

            sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 1024)  # 1MB
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 1024 * 1024)  # 1MB      
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            sock.settimeout(10)

            print(f"[connect_to_agent() SOCKET CREATED] id={id(sock)}")            
            sock.settimeout(self.connection_timeout)
            print(f'[==] Connecting to {host}:{port}...')
            sock.connect((host, port))

            if self.enable_ssl and self.ssl_context:
                sock = self.ssl_context.wrap_socket(sock, server_hostname=host)
                print('[==] Socket Connected with SSL Provided!')
            
            # ========== SEND AUTHENTICATION FIRST ==========
            # Send agent info and token BEFORE receiving
            auth_message = {
                'type': self.MSG_TYPES['AGENT_INFO'],
                'agent_id': id(self),
                'agent_name': getattr(self, 'memory_name', 'unknown'),
                'token': self.auth_token,  # Your authentication token
                'timestamp': time.time()
            }
            
            if not self._send_message(sock, auth_message):
                print(f"[-] Failed to send authentication to {host}:{port}")
                self._log_security_event('authentication_failed', {'agent': agent_id})
                sock.close()
                return None
            
            print(f'[=?=] Authentication sent')
            
            # ========== RECEIVE PEER INFO ==========
            info = self._receive_message(sock)
            
            if not info:
                print(f"[-] No response from {host}:{port}")
                sock.close()
                return None
            
            # Authenticate the peer
            if not self._authenticate_agent(info.get('token', ''), agent_id):
                print(f"[-] Authentication failed for agent {host}:{port}")
                self._log_security_event('authentication_failed', {'agent': agent_id})
                sock.close()
                return None
            
            # ========== ESTABLISH PEER RELATIONSHIP ==========
            if info.get('type') == self.MSG_TYPES['AGENT_INFO']:
                remote_id = info.get('agent_id', agent_id)
                
                query_result = self.query_node._establish_peer_nodes(remote_id)
                
                if not query_result:
                    print(f'[❌] Connection to peer {remote_id} denied by query node.')
                    self.report_failure(id(self), 'peer_establishment', reason=f'Connection to peer {remote_id} denied')
                    sock.close()
                    return None

                print('[===] Connection to peer is permitted')
                
                # Store the connection
                self.remote_agents[remote_id] = {
                    'sock': sock,
                    'host': host,
                    'port': port,
                    'trust': 1.0,
                    'last_seen': datetime.now(),
                    'failures': 0,
                    'connection_id': connection_id
                }
                self.connections.append(sock)
                
                print(f"[=✅=] Connected to agent {remote_id} at {host}:{port}")
                if self.running:
                    print('[=+=] server is still listening for messages!')
                return sock
            else:
                print(f"[❌] Invalid agent response from {host}:{port}")
                self.report_failure(id(self), 'authentication', reason=f'Failed authentication from {host}:{port}')                
                sock.close()
                return None
                
        except socket.timeout:
            print(f"[❌] Connection timeout to {host}:{port}")
            return None
        except ConnectionRefusedError:
            print(f"[❌] Connection refused by {host}:{port} - server not running?")
            return None
        except Exception as e:
            print(f"[❌] Failed to connect to {host}:{port}: {e}")
            import traceback
            traceback.print_exc()
            return None

    
    def disconnect_agent(self, agent_id):
        # Disconnect from a peer agent and clean up resources
        if agent_id in self.remote_agents:
            try:
                self._send_message(self.remote_agents[agent_id]['sock'], 
                                  {'type': self.MSG_TYPES['DISCONNECT']})
                self.remote_agents[agent_id]['sock'].close()

                print(f'[===] Removing Agent id: {agent_id}')
                del self.remote_agents[agent_id]
            except:
                pass
            print(f"🔌 Disconnected from agent {agent_id}")

    def _sanitize_structured(self, data, amount=1000):
        """Recursively sanitize strings inside structures"""
        if isinstance(data, str):
            return self._sanitize_input(data, amount)
        elif isinstance(data, list):
            return [self._sanitize_structured(item, amount) for item in data]
        elif isinstance(data, tuple):
            return tuple(self._sanitize_structured(item, amount) for item in data)
        elif isinstance(data, dict):
            return {key: self._sanitize_structured(value, amount) for key, value in data.items()}
        else:
            return data

    # ============ asynchronous queue setup ============
    async def _handle_predict_request_async(self, message):
        # Async handler for prediction requests
        payload = message.payload

        # Initialize variables
        text = None
        test_titles = None
        label_map = None
        rules = None
        
        # ✅ Check payload (which is a dict), not the message itself
        if isinstance(payload, dict):
            if 'test_titles' in payload:
                test_titles = payload.get('test_titles')
                label_map = payload.get('label_map')
                rules = payload.get('rules')
                
                # Sanitize if needed
                if test_titles:
                    test_titles = self._sanitize_structured(test_titles)
                if label_map:
                    label_map = self._sanitize_structured(label_map)
                if rules:
                    rules = self._sanitize_structured(rules)

                print('[=] Got necessary titles, label_map and rules')

            else:
                text = payload.get('text')
                if text:
                    text = self._sanitize_input(text)
                print(f'[=] Got text: {text}')
        else:
            # Fallback: maybe payload is the text directly
            text = str(payload) if payload else None
        
        if not text and not test_titles:
            print('[===] ERROR: No text or test_titles in message payload!')
            return {'type': self.MSG_TYPES['PREDICT_RESPONSE'], 'error': 'No text or test_titles provided'}
        
        # Run the actual prediction
        print(f'[=] Initiating prediction method')
        try:
            if test_titles is not None:
                print('[=] initiating Advanced prediction method...')
                if not self.pipeline.autonomous:
                    self.pipeline.autonomous = True
                    self.pipeline.ensemble.explainer.supervised_learning = False

                if self.predict_manager is not None:
                    result = await asyncio.to_thread(
                        self.predict_manager.advanced_prediction_method,
                        test_titles, label_map, rules,
                        show_proba=True,
                        use_transformer=self.pipeline.use_transformer
                    )
                    # Handle tuple return (result, chosen_label, confidence)
                    if isinstance(result, tuple) and len(result) == 3:
                        _, chosen_label, confidence = result
                    else:
                        chosen_label = result.get('prediction', 'unknown')
                        confidence = result.get('confidence', 0)
                    
                    return {
                        'type': self.MSG_TYPES['PREDICT_RESPONSE'],
                        'prediction': chosen_label,
                        'confidence': confidence,
                        'success': True
                    }

                else:
                    print('[=] Initaiting basic prediction...')
                    result = await asyncio.to_thread(self.pipeline.predict_single, text)
            
                    return {
                        'type': self.MSG_TYPES['PREDICT_RESPONSE'],
                        'prediction': result.get('prediction'),
                        'confidence': result.get('confidence'),
                        'probabilities': result.get('probabilities', []),
                        'agent_id': id(self),
                        'success': True
                    }                    
            else:

                print('[=] Basic prediction method')
                result = await asyncio.to_thread(self.pipeline.predict_single, text)
                
                return {
                    'type': self.MSG_TYPES['PREDICT_RESPONSE'],
                    'prediction': result.get('prediction'),
                    'confidence': result.get('confidence'),
                    'probabilities': result.get('probabilities', []),
                    'agent_id': id(self),
                    'success': True
                }
                
        except Exception as e:
            logger.info(f'[==] error in async method predict request: {e}')
            return {'type': self.MSG_TYPES['PREDICT_RESPONSE'], 'error': str(e), 'success': False}    
        

    async def _async_method_handle_predict_request_(self, message, sender_id, method='basic_prediction', predict_manager=None):
        # Handle prediction request async-ly
        text = None
        test_titles = None
        label_map = None
        rules = None
            
        if 'test_titles' in message:
            test_titles = message.get('test_titles')
            label_map = message.get('label_map')
            rules = message.get('rules')

            test_titles = self._sanitize_input(test_titles)
            label_map = self._sanitize_input(label_map)
            rules = self._sanitize_input(rules)
        else:
            text = message.get('text')
            text = self._sanitize_input(text) 

        if not text:
            print('[===] ERROR: No matched configuration in message for prediction!')
            return {'type': self.MSG_TYPES['PREDICT_RESPONSE'], 'error': 'No text provided'}
        
        # Run the actual prediction in thread pool (since predict_single is sync)
        print(f'[=] Initiating prediction method: {method}')
        try:
            print('[=] Advanced prediction method')
            if method != 'basic_prediction' or predict_manager:
                result = await asyncio.to_thread(
                    predict_manager.advanced_prediction_method,
                    test_titles, label_map, rules, show_proba=False, use_transformer=self.pipeline.use_transformer
                )
            else:
                print('[=] basic prediction method')
                result = await asyncio.to_thread(self.pipeline.predict_single, text)
            
            return {
                'type': self.MSG_TYPES['PREDICT_RESPONSE'],
                'prediction': result['prediction'],
                'confidence': result['confidence'],
                'probabilities': result.get('probabilities', []),
                'agent_id': id(self)
            }
        except Exception as e:
            logger.info(f'[==] error in async method predict request: {e}')
            return {'type': self.MSG_TYPES['PREDICT_RESPONSE'], 'error': str(e)}


    async def _handle_memory_sync_async(self, message):
        # Safe handler for memory sync.
        try:
            logger.info(f"[=] Processing memory sync from {message.sender}")
            return await self._handle_memory_sync_request(message, message.sender)
        except Exception as e:
            logger.error(f"[❌] Memory sync failed: {e}")
            return {'error': str(e), 'status': 'failed'}
    
    async def _handle_ensemble_vote_async(self, message):
        # Safe handler for ensemble voting.
        try:
            logger.info(f"[=] Processing ensemble vote from {message.sender}")
            return await self._handle_ensemble_vote_request(message, message.sender)
        except Exception as e:
            logger.error(f"[❌] Ensemble vote failed: {e}")
            return {'error': str(e), 'status': 'failed'}
    
    async def _handle_ping(self, message):
        # Simple ping handler for health checks.
        return {'pong': True, 'timestamp': time.time(), 'agent_id': self.agent_id}
    
    async def _handle_status(self, message):
        # Status handler for monitoring.
        return {
            'status': 'healthy',
            'queue_stats': self.message_queue.get_stats(),
            'connected_agents': len(self.remote_agents),
            'memory_size': len(self.pipeline.memory),
            'uptime': time.time() - self.start_time if hasattr(self, 'start_time') else 0
        }   


    def request_prediction(self, agent_id: Any, text: Any, timeout: float = 30.0) -> Any:
        # Unified prediction request - works with both sync and async modes.
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        try:
            # Run the async version and wait for result
            result = loop.run_until_complete(
                self.request_prediction_async(agent_id, text, timeout)
            )
            return result
        finally:
            loop.close()


    async def request_advanced_prediction_async(self, manager: Any, use_transformer: bool=False, agent_id: str=None, test_titles: List[tuple]=None, label_map: Dict[str, int]=None, rules: List[tuple]=None, X: np.ndarray=None, y: np.ndarray=None, timeout: float = 30.0, callback: Optional[Callable] = None):
        # Asynchronous prediction request
        # Local bypass - NO QUEUE
        if agent_id == 'local':
            logger.info(f"[=] Local request - direct execution")
            # Run sync prediction in thread pool
            result = await asyncio.to_thread(manager.advanced_prediction_method, test_titles, label_map, rules, X=X, y=y, show_proba=True, use_transformer=use_transformer)
            logger.info(f"[=] Local result: {result[1]} || confidence: {result[2]}")
            return result  

        msg_id = str(uuid.uuid4())
        message = Message(
            id=msg_id,
            type='predict_request',
            sender=self.temporary_agent_id,
            recipient=agent_id,
            payload={'test_titles': test_titles, 'label_map': label_map, 'rules': rules, 'X':X, 'y':y},
            timestamp=datetime.now(),
            timeout=timeout,
            callback=callback,
            max_retries=self.max_retries
        )

        logger.info(f"[=] Remote request - publishing to queue")
        response = await self.message_queue.publish(message)
        logger.info(f"[=] Queue response type: {type(response)}")

        # Extract prediction from response if needed
        if isinstance(response, dict) and 'prediction' in response:
            return response
        elif isinstance(response, dict) and 'result' in response:
            return response['result']
        else:
            return response    

    
    def request_prediction_direct(self, agent_id, text, timeout=5):
        # Generate unique request ID
        request_id = str(uuid.uuid4())
        
        # Create future for response
        future = asyncio.Future()
        with self.request_lock:
            self.pending_requests[request_id] = future
        
        # Send message with request_id
        message = {
            'type': 1,
            'text': text,
            'token': self.auth_token,
            'request_id': request_id,  # ← Include in message!
            'timestamp': time.time()
        }
        
        sock = self.remote_agents[agent_id]['sock']
        self._send_message(sock, message)
        
        # Wait for response with timeout
        try:
            return future.result(timeout=timeout)
        finally:
            with self.request_lock:
                self.pending_requests.pop(request_id, None)


    async def request_prediction_async(self, agent_id: Any, text: Any, timeout: float = 30.0, callback: Optional[Callable] = None):
        # Asynchronous prediction request
        # # Local bypass
        if agent_id == 'local':
            return await asyncio.to_thread(self.pipeline.predict_single, text)  

        if agent_id not in self.remote_agents:
            print(f"[❌] No connection to {agent_id}")
            return None
        
        sock = self.remote_agents[agent_id]['sock']
        
        # Create prediction request
        message = {
            'type': self.MSG_TYPES['PREDICT_REQUEST'],
            'text': text,
            'token': self.auth_token,
            'requester': id(self)
        }
        
        try:
            # Send via existing socket
            self._send_message(sock, message)
            
            # Wait for response
            response = self._receive_message(sock)
            
            if response and response.get('type') == self.MSG_TYPES['PREDICT_RESPONSE']:
                return response
            return None
            
        except Exception as e:
            print(f"[❌] Prediction request failed: {e}")
            return None

    def request_prediction_batch(self, agent_id: str, texts, timeout: float = 30.0) -> List[Any]:
        # Batch async prediction requests (parallelized)
        import concurrent.futures
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(texts)) as executor:
            futures = [
                executor.submit(self.request_prediction, agent_id, text, timeout)
                for text in texts
            ]
            results = [f.result(timeout=timeout) for f in futures]
        
        return results
    
    
    def start_queue_processor(self):
        # Start background queue processor
        self.queue_processor_thread = threading.Thread(target=self._process_outgoing_queue, daemon=True)
        self.queue_processor_thread.start()
    
    def _process_outgoing_queue(self):
        # Process queued outgoing messages
        while self.running:
            if self.outgoing_queue:
                msg = self.outgoing_queue.popleft()
                try:
                    self._send_message(msg['sock'], msg['message'])
                    if msg.get('callback'):
                        msg['callback'](True)
                except Exception as e:
                    if msg.get('callback'):
                        msg['callback'](e)
                    # Retry logic
                    if msg.get('retry_count', 0) < msg.get('max_retries', 3):
                        msg['retry_count'] = msg.get('retry_count', 0) + 1
                        self.outgoing_queue.append(msg)
            else:
                time.sleep(0.01)     

    
    def _start_health_checker(self):
        # Start background health checker for async mode.
        def health_check_loop():
            for _ in range(self._health_check_interval * 10):
                if not self.running:
                    return
                time.sleep(0.1)

            if self.running:
                self._check_agent_health()
        
        self._health_thread = threading.Thread(target=health_check_loop, daemon=True)
        self._health_thread.start()
    

    def _check_health(self):
        # Check health of all connected agents.
        stats = self.message_queue.get_status()
        logger.debug(f"[=] Queue stats: {stats}")
        
        # Check for stuck messages
        if stats.get('pending_count', 0) > 100:
            logger.warning(f"[=] High pending count: {stats['pending_count']}")
        
        # Ping all agents
        for agent_id in list(self.remote_agents.keys()):
            try:
                result = self.broadcast('ping', {}, timeout=5.0)
                if agent_id not in result or result[agent_id].get('error'):
                    logger.warning(f"[=] Agent {agent_id} not responding")
            except Exception as e:
                logger.warning(f"[=] Health check failed for {agent_id}: {e}")
    
    def get_queue_stats(self) -> Dict:
        # Get message queue statistics.
        return self.message_queue.get_status()
    
    def get_dead_letter_queue(self) -> List[Dict]:
        # Get failed messages for inspection.
        if hasattr(self.message_queue, 'get_dead_letter_queue'):
            return self.message_queue.get_dead_letter_queue()
        return []
    
    async def stop(self):
        # Graceful shutdown.
        logger.info("[=] Shutting down AgentDistributedInference...")
        self.running = False
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.call_soon_threadsafe(
                    lambda: asyncio.ensure_future(self.message_queue.stop())
                )
            else:
                loop.run_until_complete(self.message_queue.stop())
        except Exception as e:
            logger.warning(f"[=] Message queue stop warning: {e}")
        
        logger.info("[=] Shutdown complete")

    # ============ MESSAGE HANDLING ============


    def _send_message(self, sock, message):
        # Send message with signature and DOES NOT modify original
        if sock is None:
            print(f"[==] Send error: socket is None")
            return False
            
        # ✅ Check if socket is still connected
        try:
            sock.getpeername()
        except (socket.error, OSError, AttributeError) as e:
            print(f"[==] Send error: socket is dead - {e}")
            # Remove dead socket from remote_agents
            self._remove_dead_socket(sock)
            return False     

        try:
            msg_to_send = message.copy()  # ← Important: Copy!
            
            # Add signature to the copy
            msg_to_send['signature'] = self._sign_message(msg_to_send)

            sorted_msg = {k: msg_to_send[k] for k in sorted(msg_to_send.keys())}

            print(f'[==] Sending message, Total: {len(sorted_msg)}')   
            data = pickle.dumps(sorted_msg, protocol=pickle.HIGHEST_PROTOCOL)
            sock.send(len(data).to_bytes(4, 'big'))
            bytes_sent = 0
            while bytes_sent < len(data):
                chunk = data[bytes_sent:bytes_sent + self.CHUNK_SIZE]
                sock.send(chunk)
                bytes_sent += len(chunk)
                # Small delay to prevent buffer overflow
                if len(chunk) == self.CHUNK_SIZE:
                    time.sleep(0.001)
              
            print(f'[==] Message sent successfully')
            logger.info(f"[=] Message sent successfully: {sorted_msg}")
            return True
        except Exception as e:
            print(f"[==] Send error: {e}")
            traceback.print_exc()
            self._remove_dead_socket(sock)
            return False


    def _remove_dead_socket(self, sock):
        """Remove dead socket from remote_agents"""
        for agent_id, info in list(self.remote_agents.items()):
            if info.get('sock') == sock:
                print(f"[=] Removing dead connection to {agent_id}")
                del self.remote_agents[agent_id]
                break 

    def _receive_message(self, sock):
        # Receive message with signature verification
        try:
            print(f'[==] Server status: {self.running}')
            print(f'[=] Sock status: {sock}')

            if sock is None:
                print('[=] Sock is None !')
                return None

            try:
                data_len = sock.recv(4)
            except:
                data_len = sock.recv(10)

            print(f'[==] Data length received: {data_len}')
            if not data_len:
                print('[=] received empty message.')
                return None
            
            msg_len = int.from_bytes(data_len, 'big')
            if msg_len > self.max_message_size:
                print('[=] message size exceeds maximum to be handled')
                self.log_security_event('message_too_large', {'size': msg_len})
                return None

            data = b''
       
            while len(data) < msg_len:
                remaining = msg_len - len(data)
                chunk_size = min(self.CHUNK_SIZE, remaining)
                chunk = sock.recv(chunk_size)
                if not chunk:
                    print(f'[=] Connection closed while receiving')
                    return None
                data += chunk            
           
            message = pickle.loads(data)
        
            if "signature" in message:
                msg_for_verify = {k: v for k, v in message.items() if k != 'signature'}

                if not self._verify_signature(msg_for_verify, message['signature']):
                    logger.warning(f"[=] Invalid message signature from agent {self.temporary_agent_id}")
                    self._log_security_event('invalid_signature', {'agent_id': self.temporary_agent_id})
                    return None

            print('[= Message received]')
            return message

        except socket.timeout:
            print('[-] Socket timeout')
            return None
        except Exception as e:
            logger.error(f"[=] Receive error: {e}")
            traceback.print_exc()
            return None
    
    def _handle_client(self, client, addr):
        # Handle incoming messages from a connected client
        agent_id = f"{addr[0]}:{addr[1]}"
        self.temporary_agent_id = agent_id
        
        # Register this thread as the owner of this socket
        self.socket_owners[client] = threading.current_thread().name

        if addr[0] in ['127.0.0.1', 'localhost', 'local'] and addr[1] == self.port:
            print(f"[❌] Client is self, ignoring")
            client.close()
            return        
            
        if self._is_duplicate_connection(addr[0], addr[1]):
            print(f"[⚠️] Duplicate connection from {addr[0]}:{addr[1]}, rejecting")
            client.close()
            return
            
        # ✅ Prevent multiple connections from same host
        for existing_id, info in list(self.remote_agents.items()):
            if info.get('host') == addr[0]:
                print(f"[❌] Already have connection from {addr[0]}, rejecting new connection")
                client.close()
                return            

        while self.running:
            try:
                if 'request_id' in message:
                    continue 


                if not self._check_rate_limit(agent_id):
                    self._send_message(client, {'type': 'error', 'message': 'Rate limit exceeded'})
                    logger.info(f"[=##=] Rate limit exceeded for agent {agent_id}, request reduced.")
                    time.sleep(5)  # Sleep briefly to mitigate rapid retries
                    continue

                if message.get('type') == 2:  # PREDICT_RESPONSE
                    continue  # Skip, we'll read it in request_prediction_method

                message = self._receive_message(client) 
                self.temporary_message = message
                if message is None:
                    print('[-] Message is None.')
                    continue

                request_id = message.get('request_id')
                if request_id and request_id in self.pending_requests:
                    with self.request_lock:
                        future = self.pending_requests.get(request_id)
                        if future and not future.done():
                            future.set_result(message) 

                response = self._process_message(message, agent_id)
    
                print(f'[=~=] Got Response from client with address: {addr[0]}:{addr[1]}')
                if response:
                    print(f'[=] Sending response to client: {client}')
                    self._send_message(client, response)
                    logger.info(f'[=] Succesfully send response to client: {client}')
                else:
                    print("[SERVER] No response to send - ")
                    self._send_message(client, {'type': 'ack', 'status': 'ok'})

            except Exception as e:
                print(f"[=] Handler error for {agent_id}: {e}")
                break
        
        # Cleanup on disconnect
        if agent_id in self.remote_agents:
            print(f'[===] Removing Agent id: {agent_id}')            
            del self.remote_agents[agent_id]
        if client in self.connections:
            self.connections.remove(client)

        client.close()
        print(f"📡 Disconnected from {agent_id}")
    

    def _process_message(self, message, sender_id):
        # Process incoming messages based on type
        msg_type = message.get('type')
        
        if msg_type == self.MSG_TYPES['PREDICT_REQUEST']:
            return self._handle_predict_request(message, sender_id)

        elif msg_type == self.MSG_TYPES['MEMORY_SYNC_REQUEST']:
            return self._handle_memory_sync_request(message, sender_id)
        
        elif msg_type == self.MSG_TYPES['ENSEMBLE_VOTE_REQUEST']:
            return self._handle_ensemble_vote_request(message, sender_id)
        
        elif msg_type == self.MSG_TYPES['FAILURE_REPORT']:
            return self._handle_failure_report(message, sender_id)
        
        elif msg_type == self.MSG_TYPES['TRUST_UPDATE']:
            return self._handle_trust_update(message, sender_id)
        
        elif msg_type == self.MSG_TYPES['PING']:
            return {'type': self.MSG_TYPES['PONG'], 'timestamp': time.time()}
        
        elif msg_type == self.MSG_TYPES['DISCONNECT']:
            return None
        
        return {'type': 'ack', 'status': 'ok'}


    # ====== HANDLE PREDICTION AND UNCERTAINTY CALIBRATION ====== 
    def _check_trust_level(self, agent_id, required_trust=TrustLevel.STANDARD):
        # Check if agent has sufficient trust level for operation
        
        if agent_id not in self.trusted_agents:
            print(f"[-] Agent {agent_id} not trusted")
            return False
        
        agent_trust = self.trusted_agents[agent_id].get('trust_level', TrustLevel.BASIC)
        
        if agent_trust >= required_trust:
            return True
        else:
            print(f"[-] Agent {agent_id} trust level {agent_trust.name} < required {required_trust.name}")
            return False


    def _handle_peer_agent_request(self, probs, self_attn_weights, input_ids, type=None, agreement=False):

        # initiating peer agent request, establishing proper connections and process it.
        memory_exist = self.sync_with_local_peer(self.memory_name)   
        established_connection = self.query_node._establish_peer_nodes(self.temporary_agent_id)

        if established_connection:
            print(f'[||] Connection established and permitted with peer agent: {self.temporary_agent_id}')
            try:
                if memory_exist and type == 'DevicePeer':
                    target_preds, attn_weights = self.pipeline.storage.memory_retrieval(self.memory_name, type_func="Peer", verbose=False)
                    
                else:
                    # external peer communicates via socket
                    if type == "ExternalPeer":
                        try:
                            target_preds, attn_weights = self.get_external_peer_message()
                            if target_preds is None:
                                print('[-] Cant get viable components needed for processing request, returning regular probs...')
                                return probs

                        except Exception as e:
                            print(f'[-] No valid in device peer memory id found in database for memory name: {self.memory_name} and error: {e}')
                            return probs
                    else:
                        print('[-] Invalid type..., returning regular probs...')
                        return probs

                if not agreement:
                    probs = self.handle_peer_uncertainty(probs, target_preds, self_attn_weights, attn_weights, input_ids)
                else:
                    try:
                        probs = self.process_peer_request(probs, target_preds, self_attn_weights, input_ids)
    
                    except Exception as e:
                       print(f"[-] Error processing request: {e}, returning regular probs")

            except Exception as e:
                print(f'[-] Error handling request... {e}, returning regular probs')
                self.report_failure(id(self), 'processing', reason=f'{e}')                        

            print(f'[||] Successfully calibrate probs with previous Peer using database!')
            self.save_to_local_peer(self.memory_name, probs)
        else:
            print(f'[-] Connection to peer agent {self.temporary_agent_id} failed or not permitted, returning regular probs...')

        return probs


    def _calibrate_peer_probs(self, probs, target_preds, self_attn_weights, attn_weights, input_ids, AEL):
        eps = 1e-5
        calibrated = probs.copy()

        try:
            n_classes = probs.shape[1]
        except:
            n_classes = probs.shape[0]

        batch_size = len(target_preds)
        anisotropy = self.pipeline.anisotropy_measurement(attn_weights)  


        if isinstance(attn_weights, (str, np.str_)):
            clean_str = str(attn_weights).replace('[', '').replace(']', '')
            attn_weights = np.fromstring(clean_str, sep=' ')
        elif isinstance(attn_weights, np.ndarray) and np.issubdtype(attn_weights.dtype, np.character):
            # catches arrays filled with string text
            clean_str = ' '.join(attn_weights.astype(str).flatten()).replace('[', '').replace(']', '')
            attn_weights = np.fromiter(
                    (x for x in clean_str.split() if x != "..."), dtype=float
                ) 
        else:
            # Ensure standard float array if it was integers or objects
            attn_weights = np.asarray(attn_weights, dtype=float)

        target_preds = np.asarray(target_preds, dtype=np.float32)
    
        for i in range(batch_size):

            mlp_target = target_preds[i] if target_preds.ndim > 1 and target_preds.shape[0] > i else target_preds
            attn_target = attn_weights[i] if attn_weights.ndim > 1 and attn_weights.shape[0] > i else attn_weights
       
            if self_attn_weights is not None and i < len(attn_weights):
                attn = self_attn_weights[i]

                attn_quality = np.std(attn) if attn.size > 0.0 else AEL
                target_attention_quality = np.std(attn_target) if attn.size > 0.0 else AEL

                try:
                    target_attn_indices = np.argmax(attn_weights)
                    target_mlp_indices = np.argmax(mlp_target)
                except:
                    target_attn_indices = np.argmax(attn_weights, axis=1)
                    target_mlp_indices = np.argmax(mlp_target, axis=1)                    

                consensus = np.allclose(target_mlp_indices, target_attn_indices, atol=eps)

                justified = (1.0 - AEL) + (1.0 - attn_quality) * consensus
                boost = justified * anisotropy + eps

            else:
                attn_quality = 1.0 / (1.0 + np.exp(-self_attn_weights[i]))

                target_attn_indices = np.argmax(attn_weights, axis=1)
                target_prob_indices = np.argmax(probs, axis=1)

                consensus = np.allclose(target_prob_indices, target_attn_indices, atol=eps)

                justified = (1.0 - AEL) * consensus + eps
                boost = (1.0 + justified) * attn_quality + eps

            abstract_error_quality_score = (1.0 - attn_quality) * anisotropy + eps
            self.query_node.peer_trust = (1.0 - abstract_error_quality_score) + boost * justified 

            try:
                calibrated[i, mlp_target] = min(calibrated[i, mlp_target] * (1.5 * (1.0 - abstract_error_quality_score)), 0.95)
            except:
                return calibrated

            calibrated[i] /= calibrated[i].sum()


        return calibrated        
            

    def handle_peer_uncertainty(self, probs, target_preds, self_attn_weights, attn_weights, input_ids):
        # Handle uncertainty by measuring similarity and anisotropy, then decide whether to trust peer or calibrate with local data.
        try:
            if self_attn_weights is None:
                _, _, self_attn_weights = self.pipeline.model2.predict(input_ids)                
            batch_similarity = self.pipeline.cosine_similarity(attn_weights, self_attn_weights)
        
            anisotropy = self.pipeline.anisotropy_measurement(attn_weights)

            # AME is the Attention Modality Estimation, which estimates the reliability of the peer's attention based on its weights. It is then transformed into a trust score (AMR) using a sigmoid function.
            #  The final weighted similarity combines the original similarity with the trust score and anisotropy to determine how much to rely on the peer's information versus local data. If the weighted similarity is high, we trust the peer's prediction; if it's low, we calibrate using local data.
            AME = self.pipeline.AME_Encoder(attn_weights)
            AMR = 1.0 / (1.0 + np.exp(-AME))
            weighted_similarity = batch_similarity * (1.0 - AMR) * anisotropy

            if weighted_similarity > 0.75:
                return self.process_peer_request(probs, target_preds, attn_weights, input_ids)
            else:
                print('[-] Low uncertainty, normalizing with local agent data...')

                AEL = 0.3 + weighted_similarity * anisotropy
                calibrated = self._calibrate_peer_probs(probs, target_preds, self_attn_weights, attn_weights, input_ids, AEL)
                return calibrated

        except Exception as e:
            print(f"[-] Error in uncertainty handling: {e}")
            return probs


    def process_peer_request(self, probs, target_preds, attn_weights, input_ids):
        try:
            response_probs = self.pipeline._calibrate_probs(probs, target_preds, attn_weights, input_ids)
            return response_probs
        except Exception as e:
            print(f"[-] Error in peer request_processing: {e}")
            return None
            

    # ============ REQUEST HANDLERS ============
    def get_external_peer_message(self):
        # Get message from external peer (via socket) and extract attention weights and target predictions for processing.
        message = self.temporary_message
        if not message:
            print('[-] No viable messages')
            return None, None

        try:
            attn_weights = message.get('attn_weights')
            target_preds = message.get('target_preds')
            if not attn_weights:
                print('|| Invalid format of message, may be a Nonetype object...')
                return None, None
            return attn_weights, target_preds

        except Exception as e:
            print(f'[-] Cant get external peer message: {e}')
            return None, None
         
    
    def _handle_predict_request(self, message, sender_id, method='basic_prediction'):
        # Handle prediction request from another agent, with trust and rate limit checks.
        if not self._check_trust_level(sender_id, TrustLevel.STANDARD):
            return {'type': 'error', 'message': 'Insufficient trust level'}           
                         
        if method == 'basic_prediction' and self.predict_manager is None:
            text = message.get('text')
            if not text:
                return {'type': self.MSG_TYPES['PREDICT_RESPONSE'], 'error': 'No text provided'}
            
            text = self._sanitize_input(text)
            if not self._check_rate_limit(sender_id):
                return {'type': self.MSG_TYPES['PREDICT_RESPONSE'], 'error': 'Rate limit exceeded'}

            try:
                result = self.pipeline.predict_single(text)
            
                # Log the interaction
                self._log_interaction(sender_id, 'prediction', result['confidence'])
                
                return {
                    'type': self.MSG_TYPES['PREDICT_RESPONSE'],
                    'prediction': result['prediction'],
                    'confidence': result['confidence'],
                    'probabilities': result.get('probabilities', []),
                    'agent_id': id(self)
                }
            except Exception as e:
                print(f"[-] Prediction error: {e}")
                return {'type': self.MSG_TYPES['PREDICT_RESPONSE'], 'error': str(e)}

        else:
            titles = message.get('test_titles')
            label_map = message.get('label_map')
            rules = message.get('rules')
            if not titles and label_map and rules:
                return {'type': self.MSG_TYPES['PREDICT_RESPONSE'], 'error': 'No test titles provided'}
            
            titles = self._sanitize_arrays_and_dicts(titles)
            label_map = self._sanitize_arrays_and_dicts(label_map)
            rules = self._sanitize_arrays_and_dicts(rules)

            if not self._check_rate_limit(sender_id):
                return {'type': self.MSG_TYPES['PREDICT_RESPONSE'], 'error': 'Rate limit exceeded'}

            try:
                result, chosen_label, confidence = self.predict_manager.advanced_prediction_method(titles, label_map, rules, show_proba=True, use_transformer=self.pipeline.use_transformer)
            
                # Log the interaction
                self._log_interaction(sender_id, 'prediction', confidence)
                
                return {
                    'type': self.MSG_TYPES['PREDICT_RESPONSE'],
                    'prediction': chosen_label,
                    'confidence': confidence,
                    'probabilities': result,
                    'agent_id': id(self)
                }

            except Exception as e:
                print(f"[-] Advanced prediction error: {e}")
                return {'type': self.MSG_TYPES['PREDICT_RESPONSE'], 'error': str(e)}

    def _handle_memory_sync_request(self, message, sender_id):
        # Handle memory sync request from another agent, with trust checks and support for both local and external peers.
        memory_name = message.get('memory_name')
        if not memory_name:
            return {'type': self.MSG_TYPES['MEMORY_SYNC_RESPONSE'], 'error': 'No memory name'}
        
        try:
            # For local peer (database)
            if message.get('peer_type') == 'local':
                memory_data = self.pipeline.storage.load_model_dict(memory_name)
            else:
                # For external peer
                memory_data = self.pipeline.memory.get(memory_name, {})
            
            return {
                'type': self.MSG_TYPES['MEMORY_SYNC_RESPONSE'],
                'memory_name': memory_name,
                'data': memory_data,
                'timestamp': time.time()
            }
        except Exception as e:
            return {'type': self.MSG_TYPES['MEMORY_SYNC_RESPONSE'], 'error': str(e)}



    def _handle_ensemble_vote_request(self, message, sender_id):
        # Handle ensemble vote request from another agent
        text = message.get('text')
        if not text:
            return {'type': self.MSG_TYPES['ENSEMBLE_VOTE_RESPONSE'], 'error': 'No text provided'}
        
        try:
            result = self.pipeline.predict_single(text)
            
            return result['prediction'], {
                'type': self.MSG_TYPES['ENSEMBLE_VOTE_RESPONSE'],
                'prediction': result['prediction'],
                'confidence': result['confidence'],
                'agent_id': id(self),
                'trust_score': self.remote_agents.get(sender_id, {}).get('trust', 1.0)
            }
        except Exception as e:
            return None, {'type': self.MSG_TYPES['ENSEMBLE_VOTE_RESPONSE'], 'error': str(e)}
    
    def _handle_failure_report(self, message, sender_id):
        # Handle failure report from another agent

        failed_agent = message.get('failed_agent')
        task_type = message.get('task_type')
        failure_reason = message.get('reason', 'unknown')
        
        # Update trust for the failed agent
        if failed_agent in self.remote_agents:
            self.remote_agents[failed_agent]['failures'] += 1
            self.remote_agents[failed_agent]['trust'] = max(
                0.1, 
                1.0 - (self.remote_agents[failed_agent]['failures'] / 10)
            )
        
        # Log the failure
        self._log_interaction(failed_agent, 'failure', confidence=0, details={
            'task_type': task_type,
            'reason': failure_reason,
            'reported_by': sender_id
        })
        
        return {'type': 'ack', 'status': 'failure_recorded'}


    
    def _handle_trust_update(self, message, sender_id):
        # Handle trust score update
        target_agent = message.get('target_agent')
        new_trust = message.get('trust_score')

        self.query_node.peer_trust = new_trust
        
        if target_agent in self.remote_agents:
            self.remote_agents[target_agent]['trust'] = new_trust
        
        return {'type': 'ack', 'status': 'trust_updated'}


    # ============ REQUEST SENDING METHODS ============       
    def request_prediction_method(self, agent_id, text, timeout=5):
        if agent_id == 'local':
            result = self.pipeline.predict_single(text)
            return result

        if agent_id not in self.remote_agents:
            print(f"Agent {agent_id} not connected")
            return None
        
        sock = self.remote_agents[agent_id]['sock']
        request_id = str(uuid.uuid4())[:8]
            
        message = {
            'type': self.MSG_TYPES['PREDICT_REQUEST'],  # 1
            'text': text,
            'request_id': request_id,  # ← Add request ID!
            'token': self.auth_token,
            'timestamp': time.time()
        }
                
        try:
            sock.settimeout(timeout)
            self._send_message(sock, message)
            response = self._receive_message(sock)
            sock.settimeout(None)
            
            if response and response.get('type') == self.MSG_TYPES['PREDICT_RESPONSE']:
                return response
            return None
        except Exception as e:
            print(f"Request failed for {agent_id}: {e}")
            return None
    
    def request_ensemble_vote(self, agent_id, text, timeout=5):
        if agent_id not in self.remote_agents:
            return None
        
        sock = self.remote_agents[agent_id]['sock']
        message = {
            'type': self.MSG_TYPES['ENSEMBLE_VOTE_REQUEST'],
            'text': text
        }
        
        try:
            sock.settimeout(timeout)
            self._send_message(sock, message)
            response = self._receive_message(sock)
            sock.settimeout(None)
            
            if response and response.get('type') == self.MSG_TYPES['ENSEMBLE_VOTE_RESPONSE']:
                return response['prediction'], response['text']
            return None, None
        except Exception as e:
            print(f"Vote request failed: {e}")
            return None, None
    
    def sync_memory_with_agent(self, agent_id, memory_name, timeout=10):
        if agent_id not in self.remote_agents:
            return None
        
        sock = self.remote_agents[agent_id]['sock']
        message = {
            'type': self.MSG_TYPES['MEMORY_SYNC_REQUEST'],
            'memory_name': memory_name,
            'peer_type': 'external'
        }
        
        try:
            sock.settimeout(timeout)
            self._send_message(sock, message)
            response = self._receive_message(sock)
            sock.settimeout(None)
            
            if response and response.get('type') == self.MSG_TYPES['MEMORY_SYNC_RESPONSE']:
                return response.get('data', {})
            return None
        except Exception as e:
            print(f"Memory sync failed: {e}")
            return None
    
    def report_failure(self, agent_id, task_type, reason="unknown"):
        report = {
            'type': self.MSG_TYPES['FAILURE_REPORT'],
            'failed_agent': agent_id,
            'task_type': task_type,
            'reason': reason,
            'timestamp': time.time()
        }
        
        # Send to all other agents
        for other_id, agent_info in list(self.remote_agents.items()):
            if other_id != agent_id:
                self._send_message(agent_info['sock'], report)
    
    def broadcast_ping(self):
        # Check which agents are still alive
        alive_agents = []
        for agent_id, agent_info in list(self.remote_agents.items()):
            try:
                sock = agent_info['sock']
                self._send_message(sock, {'type': self.MSG_TYPES['PING']})
                response = self._receive_message(sock)
                if response and response.get('type') == self.MSG_TYPES['PONG']:
                    alive_agents.append(agent_id)
                    agent_info['last_seen'] = datetime.now()
                else:
                    # Agent dead, remove
                    print(f'[===] Removing Agent id: {agent_id}')                    
                    del self.remote_agents[agent_id]
            except:
                print(f'[===] Removing Agent id: {agent_id}')                
                del self.remote_agents[agent_id]
        
        return alive_agents
    
    # ============ LOCAL PEER (DATABASE) METHODS ============
    
    def sync_with_local_peer(self, memory_name):
        try:
            memory_exist = self.pipeline.storage.memory_exists(self.memory_name, type='Peer')
            if memory_exist:
                memory_data = self.pipeline.storage.memory_retrieval(self.pipeline.memory_name, type_func="Peer", verbose=False)
                print(f'|| Retrieved memory, Samples: {len(memory_data)}')

            try:
                if memory_exist and memory_data:
                    # Merge with current memory
                    print('[=] Syncing with local peer memory data...')
                    try:
                        for key, value in memory_data.items():
                            if key not in self.pipeline.memory:
                                self.pipeline.memory[key] = value
                    except Exception as e:
                        print(f'|| Using sync memory function because of {e} problem in regular syncing using value in items.')
                        agent_id = self.temporary_agent_id
                        self.sync_memory_with_agent(agent_id, memory_name)

                    print(f"✅ Synced with local peer: {len(memory_data)} memories")
            except:
                print(f'[-] Failed converting and syncing with peer, but memory exist is assured.')
            memory_exist = True
            return memory_exist

        except Exception as e:
            print(f"Local peer sync failed: {e}")
            memory_exist = False

        print(f'|| Memory Exist: {memory_exist}')
        
        return memory_exist
    
    def save_to_local_peer(self, memory_name, data):
        try:
            self.pipeline.storage.save_model_dict(memory_name, data)
            print(f"✅ Saved local peer presence: {memory_name}")
            return True
        except Exception as e:
            print(f"Save to local peer failed: {e}")
            return False
    
    # ============ UTILITY METHODS ============
    
    def _log_interaction(self, agent_id, interaction_type, confidence, details=None):
        if agent_id not in self.agent_comm_log:
            self.agent_comm_log[agent_id] = []
        
        self.agent_comm_log[agent_id].append({
            'timestamp': datetime.now(),
            'type': interaction_type,
            'confidence': confidence,
            'details': details
        })
    
    def get_agent_status(self):
        status = {}
        for agent_id, info in list(self.remote_agents.items()):
            status[agent_id] = {
                'connected': True,
                'trust': info['trust'],
                'failures': info['failures'],
                'last_seen': info['last_seen'].isoformat(),
                'host': info['host'],
                'port': info['port']
            }
        return status
    
    def get_communication_log(self, agent_id=None, limit=50):
        # Get communication log for an agent
        if agent_id:
            return self.agent_comm_log.get(agent_id, [])[-limit:]
        
        # Return all logs
        return self.agent_comm_log
    
    def print_network_status(self):
        print("\n" + "="*60)
        print("🤖 == AGENT NETWORK STATUS ==")
        print("="*60)
        print(f"[=] Local Agent: {self.memory_name}")
        print(f"[=] Port: {self.port}")
        print(f"[=] Connected Agents: {len(self.remote_agents)}")

        agent_id = self.temporary_agent_id
        comm_log = self.get_communication_log(agent_id)
        
        for agent_id, info in self.remote_agents.items():
            print(f"\n  📡 {agent_id}")
            print(f"     Trust: {info['trust']:.2f}")
            print(f"     Failures: {info['failures']}")
            print(f"     Last seen: {info['last_seen'].strftime('%H:%M:%S')}")
            print(f"     Agent Communication Log: {comm_log}")
        
        print("="*60)

# The QueryNode class manages the connection and interaction with other nodes (agents) in the network. It handles node identification, agreement evaluation, safety checks, and maintains a memory of connected nodes. 
# The class allows for flexible interactions while ensuring the safety and integrity of the Master node.
class QueryNode:
    def __init__(self, pipeline, memory_name, storage):
        self.master_node = pipeline
        self.memory_name = memory_name
        self.storage = storage
        self.agreement = False

        if not self.storage.memory_exists(self.memory_name, type='Node'):
            print(f"|| Creating new memory for Nodes population: {memory_name}!")
            self.nodes = {}
        else:
            print(f'|| Found Matched Memory for Nodes : {memory_name}!')
            self.nodes = self.storage.memory_retrieval(self.memory_name, type_func='Node', verbose=True)

        self.master_nodes_id = 0
        self.safety_check_value = 0.0
        self.node_id = 0
        self.peer_trust = 1.0

        self.permission = False

    def _add_node(self, node):
        node_id = id(node)

        self.nodes[node_id] = node
        print(f"✅ Node {node_id} added to QueryNode")

        return node_id

    def _save_node_memory(self, node):
        try:
            node_id = id(node)
            self.master_node.storage.save_nodes_dict(self.memory_name, self.nodes, node_id, model_type='Node')

            print(f"[💾] Node {node_id} memory saved to storage!")
            return True
        except Exception as e:
            print(f"[-] Error saving node memory: {e}")
            return False


    def _evaluate_node_agreement(self, node):
        print(f"[=] Evaluating node {id(node)} || agreement: {self.agreement} || Master Node memory: {self.memory_name}")
        self.agreement_threshold = (self.master_node.confidence_threshold + self.master_node.final_conf_score * self.master_node.temperature)

        if self.agreement or self.agreement_threshold > self.master_node.confidence_threshold:
            print(f"[✅] Node {id(node)} is in agreement with the Master node")
            return True

        print(f"[-] Node {id(node)} is NOT in agreement with the Master node")
        return False


    def _connect_with_node(self, node):
        self.agreement = self.master_node.agreement

        if not self._identify_node(node):
            node_id = self._add_node(node)

        node_id = id(node)
        agreement = self._evaluate_node_agreement(node)
        safety = self._node_safety_check(node)

        # stable Node is established if either agreement is met or safety check is passed, allowing for some flexibility in interactions while still protecting the Master node from harmful interactions
        if safety or agreement:
            print(f"[🔗] Node {node_id} successfully connected to the Master node")
            self.permission = True
        else:
            print(f"[⚠️] Node {node_id} connection failed due to Disagreement")
            self.permission = False

        print('== Connection Evaluation Summary ==')
        print(f'[=] Node {node_id}')
        print(f'[=] agreement: {agreement}')
        print(f'[=] safety: {safety} || permission: {self.permission}')
 
        return self.permission

    def _connect_with_peer(self, node):
        self.agreement = self.master_node.agreement

        if not self._identify_node(node):
            node_id = self._add_node(node)

        node_id = id(node)
        agreement = self._evaluate_node_agreement(node)
        safety = self._node_safety_check(node)

        # peer agreement is optional to allow for more flexible interactions, but safety check is still enforced to protect the Master node from harmful interactions
        if safety or agreement:
            print(f"[🔗] Peer with ID: {node_id} successfully connected to the Master node")
            self.permission = True
        else:
            print(f"[⚠️] Peer with ID: {node_id} connection failed due to Disagreement")
            self.permission = False
 
        return self.permission        

    def _identify_node(self, node):
        eps = 1e-5
        print(f"[||] Identifying node {id(node)} with Master node memory: {self.memory_name}")
        identified_nodes = [(nid, n) for nid, n in self.nodes.items() if n == node]
        if identified_nodes:
            for node in identified_nodes:
                print(f"✅ Node {id(node)} is already identified with the Master node")
                self.safety_check_value = (self.master_node.final_conf_score + self.master_node.temperature) + eps
                return True
        else:
            print(f"[-] Node {id(node)} is NOT identified with the Master node")
            self.safety_check_value = (1.0 - self.master_node.final_conf_score + self.master_node.temperature) + eps
            return False


    def _node_safety_check(self, node):
        print(f"[🛡️] Performing safety check for node {id(node)} with safety value: {self.safety_check_value}")
        if self.safety_check_value > self.master_node.confidence_threshold:
            print(f"✅ Node {id(node)} passed the safety check")
            return True
        else:
            print(f"[-] Node {id(node)} failed the safety check")
            if self.safety_check_value < (self.master_node.confidence_threshold / 2):
                print(f"[⚠️] Node {id(node)} is considered useless and will be removed")
                removed = self._remove_node(node)
                return removed

            return False

    def _remove_node(self, node):
        node_id = id(node)
        if node in self.nodes:
            del self.nodes[node_id]
            print(f"[🗑️] Node {node_id} removed from Nodes population")
            return True
        else:
            print(f"[-] Node {node_id} not found in Nodes population")
            return False

    def _node_activation(self, Node):
        try:
            if self.permission:
                print(f"🚀 Node {id(Node)} is now active with the Master node")
                return True
            else:
                print(f"[-] Node {id(Node)} cannot be activated due to lack of permission")
                return False
        except Exception as e:
            print(f"[-] Error during node activation: {e}")
            return False

    def _identify_peer_trust(self, peer):
        print(f"[=] Identifying peer node {id(peer)} trustworthiness with Master node memory: {self.memory_name}")
        if self.peer_trust > self.master_node.confidence_threshold:
            print(f"[✅] Peer node {id(peer)} is identified as trustworthy with trust score: {self.peer_trust:.2f}")
            return True
        else:
            print(f"[-] Peer node {id(peer)} is NOT identified as trustworthy with trust score: {self.peer_trust:.2f}")
            return False

    def _establish_peer_nodes(self, peer):
        print(f"[=] Establishing peer node connection with peer with memory: {self.memory_name}")
        if self._connect_with_peer(peer) and self._identify_peer_trust(peer):
            print(f"[✅] Peer node {id(peer)} is now connected and can interact with the Master node")
        else:
            print(f"[-] Peer node {id(peer)} cannot interact with the Master node due to failed agreement")

        activation = self._node_activation(peer)
        saved = self._save_node_memory(peer)
        return activation

    def _establish_node_connection(self, node):
        if self._connect_with_node(node):
            print(f"[✅] Node {id(node)} is now connected and can interact with the Master node")
        else:
            print(f"[-] Node {id(node)} cannot interact with the Master node due to failed agreement")

        activation = self._node_activation(node)
        saved = self._save_node_memory(node)
        return activation




# The AutoBatcherAutomation class manages the batching of incoming prediction requests to optimize processing efficiency. 
# It collects requests over a short time window or until a maximum batch size is reached, then processes them together through the pipeline. This allows for improved throughput while still providing timely responses to individual requests.
class AutoBatcherAutomation:
    '''
    Dynamic micro-batching layer that buffers incoming prediction requests and
    processes them in groups for throughput efficiency.

    Batching strategy
    -----------------
    Requests are pushed onto a deque via add_request().  A background daemon
    thread (_process_batches) wakes every max_wait_ms milliseconds, drains up
    to max_batch_size requests from the deque, and calls
    pipeline.prediction_batch() on the group.

    Results are either:
      - Delivered to the caller's optional callback function, or
      - Stored in self.results[request_id] for polling via get_result().

    The thread exits automatically when the deque is empty (no idle spinning).

    Parameters
    ----------
    pipeline        : IntegratedPipeline — provides prediction_batch().
    max_batch_size  : Maximum number of requests per batch (default 32).
    max_wait_ms     : Maximum time to wait before flushing a partial batch,
                      in milliseconds (default 50 ms).
    '''
    def __init__(self, pipeline, max_batch_size=32, max_wait_ms=50):
        self.pipeline = pipeline
        self.dataset = None
        self.max_batch_size = max_batch_size
        self.max_wait_ms = max_wait_ms
        
        self.request_queue = deque()
        self.processing = False
        self.results = {}
        self.next_id = 0
    
    def add_request(self, text, callback=None):
        request_id = self.next_id
        self.next_id += 1
        
        self.request_queue.append({
            'id': request_id,
            'text': text,
            'callback': callback,
            'timestamp': time.time()
        })
        
        if not self.processing:
            self._start_processing()
        
        return request_id
    
    def _start_processing(self):
        self.processing = True
        thread = threading.Thread(target=self._process_batches, daemon=True)
        thread.start()
    
    def _process_batches(self):
        while self.request_queue:
            # Wait for more requests or max wait time
            time.sleep(self.max_wait_ms / 1000)
            dataset = self.dataset
            
            # Collect batch
            batch = []
            while self.request_queue and len(batch) < self.max_batch_size:
                batch.append(self.request_queue.popleft())
            
            if batch:
                self._process_batch(batch)
        
        self.processing = False
    
    def _process_batch(self, batch):
        texts = [req['text'] for req in batch]
        
        results = self.pipeline.prediction_batch(texts)
        
        # Send results back
        for i, req in enumerate(batch):
            result = results[i] if i < len(results) else None
            if req['callback']:
                req['callback'](result)
            else:
                self.results[req['id']] = result
    
    def get_result(self, request_id, timeout=5):
        start = time.time()
        while request_id not in self.results:
            if time.time() - start > timeout:
                return None
            time.sleep(0.01)
        return self.results.pop(request_id)


# The IntegratedPipeline class serves as the central component that integrates all the different modules and functionalities of the system.
# It manages the overall workflow, including data processing, model training, prediction, memory management, and interactions with other agents.
class IntegratedPipeline:
    '''
    Top-level pipeline that wires together all subsystems.

    Component map
    -------------
    self.mlp            : MLP — primary TF-IDF-based classifier.
    self.focused_mlp    : MLP — secondary "focused" MLP for fine-tuning.
    self.model2         : Transformer — token-sequence-based classifier.
    self.model3         : MLP — trained on hybrid (TF-IDF + Transformer) features.
    self.tfidf          : TfidfVectorizer(max_features=70) — shared feature extractor.
    self.storage        : ModelStorage — SQLite persistence.
    self.distribution   : AgentDistributedInference — P2P networking.
    self.batcher        : AutoBatcherAutomation — dynamic batching.
    self.query_node     : QueryNode — peer node registry.

    Singleton behaviour
    -------------------
    The class checks for self._singleton_initialized to prevent double-init
    when the same instance is passed across modules.  The singleton is NOT
    enforced at the metaclass level, so multiple independent instances can
    exist (each with a different memory_name).

    Training flow
    -------------
    1. train(X, y_raw)          — fits TF-IDF, encodes labels, trains MLP.
    2. transformer_utilities()  — (called internally) checks training necessity,
                                  trains Transformer, builds hybrid features,
                                  trains model3 on the concatenated feature space.

    Prediction flow
    ---------------
    predict_single(text)        — returns a dict with prediction, confidence,
                                  probabilities, and optional attention weights.
    prediction_batch(texts)     — calls predict_single in a list comprehension.
    _calibrate_probs()          — post-hoc confidence calibration using
                                  attention quality, anisotropy, and peer data.

    Memory / persistence
    --------------------
    On construction the pipeline checks whether a saved model exists for
    memory_name.  If found it loads weights and validates them via
    is_memory_corrupted().  Predictions are written back through
    modular_prediction_saving() / modular_probability_saving().

    Parameters
    ----------
    memory_name       : Logical name for DB scoping and model identity.
    use_async         : If True, sets up an AsyncMessageQueue for non-blocking
                        distributed operations.
    agent_port        : TCP port for AgentDistributedInference (None = disabled).
    ssl_cert_file     : TLS certificate for encrypted agent comms.
    ssl_key_file      : TLS private key for encrypted agent comms.
    secret_key        : HMAC key for message signing.
    shared_auth_token : Shared secret for peer agent authentication.
    predict_manager   : Optional PipelinePredictionManager reference (set after
                        construction to avoid circular initialisation).
    cache = to store lstm memory or bins.
    '''
    def __init__(self, memory_name, use_async, agent_port=None, ssl_cert_file=None, ssl_key_file=None, secret_key=None, shared_auth_token=None, predict_manager=None):
        super().__init__()

        if hasattr(self, '_singleton_initialized'):
            print(f"[===] IntegratedPipeline already initialized, reusing...")
            return
        
        self._singleton_initialized = True
        
        # Stored initialization params for debugging later
        self._init_params = {
            'memory_name': memory_name,
            'port': agent_port,
            'secret_key': secret_key,
            'ssl_cert_file': ssl_cert_file,
            'ssl_key_file': ssl_key_file,
            'shared_auth_token': shared_auth_token
        }  

        self.ssl_cert_file = ssl_cert_file
        self.ssl_key_file = ssl_key_file
        self.secret_key = secret_key
        self._use_async = use_async
        self.port = agent_port
        self.shared_auth_token = shared_auth_token
        self.manager = None

        self.standard_scaler = StandardScaler()
        self.tfidf = TfidfVectorizer(max_features=70)
        self.storage = ModelStorage(self, memory_name, db_path='activity_log.db')
        self.distribution = AgentDistributedInference(self, self.storage, memory_name, port=self.port, use_async=use_async, secret_key=self.secret_key, ssl_cert_file=ssl_cert_file, ssl_key_file=ssl_key_file, shared_auth_token=self.shared_auth_token, predict_manager=self.manager)        
        self.ensemble = WeightedEnsemblePredictor(self, self.distribution, memory_name)        
        self.session_automation = CrossSessionAutomation(self)
        self.batcher = AutoBatcherAutomation(self)
        self.query_node = QueryNode(self, memory_name, self.storage)
        
        self._agent_mode = 'single'
        self._agent_port = int(agent_port) if int(agent_port) is not None else 5000
        self._use_async = use_async

        print(f'[= PORT =] IntegratedPipeline initialized on port {self._agent_port}')
         
        # Queue for managing async operations
        self._async_tasks = set()
        self._loop = None  

        self.mlp = MLP()
        self.focused_mlp = MLP()

        self.X = None
        self.vocab_size = None
        self.model2 = None
        self.model3 = None
        self.texts = None
        self.intents = None
        self.role_bot = None
        self.batch_timer = None
        self.reverse_map = None
        self.rules = None
        self.titles = None
        self.labels = None

        self.use_transformer = False
        self.agreement = False
        self.external_peer_enabled = False
        self.autonomous = False 
        self.show_explainability_details = True   
        self.froze_learning = False  

        self.temperature = 1.0
        self.memory_name = memory_name

        self.pending_batch = []
        self.temporary_id = []

        self.input_size = 1
        self.hidden = 32
        self.output_size = 1
        self.dropout_rate = 0.1

        self.final_conf_score = 0.0
        self.timeout = 120
        self.confidence_threshold = 0.45  
        self.peer_assistance_threshold = 0.0              
        self.agent_id = random.randint(0, 10000)

        self.vocab = {}
        self.cache = {}

        # LSTM __init__ setup for lstm architectures
        self.network_model = LSTMNetwork(self, input_size=self.input_size, hidden_size=self.hidden, output_size=self.output_size)
        self.scrapper_model = LSTMEngine(self, self.network_model, dropout=self.dropout_rate, n_samples=50)        
        self.lstm_engine = None
        self.lstm_n_samples = 0
     
        if not self.storage.memory_exists(memory_name, type='Pipeline'):
            self.memory = {}
        else:
            print(f'|| Found Matched Memory: {memory_name}!')
            self.memory = self.storage.memory_retrieval(memory_name, type_func='Pipeline', verbose=True)

            is_corrupted, reason, suggested_fix = self.is_memory_corrupted(self.memory)
            if is_corrupted:
                print(f'[⚠️] MEMORY CORRUPTION DETECTED!')
                print(f'    Reason: {reason}')
                print(f'    Suggestion: {suggested_fix}')
                
                # Auto-fix based on severity
                if '133' in reason:
                    print(f'[!] Hybrid feature detected - clearing all memory entries')
                    self.memory = {}
                    # Also clear from storage
                    self.storage.fix_corrupted_memory(memory_name)
                elif 'deserialization' in reason.lower():
                    print(f'[!] Deserialization error - resetting memory')
                    self.memory = {}
                else:
                    print(f'[!] Keeping memory but will validate on access')
            else:
                print(f'[✅] Memory validation passed: {reason}')              

        if use_async:
            self._setup_async_queue()
            
        self.distribution.remote_agents['local'] = {
            'sock': None,  # No socket needed for local
            'host': 'localhost',
            'port': self.port,
            'trust': 1.0,
            'last_seen': datetime.now(),
            'failures': 0
        }

    def is_memory_corrupted(self, memory, num_classes: int = None) -> tuple:
        """
        Robust memory corruption detection.
        
        Returns:
            (is_corrupted: bool, reason: str, suggested_fix: str)
        """
        if num_classes is None:
            num_classes = self._get_num_classes()
        
        # Case 1: Memory is None
        if memory is None:
            return (True, "Memory is None", "Initialize new memory dict")
        
        # Case 2: Memory is numpy array
        if isinstance(memory, np.ndarray):
            # Valid probability array
            if memory.ndim == 1 and memory.shape[0] == num_classes:
                return (False, "Valid probability array", None)
            
            # Valid probability matrix (batch)
            if memory.ndim == 2 and memory.shape[1] == num_classes:
                return (False, "Valid probability matrix", None)
            
            # Hybrid features - NOT corrupted, just wrong type
            if memory.shape[0] != self._get_num_classes():
                return (True, f"[=] Hybrid feature array (shape {memory.shape}) stored as memory", 
                    "Clear and retrain, or convert to probability array")
            
            # Other shapes
            return (True, f"[=] Unexpected array shape: {memory.shape}", 
                "Clear memory and retrain model")
        
        # Case 3: Memory is list
        if isinstance(memory, list):
            if not memory:
                return (True, "[=] Empty list", "Initialize new memory dict")
            
            # List of probabilities
            if len(memory) == num_classes:
                # Check if all elements are numbers
                if all(isinstance(x, (int, float)) for x in memory[:min(5, len(memory))]):
                    return (False, "[=] Valid probability list", None)
            
            # List of hybrid features 
            if len(memory) != self._get_num_classes():
                return (True, f"[=] Hybrid feature list with length: {len(memory)} stored as memory", 
                    "Clear memory and retrain")
            
            # List of tuples (likely valid memory entries)
            if all(isinstance(item, (tuple, list)) and len(item) >= 2 for item in memory[:min(5, len(memory))]):
                return (False, "[=] Valid memory entries list", None)
            
            # Check for numpy arrays in list
            if any(isinstance(item, np.ndarray) for item in memory):
                arrays = [item.shape for item in memory if isinstance(item, np.ndarray)]
                if any(shape[0] == num_classes for shape in arrays):
                    return (False, "[=] Valid with numpy arrays", None)
            
            return (True, f"[=] Suspicious list length: {len(memory)}", 
                "Inspect memory contents")
        
        # Case 4: Memory is dict (expected format)
        if isinstance(memory, dict):
            # Empty dict is fine (no memory yet)
            if not memory:
                return (False, "[=] Empty dict (no memory)", None)
            
            # Check for valid keys
            valid_keys = {'TW', 'MW', 'TP', 'MP', 'TA', 'local', '_cached_probs', '_data'}
            
            for key, value in memory.items():
                # Skip valid keys
                if key in valid_keys or key.startswith(('TW', 'MW', 'TP', 'MP', 'TA')):
                    continue
                
                # Suspicious key
                if isinstance(key, (int, float)):
                    return (True, f"[=] Dict has numeric key: {key}", 
                        "Likely deserialization error, clear memory")
                
                if len(str(key)) > 100:
                    return (True, f"[=] Dict has very long key: {len(str(key))} chars", 
                        "Possible corruption, clear memory")
            
            # Check values in dict
            for key, value in memory.items():
                # Check for corrupted array values
                if isinstance(value, np.ndarray):
                    if value.shape != self._get_num_classes:
                        return (True, f"[=] Array with shape {value.shape} in dict key '{key}'", 
                            "Hybrid feature stored incorrectly, clear entry")
                    
                    if value.shape == (0,):
                        return (True, f"[=] Empty array in dict key '{key}'", 
                            "Corrupted array, clear entry")
                
                # Check for corrupted list values
                if isinstance(value, list) and len(value) == 133:
                    return (True, f"[=] List with length 133 in dict key '{key}'", 
                        "Hybrid feature stored incorrectly, clear entry")
            
            return (False, "Valid dict structure", None)
        
        # Case 5: Memory is other type
        return (True, f"Unexpected memory type: {type(memory)}", 
            "Clear and reinitialize memory")


    def initialize_fitting(self, text):
        self.tfidf.fit_transform(text).toarray()
        vocab_size = len(self.tfidf.get_feature_names_out())
        self.vocab_size = vocab_size
        

    def initialize_model_encoding(self, X, y_raw):
        vocab_size = self.vocab_size

        num_classes = len(np.unique(y_raw))
        y_onehot = np.zeros((len(y_raw), num_classes))
        y_onehot[np.arange(len(y_raw)), y_raw] = 1

        automatic_change = self.automatic_parameterization(vocab_size, num_classes)
        self.embedding_dim = automatic_change
        layer1, layer2 = self.automatic_dense_layer(X, vocab_size, num_classes)

        model = self.mlp  

        model.add(layer1)
        model.add(layer2)

        return y_onehot



    def initialize_model_(self, X, input_dim, num_classes):
        automatic_change = self.automatic_parameterization(input_dim, num_classes)

        automatic_change = self.automatic_parameterization(input_dim, num_classes)

        layer1= Dense(X, input_dim, automatic_change, activation="relu")
        layer2 = Dense(X, automatic_change, num_classes, activation='relu')

        abundant_layer = automatic_change * 10
        first_feed_layer = Dense(X, input_dim, abundant_layer, activation="relu")
        sec_feed_layer = Dense(X, abundant_layer, num_classes, activation="relu")

        self.model3 = MLP() 

        self.model3.add(layer1)
        self.model3.add(layer2)

        self.focused_mlp.feed_add(first_feed_layer)   
        self.focused_mlp.feed_add(sec_feed_layer)                

        
    def automatic_parameterization(self, input_size, num_classes):
        parameters = input_size * num_classes / 2
        parameters = int(parameters)
        return parameters


    def automatic_dense_layer(self, X, input_dim, num_classes):
        vocab_size = self.vocab_size 

        automatic_change = self.automatic_parameterization(input_dim, num_classes)

        layer1= Dense(X, input_dim, automatic_change, activation="relu")
        layer2 = Dense(X, automatic_change, num_classes, activation="relu")

        return layer1, layer2


    def text_encoder(self, texts):
        vocab = self.vocab
        idx = 0
        for item in texts:
            texts = item[0] if isinstance(item, tuple) else item
            for word in texts.split():
                if word not in vocab:
                    vocab[word] = idx
                    idx += 1


    def encode(self, sentence, vocab, max_len=6):        
        tokens = sentence.split()
        ids = [vocab.get(w, 0) for w in tokens]
        while len(ids) < max_len:
            ids.append(0)
        
        return ids[:max_len]



    def input_encoding(self, datasets):
        texts = [d[0] for d in datasets]
        intents = [d[1] for d in datasets]
        intent_to_id = {intent:i for i, intent in enumerate(sorted(set(intents)))}
        num_classes = len(intent_to_id)
        labels = [intent_to_id[i] for i in intents]

        reverse_map = {}
        for i in range(len(intents)):
            reverse_map[i] = intents[i]

        self.texts = texts
        self.intents = intents
        self.reverse_map = reverse_map

        self.model2 = Transformer(
            vocab_size=len(self.vocab),
            d_model=32,
            n_heads=4,
            num_classes=num_classes
        )   

        y_true = np.zeros((len(labels), num_classes))
        for i,l in enumerate(labels):
            y_true[i,l] = 1
            
        input_ids_list = []

        input_ids_list = []
        for text in texts:
            input_ids_list.append(np.array(self.encode(text, self.vocab)))  

        return input_ids_list, y_true


    def cosine_robust_similarity(self, a, b):
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b[0])
    
        try:
            dot_product = np.dot(a, b)
        except:
            try: #detect inhomogenous shape
                dot_product = np.dot(a.flatten(), b[:a.flatten().shape[0]])
            except:
                try:
                    dot_product = np.dot(a[:b.shape[0]], b.flatten()[:a.shape[0]])
                except:
                    print('[-] No similarity due to inhomogenous shapes and failed attempts to find subsets, returning low similarity score.')
                    return 0.1
    
        dot_product = np.dot(a, b)
        cosine = dot_product / (norm_a * norm_b)
    
        return np.clip(cosine, -1.0, 1.0)

    # ===== async setup ======
    def _setup_async_queue(self):
        # Setup async queue handlers
        if not self.distribution or not self.distribution.use_async:
            return
            
        # Register custom handlers
        self.distribution.message_queue.register_handler(
            'custom_prediction', 
            self._handle_custom_prediction_async
        )
        self.distribution.message_queue.register_handler(
            'model_update',
            self._handle_model_update_async
        )
        
        # Start queue processor if not already running
        self.distribution.start_queue_processor()
        
        # Start health checker for async mode
        if self.distribution.use_async:
            self.distribution._start_health_checker()
            
        print("✅ Async message queue initialized")
    
    async def _handle_custom_prediction_async(self, message):
        # Handle custom prediction requests asynchronously.
        try:
            text = message.payload.get('text', '')
            result = self.predict_single(text)
            return {
                'prediction': result['prediction'],
                'confidence': result['confidence'],
                'success': True
            }
        except Exception as e:
            return {
                'prediction': None,
                'confidence': 0.0,
                'success': False,
                'error': str(e)
            }
    
    async def _handle_model_update_async(self, message):
        # Handle model update requests asynchronously.
        try:
            weights = message.payload.get('weights')
            if weights:
                self.update_weights(weights)
                return {'success': True, 'message': 'Model updated'}
            return {'success': False, 'message': 'No weights provided'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    # ============ Async Prediction Methods ============
    
    def predict_async(self, text: Any, callback=None, timeout=30):
        # Async prediction with callback support.
        if not self.distribution or not self.distribution.use_async:
            # Fallback to sync prediction
            result = self.predict_single(text)
            if callback:
                callback(result)
            return result
        
        return self.distribution.request_prediction_async(
            agent_id='local',
            text=text,
            callback=callback
        )
    
    async def predict_async_await(self, text, timeout=30):
        # Async prediction with await support.
        if not self.distribution or not self.distribution.use_async:
            # Fallback to sync prediction (run in thread)
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(
                None, self.predict_single, text
            )   
            
        try:
            result = await asyncio.wait_for(
                self.distribution.request_prediction_async('local', text, timeout=timeout),
                timeout=timeout + 5
            )
            return result
        except asyncio.TimeoutError:
            raise TimeoutError(f"[-] Prediction timed out after {timeout + 5}s")
        except Exception as e:
            logger.error(f"[-] Async prediction failed: {e}")
            traceback.print_exc()
            raise

    
    async def predict_batch_async(self, texts: List[str], callback=None):
        # Batch async predictions.
        if not self.distribution or not self.distribution.use_async:
            # Fallback to sync batch prediction
            results = self.prediction_batch(texts)
            if callback:
                callback(results)
            return results

        return await self.distribution.request_batch_prediction_async(
            agent_id='local',
            texts=texts,
            callback=callback
        )


    # ============ Distributed Agent Methods ============
    
    def connect_peers(self, peer_addresses: List[tuple]):
        # Connect to multiple peer agents.
        if not self.distribution:
            self.init_distributed()
        
        results = []
        for host, port in peer_addresses:
            try:
                sock = self.distribution.connect_to_agent(host, port)
                results.append({'host': host, 'port': port, 'success': sock is not None})
            except Exception as e:
                results.append({'host': host, 'port': port, 'success': False, 'error': str(e)})
        
        return results
    
    async def broadcast_to_peers(self, message_type: str, payload: dict):
        # Broadcast message to all connected peers.
        if not self.distribution:
            raise RuntimeError("Distributed inference not initialized")
        
        return await asyncio.to_thread(
            self.distribution.broadcast,
            message_type, payload, timeout=10
        )
    
    def get_network_status(self):
        # Get current network status.
        if not self.distribution:
            return {'status': 'not_initialized'}
        
        return {
            'status': 'active',
            'connected_agents': len(self.distribution.remote_agents),
            'queue_stats': self.distribution.get_queue_stats(),
            'mode': 'async' if self.distribution.use_async else 'sync'
        }
    
    # ============ Lifecycle Management ============

    async def shutdown_async(self):
        # Graceful shutdown of async components.
        print("🛑 Shutting down async components...")
        
        # Cancel all pending async tasks
        for task in self._async_tasks:
            if not task.done():
                task.cancel()
        
        # Wait for tasks to complete
        if self._async_tasks:
            await asyncio.gather(*self._async_tasks, return_exceptions=True)
        
        # Shutdown distributed inference
        if self.distribution:
            self.distribution.stop()
        
        print("✅ Async shutdown complete")
    
    async def shutdown(self):
        if self.distribution:
            self.distribution.stop()      # sync call
            self.distribution.stop_server()
            
            
            if hasattr(self, '_shutdown_event'):
                self._shutdown_event.set()

            # cancel async tasks
            if self._async_tasks:
                for task in self._async_tasks:
                    if not task.done():
                        task.cancel()
                await asyncio.gather(*self._async_tasks, return_exceptions=True)




    def cosine_similarity(self, a, b):
        eps = 1e-5
        b = b[0]

        if isinstance(a, (str, np.str_)):
            clean_str = str(a).replace('[', '').replace(']', '')
            a = np.fromstring(clean_str, sep=' ')
        elif isinstance(a, np.ndarray) and np.issubdtype(a.dtype, np.character):
            # catches arrays filled with string text
            clean_str = ' '.join(a.astype(str).flatten()).replace('[', '').replace(']', '')
            a = np.fromiter(
                    (x for x in clean_str.split() if x != "..."), dtype=float
                )               
        else:
            # Ensure standard float array if it was integers or objects
            a = np.asarray(a, dtype=float)

        # Handle variable b
        if isinstance(b, (str, np.str_)):
            clean_str = str(b).replace('[', '').replace(']', '')
            b = np.fromstring(clean_str, sep=' ')
        elif isinstance(b, np.ndarray) and np.issubdtype(b.dtype, np.character):
            clean_str = ' '.join(b.astype(str).flatten()).replace('[', '').replace(']', '')
            b = np.fromstring(clean_str, sep=' ')
        else:
            b = np.asarray(b, dtype=float)

        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
    
        if len(a.shape) > 1 and len(b.shape) > 1 and a.shape[1] != b.shape[0]:
            a = np.asarray(a)
            b = np.asarray(b)
            subset_a = a[0, :b.shape[0]]
            subset_b = a[:subset_a.shape[0], 0]

            try:
                try:
                    dot_product = np.dot(subset_a, subset_b)
                except:
                    dot_product = np.dot(subset_a[0, :min(subset_a.shape[1], subset_b.shape[0])], subset_b[:min(subset_a.shape[1], subset_b.shape[0])])
            except:
                try:
                    dot_product = np.dot(a.flatten(), b[:a.flatten().shape[0]])
                except:
                    try:
                        dot_product = np.dot(a[:b.shape[0]], b.flatten()[:a.shape[0]])
                    except:
                        print('[-] No similarity due to inhomogenous shapes and failed attempts to find subsets, returning low similarity score.')
                        return 0.1
       

        else:
            subset_a = a[:a.shape[0]]
            subset_b = b[:subset_a.shape[0]]

            try:
                dot_product = np.dot(subset_a, subset_b) 
            except:
                try:
                    subset_b_2 = subset_b[:subset_a.shape[1], :subset_a.shape[0]]  
                    dot_product = np.dot(subset_a, subset_b_2)

                except:
                    print('[-] No similarity due to inhomogenous shapes and failed attempts to find subsets, returning low similarity score.')
  
                    return 0.0         

        cosine = dot_product / (norm_a * norm_b)
        cosine = np.clip(cosine, -1.0, 1.0)

        return cosine  

    def anisotropy_measurement(self, x):
        eps = 1e-5
        if isinstance(x, list):
            print(f'[=] Converting list to array with shape: {len(x)}')
            x = np.array(x)
            x = x.reshape(x.shape[0], -1)  # Flatten if necessary
        
        try:
            try:
                grads = np.gradient(x)
                # Stack gradients into a single array of vectors and find the norm of each
                # automatically handles multi-dimensional arrays (e.g., 2D, 3D volumes)
                stacked_grads = np.stack(grads, axis=-1)
                norms = np.linalg.norm(stacked_grads, axis=-1)
                
                # Safely filter out potential NaNs or infs (common at array boundaries)
                valid_norms = norms[np.isfinite(norms)]
                
                if len(valid_norms) == 0:
                    return 0.0 # Return zero or appropriate default if no valid values exist
                    
                # Calculate statistics using the clean data
                std_val = np.std(valid_norms)
                mean_val = np.mean(valid_norms)
                
                anisotropy = std_val / (mean_val + eps)    
                if np.isnan(anisotropy) or np.isinf(anisotropy):
                    anisotropy = self.pipeline.confidence_threshold
            except:
                try:
                    gradient = np.gradient(x)
                except:
                    subnet = x[:min(10, x.shape[0]), :min(10, x.shape[1])]
                    gradient = np.gradient(subnet.flatten())

                val = [np.linalg.norm(v) for v in gradient]
                anisotropy = np.std(val) / np.mean(val) + eps 
        except Exception as e:
            print(f'[!] Cant calculate anisotropy due to: {e}')   
            anisotropy = self.confidence_threshold

        if np.isnan(anisotropy) or np.isinf(anisotropy):
            anisotropy = self.confidence_threshold

        return anisotropy


    def modular_prediction_saving(self, X, X2, output):
        memory_name = self.memory_name
        if self.memory is None:
            self.memory = {}

        elif not isinstance(self.memory, dict):
            print(f'[!] Warning: memory was {type(self.memory)}, converting to dict')
            # Try to convert or reset
            if isinstance(self.memory, np.ndarray):
                # If memory was an array, changing type - log it
                print(f'[!] Converting memory from array to dict, old shape: {self.memory.shape}')
            self.memory = {}

        self.memory['TW'] = X, output # transformers Weight
        self.memory['MW'] = X2, output # MLP Weight
        try:
            print('🚀 Memory Prediction Added!')
            self.storage.save_model_dict(memory_name, self.memory, type='Pipeline', model_type='prediction')
        except Exception as e:
            print(f'[!] Cant save model memory: {e}')


    def modular_probability_saving(self, X, X2, prob):
        memory_name = self.memory_name

        if self.memory is None:
            self.memory = {}

        elif not isinstance(self.memory, dict):
            print(f'[!] Warning: memory was {type(self.memory)}, converting to dict')
            # Try to convert or reset
            if isinstance(self.memory, np.ndarray):
                # If memory was an array, changing type - log it
                print(f'[!] Converting memory from array to dict, old shape: {self.memory.shape}')
            self.memory = {}
    
        self.memory['TP'] = (X, prob)
        self.memory['MP'] = (X2, prob)
        
        # Save to database
        try:
            self.storage.save_model_dict(memory_name, self.memory, type='Pipeline', model_type='probs')
            print('🚀 Memory Probability Added!')
        except Exception as e:
            print(f'[!] Failed to save memory: {e}')
       
    def _cross_session_availability(self):
        try:
            print('=== CROSS SESSION MEMORY AVAILABILITY AND TRANSFER ===')
            print('1. Export memory session')
            print('2. Import memory session')
            print('3. Sync with another device')
            print('4. List sessions')

            chosen = input('[=] Choose Options [1/2/3/4]: ')
            if chosen != '3':
                filename = input('[=] Insert filename name to export or import or list session (ex. name: memory_session): ')

            if chosen == '1':
                if filename:
                    print(f'[+] Exporting memory session with name {filename}...')
                    self.session_automation.export_session(filename)
                    print(f'🚀 {filename} successfully exported as json!')
                else:
                    print('[-] Invalid filename!')
                    pass

            elif chosen == '2':
                if isinstance(filename, str):
                    json_converted = filename + '.json'
                    print(f'[=] Importing memory session, filename: {json_converted}...')
                    self.session_automation.import_session(json_converted)
                    print(f'[+] Successfully imported {json_converted}! ')
                else:
                    print('[-] Invalid filename!')
                    pass

            elif chosen == '3':
                ip_number = input('[=] Insert ip number of your device for syncing: ')  
                if ip_number:
                    print('[=] Syncing with device to export memory session...')  
                    self.session_automation.sync_with_another_device(ip_number, port=5000) 
                else:
                    print('[-] Invalid filename!')
                    pass

            elif chosen == '4':
                print('[=] Listing sessions...')                
                print('[!] Note: you must put the common name of memory sessions you have, (ex: memory_sessions)')
                print('if your most memory sessions you have contains memory_ name in front, insert it in the input.')
                self.session_automation.list_sessions(filename)
            else:
                print('[-] Invalid options! ')
                pass

        except Exception as e:
            print(f'[-] Warning! Error detected during session availability: {e}')
            pass


    def model_memory_gate(self, x, x2):
        memory = self.memory
        is_corrupted, reason, _ = self.is_memory_corrupted(memory)
               

        if isinstance(memory, np.ndarray):
            if self._get_num_classes() and memory.shape[-1] == self._get_num_classes():
                if is_corrupted:
                    print('[!] Memory corruption detected, Trying possible conversion to extract memory...')
                    print(f'[REASON]: {reason}')
                else:
                    print('[+] Memory is a direct array, converting...')
                               
                num_classes = self._get_num_classes()                 
                if memory.ndim == 1:                   
                    print(f'[+] Memory is flat array shape {memory.shape}, converting to 2D...')
                    converted_memory = memory.reshape(1, -1)
                    
                    if converted_memory.shape[-1] == num_classes:
                        print(f'[+] Memory converted to shape {converted_memory.shape}, returning it.')
                        return converted_memory
                    else:
                        print(f'[!] Shape mismatch! Got {converted_memory.shape[-1]} classes, expected {num_classes}')
                        return None
                
                # Case 2: Already 2D array (1, 8) or (N, 8)
                elif memory.ndim == 2:
                    if memory.shape[-1] == num_classes:
                        print(f'[+] Memory already in correct shape {memory.shape}, returning it.')
                        return memory
                    else:
                        print(f'[!] Memory shape mismatch! shape: {memory.shape}, expected classes: {num_classes}')
                        return None
                
                # Case 3: Higher dimensional array
                else:
                    print(f'[!] Memory has unexpected dimensions: {memory.ndim}D, shape: {memory.shape}, No matching memory!')
                    return None

            elif not self._get_num_classes():
                print('[!] Cant get number of classes from transformer and MLP model!')
                return None
            else:
                print(f'[!] Memory shape mismatch! shape: {memory.shape}, No matching memory! ')
                return None

        if isinstance(memory, list):
            print('[==] Memory is a list, checking contents...')
            if len(memory) > 0 and isinstance(memory[0], np.ndarray):
                print('[+] Got probability features inside list!')
                return memory[0].copy()
            else:
                if self._gate_from_list(memory, x, x2):
                    return self._gate_from_list(memory, x, x2)
                else:
                    print('[!] No matching item from memory!')
                    return None

        if isinstance(memory, dict):
            for key, value in list(memory.items()):
                is_val_corrupted, reason, _ = self.is_memory_corrupted(value)
                if is_val_corrupted:
                    print(f'[!] Removing corrupted entry {key}: {reason}')
                    del memory[key] 

            cache_trans_memory = [key for key, (inp) in memory.items() if key.startswith('TW') and (isinstance(inp, np.ndarray) or isinstance(inp, list)) and self.cosine_robust_similarity(x, inp) >= 0.9]
            cache_mlp_memory =  [key for key, (inp2) in memory.items() if key.startswith('MW') and (isinstance(inp2, np.ndarray) or isinstance(inp2, list)) and self.cosine_similarity(x2, inp2) >= 0.9]

            if cache_mlp_memory and cache_trans_memory:
                for memo in cache_trans_memory:
                    _, out = memory[memo]
                    
                for memo2  in cache_mlp_memory:
                    _, out = memory[memo2]

                if isinstance(out, str):
                    out = np.array([float(x) for x in out.strip('[]').split(',')])  # Convert string to numpy array

                output = out.copy()
                return output      
            else:
                if cache_mlp_memory:
                    print('[+] Found matching memory from mlp past memory!')                
                    for memo in cache_mlp_memory:
                        _, out = memory[memo] 
                        if isinstance(out, str):
                            out = np.array([float(x) for x in out.strip('[]').split(',')])  # Convert string to numpy array

                    output = out.copy() 
                    return output 

                elif cache_trans_memory:
                    print('[+] Found matching memory from transformer past memory!')                
                    for memo in cache_trans_memory:
                        _, out = memory[memo] 
                        if isinstance(out, str):
                            out = np.array([float(x) for x in out.strip('[]').split(',')])  # Convert string to numpy array

                    output = out.copy() 
                    return output

                else:
                    print('🔄 No Matching Memory!')
                    return None

            
        else:
            print('[!] No matching memory types!')
            return None

    def _gate_from_list(self, memory: list, x, x2) -> Optional[np.ndarray]:
        # xtract from list memory (fallback for corrupted storage)

        print('[=] Extracting from list memory.. handling possible corruption of data...')
        for item in memory:
            if isinstance(item, (tuple, list)) and len(item) >= 2:
                stored_x = item[0]
                stored_out = item[1]
                
                # Check similarity
                print('[=] checking similarity from stored X data and stored output...')
                if self.cosine_robust_similarity(x, stored_x) >= 0.9:
                    return self._to_numpy_array(stored_out)

        print('[=] Cant get item from memory, possible dangerous data Corruption!')
        return None


    def _to_numpy_array(self, value) -> Optional[np.ndarray]:
        """
        Convert various return types to numpy array.
        Handles: array, list, tuple, string, scalar.
        """
        if value is None:
            print('[!] Value is None!')
            return None
        
        # check here numpy array
        if isinstance(value, np.ndarray):
            return value.copy() if value.size > 0 else None
        
        # List or tuple of numbers
        if isinstance(value, (list, tuple)):
            try:
                arr = np.array(value, dtype=np.float32)
                if arr.ndim == 0:
                    arr = arr.reshape(1)
                return arr
            except:
                return None
        
        # String (from database JSON)
        if isinstance(value, str):
            try:
                # JSON first
                if value.startswith('['):
                    parsed = json.loads(value)
                    return np.array(parsed, dtype=np.float32)
                # space-separated
                parts = value.strip('[]').split()
                if parts:
                    return np.array([float(p) for p in parts], dtype=np.float32)
            except:
                pass
            return None
        
        # Scalar number
        if isinstance(value, (int, float)):
            return np.array([value], dtype=np.float32)
        
        print(f'[!] Cannot convert to array: {type(value)}')
        return None


    def _get_num_classes(self) -> int:
        # Get number of classes from model first
        if hasattr(self, 'model2') and self.model2:
            return self.model2.output.shape[1]
        elif hasattr(self, 'mlp') and self.mlp.layers:
            return self.mlp.layers[-1].b.shape[1]
        return None  


    def model_probability_gate(self, x, x2):
        memory = self.memory
        is_corrupted, reason, _ = self.is_memory_corrupted(memory)

        if isinstance(memory, np.ndarray):
            if self._get_num_classes() and not memory.shape[-1] == self._get_num_classes():
                if is_corrupted:
                    print('[!] Memory corruption detected, Trying possible conversion to extract memory...')
                    print(f'[REASON]: {reason}')
                else:
                    print('[+] Memory is a direct probability, converting...')

                num_classes = self._get_num_classes()       

                if memory.ndim == 1:                  
                    print(f'[+] Memory is flat array shape {memory.shape}, converting to 2D...')
                    converted_memory = memory.reshape(1, -1)
                    
                    if converted_memory.shape[-1] == num_classes:
                        print(f'[+] Memory converted to shape {converted_memory.shape}, returning it.')
                        return converted_memory
                    else:
                        print(f'[!] Shape mismatch! Got {converted_memory.shape[-1]} classes, expected {num_classes}')
                        return None
                
                # Case 2: Already 2D array (1, 8) or (N, 8)
                elif memory.ndim == 2:
                    if memory.shape[-1] == num_classes:
                        print(f'[+] Memory already in correct shape {memory.shape}, returning it.')
                        return memory
                    else:
                        print(f'[!] Memory shape mismatch! shape: {memory.shape}, expected classes: {num_classes}')
                        return None
                
                # Case 3: Higher dimensional array
                else:
                    print(f'[!] Memory has unexpected dimensions: {memory.ndim}D, shape: {memory.shape}, No matching memory!')
                    return None

            elif not self._get_num_classes():
                print('[!] Cant get number of classes from transformer and MLP model!')
                return None
            else:
                print(f'[!] Memory shape mismatch! shape: {memory.shape}, No matching memory! ')
                return None

        if isinstance(memory, list):
            print('[==] Memory is a list, checking contents...')
            if len(memory) > 0 and isinstance(memory[0], np.ndarray):
                print('[+] Got probability features inside list!')
                return memory[0].copy()
            else:
                self._gate_from_list(memory, x, x2)

        if isinstance(memory, dict):
            for key, value in list(memory.items()):
                is_val_corrupted, reason, _ = self.is_memory_corrupted(value)
                if is_val_corrupted:
                    print(f'[!] Removing corrupted entry {key}: {reason}')
                    del memory[key] 

            cache_trans_memory = [key for key, (inp) in memory.items() if key.startswith('TP') and (isinstance(inp, np.ndarray) or isinstance(inp, list)) and self.cosine_robust_similarity(x, inp) >= 0.95]
            cache_mlp_memory =  [key for key, (inp2) in memory.items() if key.startswith('MP') and (isinstance(inp2, np.ndarray) or isinstance(inp2, list)) and self.cosine_similarity(x2, inp2) >= 0.95]

            if cache_mlp_memory and cache_trans_memory:
                for memo in cache_trans_memory:
                    _, out = memory[memo]

                for memo2  in cache_mlp_memory:
                    _, out = memory[memo2]

                if isinstance(out, str):
                    out = np.array([float(x) for x in out.strip('[]').split(',')])  # Convert string to numpy array

                output = out.copy()
                return output      
            else:
                print('🔄 No Matching Probability!')
                return None
        else:
            print('[!] No matching memory types!')
            return None

    def prediction_batch(self, texts):

        self.initialize_fitting(texts)
        if not texts:
            return []
        
        # Prepare batch inputs

        input_ids_list = []
        X_raw_list = []

        for text in texts:
            # Prepare transformer input
            input_ids = np.array([self.encode(text, self.vocab)])
            input_ids_list.append(input_ids)
            
            # Prepare MLP input
            if not hasattr(self, 'tfidf') or self.tfidf is None:
                self.initialize_fitting([text])
            X_raw = self.tfidf.transform([text]).toarray()
            X_raw_list.append(X_raw)
        
        # Stack into batches
        batch_input_ids = np.vstack(input_ids_list)  # (batch_size, seq_len)
        batch_X_raw = np.vstack(X_raw_list) # (batch_size, features)

        if self.labels is None and self.titles is None:
            _, y_true = self.input_encoding(list(zip(texts, texts)))  # No-value labels for y_true
        else:
            dataset, _ = self.data_preparation(self.titles, self.labels)
            y_true = self.input_encoding(dataset)
        
        # Run batch prediction through your existing logic
        return self._batch_prediction_core(batch_input_ids, batch_X_raw, y_true)



    def _batch_model_memory_gate(self, batch_input_ids, batch_X_raw):
        batch_probs = [None] * len(batch_input_ids)
        
        for i in range(len(batch_input_ids)):
            probs = self.model_memory_gate(
                batch_input_ids[i:i+1], 
                batch_X_raw[i:i+1]
            )
            if probs is not None:
                arr = np.array(probs)
                if arr.ndim > 1:
                    arr = arr[0]
                elif arr.ndim == 0:
                    arr = arr.reshape(1)
                batch_probs[i] = arr.copy()
        
        return batch_probs


    def _refit_sparse_data(self, X_features, texts, threshold=0.3):
        """Refit TF-IDF if zero-row ratio exceeds threshold."""
        X_features = np.asarray(X_features, dtype=np.float32)
        if X_features.ndim == 1:
            X_features = X_features.reshape(1, -1)        
            X_features = np.asarray(X_features)
                    
        zero_rows = np.where(X_features.sum(axis=1) == 0)[0]
        zero_ratio = len(zero_rows) / len(X_features)
        
        if zero_ratio > threshold:
            print(f'[!] {len(zero_rows)} zero rows ({zero_ratio:.0%}), refitting TF-IDF on current batch')
            self.tfidf.fit(texts)
            X_features = self.tfidf.transform(texts).toarray()
            
            # second pass — fill remaining zeros with checksum fingerprint
            zero_rows = np.where(X_features.sum(axis=1) == 0)[0]
            for i in zero_rows:
                text = texts[i] if isinstance(texts[i], str) else str(texts[i])
                checksum = int(hashlib.md5(text.encode()).hexdigest(), 16)
                rng = np.random.default_rng(checksum)
                X_features[i] = rng.uniform(0.01, 0.1, size=X_features.shape[1])
                print(f'[!] Row {i} still zero after refit, checksum fallback applied')
        
        return X_features 


    def _batch_prediction_core(self, batch_input_ids: np.ndarray, batch_X: np.ndarray, 
                                batch_size: Any = None, show_progress: bool = True) -> np.ndarray:
        """
        Robust batch prediction with dynamic shape handling.
        """
        if len(batch_input_ids) == 0:
            return np.array([])
        
        # Auto-calculate optimal batch size if not provided
        if batch_size is None:
            batch_size = self._calculate_optimal_batch_size(batch_input_ids, batch_X)
        
        if isinstance(batch_size, (list, np.ndarray)):
            try:
                try:
                    batch_size = int(batch_size[0]) if len(batch_size) > 0 else 32
                except:
                    batch_size = int(batch_size[0][0])
            except:
                batch_size = int(batch_size)
        else:
            if isinstance(batch_size, (tuple, list, np.ndarray)):
                batch_size = batch_size[0]
                batch_size = len(batch_size)
            else:
                batch_size = int(batch_size)
            
        n_samples = len(batch_input_ids)
        chunks = []
        if isinstance(batch_size, (tuple, list)):
            batch_size = batch_size[0] 

        print(f'[=] Total samples: {n_samples}, using batch size: {batch_size}, total batches: {((n_samples - 1) // batch_size) + 1}')
        
        for i in range(0, n_samples, batch_size):
            chunk = (
                batch_input_ids[i:i + batch_size],
                batch_X[i:i + batch_size]
            )
            chunks.append(chunk)
        
        # ✅ Determine number of classes dynamically from first successful chunk
        num_classes = None
        batch_probs = None
        
        for chunk_idx, (chunk_ids, chunk_X) in enumerate(chunks):
            if show_progress:
                start_idx = chunk_idx * batch_size
                end_idx = min(start_idx + batch_size, n_samples)
                print(f"\r📊 Processing batch {chunk_idx + 1}/{len(chunks)} (samples {start_idx}-{end_idx})...", end="")
            
            try:
                # Process chunk with memory gate
                chunk_probs = self._process_batch_chunk(chunk_ids, chunk_X)
                
                # ✅ Handle numpy array conversion
                if isinstance(chunk_probs, list):
                    chunk_probs = np.array(chunk_probs)
                
                # ✅ Determine number of classes from first successful chunk
                if num_classes is None:
                    if chunk_probs.ndim == 1:
                        num_classes = 1
                    else:
                        num_classes = chunk_probs.shape[1] if chunk_probs.ndim > 1 else len(chunk_probs)
                    
                    # Initialize results array
                    batch_probs = np.zeros((n_samples, num_classes))
                    print(f'\n[=] Detected {num_classes} classes from chunk {chunk_idx + 1}')
                
                # ✅ Handle dimension mismatches
                if chunk_probs.ndim == 1:
                    chunk_probs = chunk_probs.reshape(-1, 1)
                
                # ✅ If chunk has different number of classes, pad or trim
                if chunk_probs.shape[1] != num_classes:
                    print(f'[=] Shape mismatch: chunk has {chunk_probs.shape[1]} classes, expected {num_classes}')
                    
                    if chunk_probs.shape[1] > num_classes:
                        # Trim extra classes
                        chunk_probs = chunk_probs[:, :num_classes]
                        print(f'[=] Trimmed to {chunk_probs.shape[1]} classes')
                    else:
                        # Pad missing classes
                        padded = np.zeros((chunk_probs.shape[0], num_classes))
                        padded[:, :chunk_probs.shape[1]] = chunk_probs
                        chunk_probs = padded
                        print(f'[=] Padded to {chunk_probs.shape[1]} classes')
                
                # Place in results
                start_idx = chunk_idx * batch_size
                end_idx = start_idx + len(chunk_probs)
                batch_probs[start_idx:end_idx] = chunk_probs
                
            except Exception as e:
                print(f"\n⚠️ Chunk {chunk_idx + 1} failed: {e}")
                traceback.print_exc()
                
                # Fill failed chunk with zeros
                start_idx = chunk_idx * batch_size
                end_idx = start_idx + len(chunk_ids)
                
                if batch_probs is None:
                    # If first chunk failed, initialize with default
                    num_classes = self._get_num_classes()
                    batch_probs = np.zeros((n_samples, num_classes))
                
                batch_probs[start_idx:end_idx] = 0
        
        if show_progress:
            print(f"\r✅ Batch complete: {n_samples} samples processed                    ")
        
        return batch_probs if batch_probs is not None else np.array([])

    def _process_batch_chunk(self, chunk_ids: np.ndarray, chunk_X: np.ndarray) -> np.ndarray:
        """
        Process a single chunk - core batch logic with memory gate.
        """
       
        chunk_probs = self._batch_model_memory_gate(chunk_ids, chunk_X)
        
        needs_fresh = [i for i, p in enumerate(chunk_probs) if p is None]
        
        if needs_fresh:
            # Extract samples that need fresh prediction
            fresh_ids = chunk_ids[needs_fresh]
            fresh_X = chunk_X[needs_fresh]
            
            # Get fresh predictions from ensemble
            fresh_probs, _ = self.ensemble.predict_ensemble(
                fresh_ids, fresh_X, 
                np.zeros((len(fresh_ids), self._get_num_classes())),
                method='dynamic', embedded=False
            )
            
            # Store fresh predictions
            for i, fresh_idx in enumerate(needs_fresh):
                chunk_probs[fresh_idx] = fresh_probs[i]
                
                # Cache to memory (first 2 only to avoid spam)
                if fresh_idx < 2:
                    self.modular_prediction_saving(
                        fresh_ids[i:i+1],
                        fresh_X[i:i+1],
                        fresh_probs[i:i+1]
                    )
        
        # Convert list to array
        return np.array([p if p is not None else np.zeros(self._get_num_classes()) 
                        for p in chunk_probs])



    def _calculate_optimal_batch_size(self, batch_input_ids: np.ndarray, batch_X: Any=None) -> int:
        """
        Calculate optimal batch size based on available memory.
        """
        try:
            import psutil
            # Estimate memory per sample
            sample_size = batch_input_ids[0].nbytes + batch_X[0].nbytes if hasattr(batch_X, '__len__') else 1024
            available_memory = psutil.virtual_memory().available
            max_samples = int(available_memory * 0.1 / sample_size)  # Use 10% of memory
            return min(64, max(8, max_samples))
        except:
            # Fallback to conservative batch size
            return 32

    def _get_num_classes(self) -> int:
        if hasattr(self, 'model2') and self.model2 is not None:
            if hasattr(self.model2, 'output'):
                return self.model2.output.shape[1]
        
        if hasattr(self, 'mlp') and self.mlp is not None:
            if hasattr(self.mlp, 'layers') and len(self.mlp.layers) > 0:
                last_layer = self.mlp.layers[-1]
                if hasattr(last_layer, 'b'):
                    return last_layer.b.shape[1]
        
        if hasattr(self, 'reverse_map') and self.reverse_map:
            return len(self.reverse_map)
        
        if hasattr(self, 'label_map') and self.label_map:
            return len(self.label_map)
        
        # infer from any cached probability
        if isinstance(self.memory, dict):
            for value in self.memory.values():
                if isinstance(value, np.ndarray) and value.ndim == 1:
                    return value.shape[0]
                if isinstance(value, list) and len(value) > 0:
                    if all(isinstance(x, (int, float)) for x in value[:5]):
                        return len(value)
        
        print('[!] Could not determine num_classes, defaulting to 0')
        return 0
    
  
    def predict_async(self, text, callback=None):
        try:
            return self.batcher.add_request(text, callback)
        except Exception as e:
            print(f'[=] error in automatic batcher: {e}')
            return None
    

    def predict_single(self, text):
        result = [None]
        
        def callback(r):
            result[0] = r
        
        self.predict_async(text, callback)
        
        # Wait for result
        while result[0] is None:
            time.sleep(0.001)
        
        return result[0]
 

    def _batch_hybrid_prediction(self, batch_input_ids, batch_X_raw, y_true):
        print('[+] Initiating hybrid prediction batching...')
        idx_total = 0
        batch_probs = self._batch_model_memory_gate(batch_input_ids, batch_X_raw)
        
        needs_prediction = [i for i, p in enumerate(batch_probs) if p is None]
        
        if needs_prediction:
            fresh_input_ids = batch_input_ids[needs_prediction]
            fresh_X_raw = batch_X_raw[needs_prediction]
            
            # Batch ensemble
            fresh_probs, details = self.ensemble.predict_ensemble(
                fresh_input_ids, fresh_X_raw, y_true, method='dynamic', embedded=False
            )
            
            for i, idx in enumerate(needs_prediction):
                batch_probs[idx] = fresh_probs[i]
                idx_total += 1
                if idx_total < 2:
                    self.modular_prediction_saving(
                        fresh_input_ids[i:i+1], 
                        fresh_X_raw[i:i+1], 
                        fresh_probs[i:i+1]
                    )

        valid_probs = []
        for p in batch_probs:
            if p is None:
                # Use zeros as fallback for None values
                valid_probs.append(np.zeros_like(fresh_probs[0]))
            elif isinstance(p, list):
                valid_probs.append(np.array(p))
            else:
                valid_probs.append(p)
        
        try:
            try:
                return np.array(valid_probs)
            except:
                return valid_probs
        except Exception as e:
            print(f'[-] Error converting batch probabilities to array: {e}')
            return valid_probs
    

    def _batch_predict_proba(self, batch_input_ids, batch_X, type='Hybrid'):
        batch_size = len(batch_input_ids)
        idx_total = 0
        
        # Batch memory gate
        batch_probs = [None] * batch_size
        for i in range(batch_size):
            probs = self.model_probability_gate(
                batch_input_ids[i:i+1], 
                batch_X[i:i+1]
            )
            if probs is not None:
                batch_probs[i] = probs[0]
        
        # Find which need fresh prediction
        needs_prediction = [i for i, p in enumerate(batch_probs) if p is None]
        
        if needs_prediction:
            fresh_input_ids = batch_input_ids[needs_prediction]
            fresh_X = batch_X[needs_prediction]
            
            # Batch transformer and MLP
            transformer_pred, fresh_probs, attn_weights = self.model2.predict(fresh_input_ids)
            mlp_pred = self.mlp.forward(fresh_X)
            
            mlp_pred_indices = np.argmax(mlp_pred, axis=1)
            trans_pred_indices = np.argmax(fresh_probs, axis=1)
            
            # Calibrate batch
            for i, idx in enumerate(needs_prediction):
                idx_total += 1
                if mlp_pred_indices[i] != trans_pred_indices[i]:
                    calibrated = self._calibrate_probs(
                        fresh_probs[i:i+1], 
                        [mlp_pred_indices[i]], 
                        attn_weights[i:i+1] if attn_weights is not None else None,
                        fresh_input_ids[i:i+1]
                    )
                    batch_probs[idx] = calibrated[0]
                else:
                    # Models agree
                    probs_i = fresh_probs[i].copy()
                    target = mlp_pred_indices[i]
                    probs_i[target] = min(probs_i[target] * 1.2, 0.95)
                    probs_i /= probs_i.sum()
                    batch_probs[idx] = probs_i
                
                # Save to memory
                if idx_total < 2:
                    self.modular_probability_saving(
                        fresh_input_ids[i:i+1], 
                        fresh_X[i:i+1], 
                        np.array([batch_probs[idx]])
                    )
      
        return np.array(batch_probs)



    def hybrid_prediction(self, rules, input_ids, dataset):
        X, y, _, _ = self.feature_generation(rules, dataset) 
        if len(input_ids.shape) == 2 and input_ids.shape[0] > 1:
            # this is batch mode version
            return self._batch_hybrid_prediction(input_ids, X, y)

        probs = self.model_memory_gate(input_ids, X)

        if probs is None or not self.agreement:
            if not self.autonomous:
                print('= Prediction Method needed: ')
                print('[1]. dynamic')
                print('[2]. meta')
                print('[3]. attention')

                print('[-] Autonomous prediction give the model full control of its dynamic prediction, without any user input.')
                choose_method = input('[=] Autonomous prediction initiated? [Y/N] (press N to insert manual prediction method): ')

                if choose_method == 'Y':
                    self.autonomous = True
                    probs, details = self.ensemble.predict_ensemble(input_ids, X, y, method='dynamic', embedded=True) 

                else:
                    method = input('|| Choose one method (ex: dynamic): ')
                    if method:
                        probs, details = self.ensemble.predict_ensemble(input_ids, X, y, method=method, embedded=True)
                    else:
                        print('|| Invalid Method.. returning to dynamic prediction..')
                        probs, details = self.ensemble.predict_ensemble(input_ids, X, y, method='dynamic', embedded=True)    
            else:
                print('[+] Autonomous dynamic prediction: ')
                probs, details = self.ensemble.predict_ensemble(input_ids, X, y, method='dynamic', embedded=True) 

            self.modular_prediction_saving(input_ids, X, probs)
            print('🚀 Memory Added!')

        return probs

    def _handle_distributed_connections(self, probs, self_attn_weights, input_ids, agreement):
        print('=== AGENT DISTRIBUTIED INFERENCE HANDLING ===')
        print('1. Handle local In-device Peer')
        print('2. Handle external-device Peer')

        program = None
        if not self.autonomous:
            program = input('[=] Pick your choice [1/2] (choose N to skip): ')

        if program == '1' or self.autonomous:
            print('=== IN-DEVICE PEER REQUEST INITIATED ===')
            probs = self.distribution._handle_peer_agent_request(probs, self_attn_weights, input_ids, type='DevicePeer', agreement=agreement)
            if self.distribution.query_node.peer_trust < self.confidence_threshold:
                print('[-] Peer trust is low, broadcasting ping to check for better peers...')
                alive_agents = self.distribution.broadcast_ping()

                if alive_agents:
                    print(f'[+] Alive agents: {alive_agents} identified, enabling external peer connections for better assistance...')
                    self.external_peer_enabled = bool(alive_agents)
                    self.autonomous = False

        elif program == '2' or self.external_peer_enabled:
            print('=== EXTERNAL PEER REQUEST INITIATED ===')
            ip_number = input('[=] Insert IP Number to connect with peer: ')

            if ip_number:
                try:
                    distributed_a = self.distribution
                    
                    distributed_a.start_server()
                    if distributed_a.connect_to_agent(ip_number, 5555):
                        print(f'[=+=] Successfully connected to external peer at {ip_number}!')
                        time.sleep(10)

                        print('=== EXTERNAL PEER REQUEST INITIATED ===')
                        print('[1]. Request prediction')
                        print('[2]. Handle Peer uncertainty')
                        sec_program = input('[=] Pick your choice [1/2]: ')    

                        if sec_program == '1':
                            for intent in self.intents:
                                result = distributed_a.request_prediction_method(self, intent)
                                print(f"[+] Remote prediction: {result}")
                    
                                # Ensemble vote across all agents
                                votes = []
                                list_probs = []

                            # Check network status
                            print('=== Checking network status with broadcast ping... ===')
                            alive_agents = distributed_a.broadcast_ping()  
                            if alive_agents:
                                print(f'[+] Alive agents: {alive_agents} identified, requesting ensemble votes...')                          
                                for agent_id in distributed_a.remote_agents:
                                    peer_probs, vote = distributed_a.request_ensemble_vote(agent_id, intent)
                                    if vote:
                                        votes.append(vote)
                                        list_probs.append(peer_probs)
                                        
                                        for vote in votes:
                                            print(f'[+] Prediction: {vote['prediction']}')
                                            print(f'[+] Confidence: {vote['confidence']}')
                                            print(f'[+] Trust: {vote['trust_score']}')
                                            if vote['confidence'] > self.confidence_threshold:
                                                for i in range(len(probs)):
                                                    probs = probs[i] * (1.0 + vote['trust_score'] * vote['confidence'])
                                                probs = probs.copy() / np.sum(probs) # Normalize after adjustment
                                else:
                                    print(f'[-] No alive agents found, Total: {alive_agents} Agent found. Using local prediction only.')
                                    probs = self.distribution._handle_peer_agent_request(probs, self_attn_weights, input_ids, type='ExternalPeer', agreement=agreement)

                            distributed_a.print_network_status()

                        elif sec_program == '2':
                            probs = self.distribution._handle_peer_agent_request(probs, self_attn_weights, input_ids, type='ExternalPeer', agreement=agreement)     
                    else:
                        print(f'[-] No Peer agents found, Using local prediction only.')
                        probs = self.distribution._handle_peer_agent_request(probs, self_attn_weights, input_ids, type='DevicePeer', agreement=agreement) 
                        time.sleep(10)

                except Exception as e:
                    print(f'[-] Error establishing connections: {e}, returning previous probs.')
                    self.distribution.report_failure(id(self), 'processing', reason=f'{e}')

            else:
                print(f'[-] Invalid Choice... returning previous probs.')
                self.distribution.report_failure(id(self), 'processing', reason="InvalidChoice")                        

        elif program == 'N':
            print('|| Skipping Peer connections, returning previous probs')
        else:
            print('[-] Invalid choice! returning previous probs')
            
        return probs



    def mlp_predict(self, X):
        if isinstance(X, str) or isinstance(X[0], str):
            self.initialize_fitting(X)            
            X_tfidf = self.tfidf.transform(X).toarray() 

        logits = self.mlp.prediction(X_tfidf)
        return logits

    
    def predict_proba(self, input_ids, X, type='Hybrid', embedded=False):
        eps = 1e-5
        probs_memory = self.model_probability_gate(input_ids, X)
        if isinstance(self.storage.id_history, list) or isinstance(self.storage.id_history, np.ndarray) and not self.agent_id in self.storage.id_history:
            self.storage.id_history.append(self.agent_id)
            id_history = self.storage.id_history
        else:
            self.temporary_id.append(self.agent_id)
            id_history = self.temporary_id

        if self.use_transformer:
            is_batch = len(input_ids.shape) == 2 and input_ids.shape[0] > 1
        else:
            is_batch = False

        AME = self.AME_Encoder(input_ids)
        AMR = 1.0 / (1.0 + np.exp(-AME))
        
        if is_batch:
            return self._batch_predict_proba(input_ids, X, type) 

        if type == 'Hybrid' and self.use_transformer:
            print('[=] Hybrid based classification method.')
            transformer_pred, probs, attn_weights = self.model2.predict(input_ids, embedded=embedded)
            mlp_pred = self.mlp.forward(X)

            if mlp_pred.ndim == 1:
                mlp_pred = mlp_pred.reshape(1, -1)
            # Ensure transformer_pred is 2D
            if transformer_pred.ndim == 1:
                transformer_pred = transformer_pred.reshape(1, -1)

            mlp_pred_indices = np.argmax(mlp_pred, axis=1)
            trans_pred_indices = np.argmax(transformer_pred, axis=1)
           
            if probs_memory is None:
                agreement = np.allclose(mlp_pred_indices, trans_pred_indices, rtol=eps)
          
            else:
                # memory agreement must match previously detected learned patterns, contextual transformer prediction isnot needed
                try:
                    probs_memory_ = np.argmax(probs_memory) 
                except:
                    probs_memory_= np.argmax(probs_memory, axis=1)

                agreement = np.allclose(mlp_pred_indices, probs_memory_, rtol=eps)

            need_peer_condition = not agreement and probs_memory is None
            self.agreement = agreement

            if not agreement:
                self.peer_assistance_threshold += 0.1                                     
                # if both pattern are still conflicting, use contextual relations for sorting regularization.
                if need_peer_condition:
                    print('|| Uncertain prediction, requesting peer assistance if allowed...')
                    probs = self._handle_distributed_connections(probs, attn_weights, input_ids, agreement)
                else:
                    need_calibration_condition = not agreement and self.final_conf_score > self.confidence_threshold
                    if need_calibration_condition:
                        print('[||] Uncertain prediction, but memory exist, skipping peer assistance and calibrating with attention because of high confidence...')                        
                        probs = self._calibrate_probs(probs, mlp_pred_indices, attn_weights, input_ids)       
                    else:
                        print('[-] Uncertain prediction, needing local peer assistance...')                        
                        probs = self._handle_distributed_connections(probs, attn_weights, input_ids, agreement)

            else:
                self.peer_assistance_threshold -= 0.2               
                print('[+] Both Models agree, Normalizing prediction with confidence boost...')
                for i, target in enumerate(mlp_pred_indices):
                    probs[i, target] = min(probs[i, target] * 1.2, 0.95)
                    probs[i] /= probs[i].sum()

                    
            if not agreement and probs_memory is not None:
                self.storage.save_peer_needs_dict(self.memory_name, probs_memory, mlp_pred, id_history)   
            else:
                self.storage.save_peer_needs_dict(self.memory_name, probs, mlp_pred, id_history)

            self.modular_probability_saving(input_ids, X, probs)
            print('🚀 Memory Added!')
            return probs
        else:
            print(f'[=] MLP Based classification method. Transformer usage permission: {self.use_transformer}')
            logits = self.mlp.forward(X)

            if probs_memory is not None:
                mlp_pred_indices = np.argmax(logits, axis=1)
                probs_memo = np.array(probs_memory)
                try:
                    probs_memory_ = np.argmax(probs_memory) 
                except:
                    probs_memory_ = np.argmax(probs_memory, axis=1)

                agreement = np.allclose(mlp_pred_indices, probs_memory_, rtol=eps)
                
                if not agreement:
                    # if both pattern are still conflicting, used latest prediction
                    probs = logits.copy()       
                else:
                    for i, target in enumerate(mlp_pred_indices):
                        probs_memo[i, target] = min(probs_memo[i, target] * AMR, 0.95)
                        probs_memo[i] /= probs_memo[i].sum()

            return logits

    def data_preparation(self, titles, labels):
        datasets = []
        raw = []
        for title in titles:
            tupled_title = (str(title))
            datasets.append(tupled_title)
            raw.append(str(title))

        for label in labels:
            tupled_label = (str(label))
            datasets.append(tupled_label)
            raw.append(str(label))

        self.initialize_fitting(raw)
        X_raw = self.tfidf.transform(raw).toarray()
        X_raw = self._refit_sparse_data(X_raw, raw)

        return datasets, X_raw

    
    def _calibrate_probs(self, probs, target_preds, attn_weights, input_ids):
        calibrated = probs.copy()
        if isinstance(input_ids, list):
            input_ids = np.array(input_ids)

        if len(probs.shape) > 1:
            n_classes = probs.shape[1]
        else:
            n_classes = probs.shape[0]

        batch_size = len(target_preds)
        eps = 1e-5

        for i in range(batch_size):
            mlp_target = target_preds[i]

            if attn_weights is None:
                anisotropy = self.anisotropy_measurement(mlp_target)     
            else:
                anisotropy = self.anisotropy_measurement(attn_weights[i])
            if attn_weights is not None and i < len(attn_weights):
                attn = attn_weights[i]
    
                score_quality = np.std(attn) if attn.size > 0 else self.confidence_threshold
                abstract_score = self.confidence_threshold + score_quality * anisotropy

            else:
                if attn_weights is not None:
                    score_quality = 1.0 / (1.0 + np.exp(-attn_weights[i]))
                else:
                    score_quality = 1.0 / (1.0 + np.exp(-mlp_target))

                abstract_score = (1.0 - score_quality) + eps

            self.temperature = (1.0 - abstract_score) + score_quality * anisotropy
            if isinstance(self.temperature, np.ndarray):
                self.temperature = np.clip(np.mean(self.temperature), 1e-5, 5.0)

            try:
                calibrated[i, mlp_target] = min(calibrated[i, mlp_target] * (1.5 * (1.0 - abstract_score)), 0.95)
            except:
                return calibrated

            calibrated[i] /= calibrated[i].sum()
        return calibrated
    
    def _softmax(self, x):
        temp = self.temperature

        try:
            if len(x.shape) > 1:
                x_dip = x / temp
                exp_x = np.exp(x_dip - np.max(x_dip, axis=1, keepdims=True))
                softmax = exp_x / np.sum(exp_x, axis=1, keepdims=True)     
            else:
                x_dip = x / temp
                exp_x = np.exp(x_dip - np.max(x_dip))
                softmax = exp_x / np.sum(exp_x)
        except:
            x_dip = x / temp
            exp_x = np.exp(x_dip - np.max(x_dip, axis=1, keepdims=True))


        softmax = exp_x / np.sum(exp_x, axis=1, keepdims=True)     
        return softmax


    def validate_writable_path(self, path):
        try:
            path = os.path.expanduser(path)
        
            directory = os.path.dirname(path) or '.'
        
            if not os.path.exists(directory):
                return False, f"Directory does not exist: {directory}"
        
            if not os.access(directory, os.W_OK):
                return False, f"No write permission for directory: {directory}"
        
            if os.path.exists(path):
                if not os.access(path, os.W_OK):
                    return False, f"File exists but is not writable: {path}"
        
            test_file = os.path.join(directory, f".test_write_{os.getpid()}")
            try:
                with open(test_file, 'w') as f:
                    f.write("test")
                os.remove(test_file)
            except Exception as e:
                return False, f"Write test failed: {e}"
        
            return True, "Path is writable"
        
        except Exception as e:
            return False, f"Validation error: {e}"

    def safe_pickle_save_with_feedback(self, data, suggested_path):
        print("\n" + "="*50)
        if suggested_path:
            print(f"|| Suggested path: {suggested_path}")
        
        user_path = input("|| Enter path to save pickle file (or 'cancel' to skip): ").strip()
        
        if user_path.lower() == 'cancel':
            print("|| Save cancelled.")
            pass
        
        user_path = user_path.strip('"').strip("'")
        user_path = os.path.expanduser(user_path)
        
        if os.path.isdir(user_path):
            from datetime import datetime
            default_filename = f"data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pkl"
            user_path = os.path.join(user_path, default_filename)
            print(f"|| Using filename: {default_filename}")
        
        valid, message = self.validate_writable_path(user_path)
        
        if valid:
            try:
                os.makedirs(os.path.dirname(user_path), exist_ok=True)
                
                with open(user_path, 'wb') as f:
                    joblib.dump(data, f)
                
                print(f"✓ Successfully saved to: {user_path}")
                pass
                
            except PermissionError as e:
                print(f"✗ Permission denied: {e}")
                print("|| Try a different location (like your Desktop or Documents folder)")
                pass
            except Exception as e:
                print(f"✗ Save failed: {e}")
                pass

        else:
            print(f"✗ Invalid path: {message}")
            print("Tips:")
            print("  - Use a path in your home directory: ~/Documents/myfile.pkl")
            print("  - Make sure the directory exists and is writable")
            print("  - Try saving to Desktop or Documents folder")
            pass


    def utility_MLP_set(self, X, y):
        print('🚀 Training MLP Pipeline: ')
        self.mlp.train(X, y, epochs=1000, lr=0.1)

        try:
            joblib.dump(self.mlp, 'analyzer_model.pkl')
            joblib.dump(self.model2, 'analyzer_agent.pkl')
            print("🎉 Model trained and saved!")            
        except Exception as e:
            print(f'|| Failed to joblib dump file! : {e}, User Manual filepath suggestion needed...')

            permission = input('|| Insert Filepath? [Y/N]: ')
            if permission == 'Y':
                suggested_path = input('|| Filepath suggestion: ')
                if suggested_path:
                    self.safe_pickle_save_with_feedback(self.mlp, suggested_path)
                    self.safe_pickle_save_with_feedback(self.model2, suggested_path)
                    print("🎉 Model trained and saved!")                     
                else:
                    print('|| Failed to dump Your model! ')
                    pass
            else:
                print('|| Failed to dump Your model! ')
                pass

        print("🎉 Model trained!")


    def auto_generate_labels_from_texts(self, rules, texts):
        import re
        y_raw = []
        self.rules = rules
     
        for text in texts:
            text_lower = text.lower()
            matched = False
            for pattern, label in rules:
                if re.search(pattern, text_lower):
                    y_raw.append(label)
                    matched = True
                    break
        
            if not matched:
                y_raw.append('other')
    
        from collections import Counter
        print("\n📊 Auto-generated label distribution:")
        for label, count in Counter(y_raw).items():
            print(f"   {label}: {count} ({count/len(texts)*100:.1f}%)")
    
        return y_raw



    def mlp_training_features(self, rules, dataset):
        print("\n🔄 Preparing MLP data from dataset format")
    
        if isinstance(dataset[0], tuple) and len(dataset[0]) == 2:
            # Format: [(features, label), ...]
            features_list = []
            labels_list = []
            print('Dataset Type 1: [(value), (value)]')

            for item in dataset:
                features, label = item
                features_list.append(features)
                labels_list.append(label)
        
            X_mlp = np.array(features_list)
            y_raw = np.array(labels_list)
        
        elif isinstance(dataset[0], (list, np.ndarray)) and len(dataset[0]) > 1:
            print('Dataset Type 2')
            X_mlp = np.array([item[:-1] for item in dataset])
            y_raw = np.array([item[-1] for item in dataset])

        else: 
            print('Dataset type 3')     
            X_mlp = dataset.copy()   
            y_raw = self.auto_generate_labels_from_texts(rules, dataset)         

        unique_labels = sorted(set(y_raw))
        label_to_idx = {l: i for i, l in enumerate(unique_labels)}
        y_indices = np.array([label_to_idx[l] for l in y_raw])
    
        n_classes = len(unique_labels)
        y_onehot = np.zeros((len(y_indices), n_classes))
        y_onehot[np.arange(len(y_indices)), y_indices] = 1

        if isinstance(X_mlp, np.ndarray):
            input_dim = X_mlp.shape[0]           
        else:
            input_dim = len(X_mlp)

        print(f"\n✅ MLP data ready:")
        print(f"   X shape: {input_dim}")
        print(f"   y shape: {y_onehot.shape}")
        print(f"   Classes: {label_to_idx}")     
        return X_mlp, y_onehot, n_classes, input_dim        

    def shape_adaptation(self, X, inp):
        tuple_ver = (inp, inp)
        if X.shape != tuple_ver:
            X = X[:inp, :inp]

        return X

    def AME_Encoder(self, x):
        # function that  handles abstraction modelling rate to predict model prediction capabilities.
        X = np.asarray(x)

        if isinstance(X, (str, np.str_)):
            clean_str = str(X).replace('[', '').replace(']', '')
            X = np.fromstring(clean_str, sep=' ')
        if isinstance(X, np.ndarray) and np.issubdtype(X.dtype, np.character):
            # catches arrays filled with string text
            clean_str = ' '.join(X.astype(str).flatten()).replace('[', '').replace(']', '')
            X = np.fromiter(
                    (x for x in clean_str.split() if x != "..."), dtype=float
                )               
        X = np.squeeze(X)
        if X.ndim == 1:
            X = np.atleast_2d(X).T  # Returns shape back to (12, 1) safely

        # Handle cropping for a 2D array
        if X.ndim == 2:
            rows, cols = X.shape
            new_rows = rows - 1 if (rows % 2 != 0 and rows > 1) else rows
            new_cols = cols - 1 if (cols % 2 != 0 and cols > 1) else cols
            
            X = X[:new_rows, :new_cols]

        if X.shape[1] == 1:
            gradient = np.gradient(X, axis=0)  # Calculate vertically instead of horizontally
        else:
            gradient = np.gradient(X, axis=-1) # Calculate horizontally
        grad_energy = np.mean(np.linalg.norm(gradient, axis=-1))       
        X_mag = np.mean(np.linalg.norm(X, axis=-1))

        AME = np.log1p(X_mag) * np.log1p(grad_energy) 

        if AME == 0.0:
            eps = 1e-5
            AME = AME + eps

        return AME

    def feature_generation(self, rules, dataset):
        X_raw, y, n_classes, input_dim = self.mlp_training_features(rules, dataset)
            
        self.initialize_fitting(X_raw)            
        X_tfidf = self.tfidf.transform(X_raw).toarray()
        X = X_tfidf.copy() 

        X = self.shape_adaptation(X, input_dim)  

        return X, y, input_dim, n_classes       


    # necessary functions to reduce wasteful training in similar scarce environment
    def training_necessary_condition(self, input_ids, x):
        eps = 1e-5
        final_conf = self.final_conf_score
        confidence_threshold = self.confidence_threshold
        unsuitable_training = False

        probs = self.model_memory_gate(input_ids, x)

        anisotropy = self.anisotropy_measurement(input_ids)
        AME = self.AME_Encoder(input_ids)
        AMR = 1.0 / (1.0 + np.exp(-AME)) 

        LMR = 1.0 / (1.0 + np.exp(-AMR)) # logistic modelling rate
        ALR = 1.0 / (1.0 + np.exp(-anisotropy)) # anisotropic logistic rate
        AAC = (1.0 - ALR) + (1.0 - LMR) + eps # anisotropic abstract coefficient

        self.confidence_threshold = anisotropy * AAC 
        if np.isnan(self.confidence_threshold) or np.isinf(self.confidence_threshold):
            self.confidence_threshold = 0.45

        print(f'[||] Confidence threshold set to: {self.confidence_threshold} || Final Confidence Score: {final_conf}')

        # training is wasteful if the model processes little abstraction divergence without necessary context on a similar environment
        # AMR is guaranteed to give sufficient ratio on how modelling error error could be sufficient enough to guarantee the model successful training 
        # (not too high that it shows unstability, not too low that it shows rigidity), high anisotropy correlates to a much complex non linearity that the model will have a hard time adjusting
        # higher LMR than AAC means the model is likely to be in a regime where training could lead to overfitting or divergence due to insufficient modelling capacity relative to the complexity of the data, especially if the confidence score is also low, indicating that the model is not currently confident in its predictions and may not benefit from further training on this data.
        unsuitable_tolerance = probs is not None or LMR > AAC 
        unsuitable_conditions = anisotropy > 0.85 or final_conf > confidence_threshold or self.froze_learning
        unsuitable_peer_request = probs is not None and self.peer_assistance_threshold > self.confidence_threshold

        if unsuitable_tolerance or unsuitable_conditions or unsuitable_peer_request:
            print(f'[==] Unsuitable training condition detected! Tolerance: {unsuitable_tolerance} || Unsuitable Conditions: {unsuitable_conditions}')
            print(f'[==] Peer assistance condition: {unsuitable_peer_request} || Peer assistance threshold: {self.peer_assistance_threshold}')
            unsuitable_training = True

        print('== Training Condition evaluation == ')
        print(f'[==] Unsuitable training condition Evaluation || Unsuitable Tolerance: {unsuitable_tolerance} || Unsuitable Conditions: {unsuitable_conditions} || Unsuitable Peer Assistance: {unsuitable_peer_request}')
        print('[==] Final Decision on Training: ' + ('Unsuitable' if unsuitable_training else 'Suitable') + ' for training.')

        return unsuitable_training

    def sequence_encoding(self, datasets, max_len=32):
        input_sequences = []
        for item in datasets:
            if not self.model2:
                intents = [d[1] for d in datasets]
                intent_to_id = {intent:i for i, intent in enumerate(sorted(set(intents)))}
                num_classes = len(intent_to_id)                
                self.model2 = Transformer(
                    vocab_size=len(self.vocab),
                    d_model=32,
                    n_heads=4,
                    num_classes=num_classes
                ) 

            text = item[0] if isinstance(item, tuple) else item
            token_ids = self.encode(text, self.vocab, max_len=max_len)
            token_embs = self.model2.token_embedding[token_ids]         # (max_len, d_model)
            pos_embs = self.model2.pos_embedding[:max_len]              # (max_len, d_model)
            sequence_input = token_embs + pos_embs
            input_sequences.append(sequence_input)
        return np.stack(input_sequences)  # shape: (batch, max_len, d_model)

    def transformer_pooled_features(self, sequence_inputs):
        # mean/max/std pooling over sequence dimension
        mean_pool = np.mean(sequence_inputs, axis=1)
        max_pool = np.max(sequence_inputs, axis=1)
        std_pool = np.std(sequence_inputs, axis=1)
        return np.concatenate([mean_pool, max_pool, std_pool], axis=-1)


    def _set_lstm_samples(self, X, Y):
        X = np.array(X)[..., np.newaxis]
        Y = np.array(Y)[..., np.newaxis]

        print('[=] Successfully set up LSTM Samples:')
        print(f'[=] X.shape: {X.shape}')
        print(f'[=] Y.shape: {Y.shape}')

        return X, Y

    def lstm_setup_inference(self, raw_X, raw_Y):
        print("\n" + "=" * 55)
        print("===== LSTM SETUP INFERENCE =====")
        print('[=] LSTM Setup is initiated for Longer short term memory.')

        scaler_y = self.standard_scaler 
        scrapper_engine = self.scrapper_model

        # build dataset for calibration
        AME = self.AME_Encoder(raw_X)  # geometric complexity scalar
        AMR = 1.0 / (1.0 + np.exp(-AME))  # abstract modelling rate

        X, Y = self._set_lstm_samples(raw_X, raw_Y)
        n_train = int(0.8 * len(X)) # 80% of the data training is used for training
        X_val   = X[n_train:]
        Y_val   = Y[n_train:]
        n_display = len(X_val)
        if n_display > 3:
            n_display = 3

        print('[= FIT =] Fitting Short Term Memory...')
        n_samples = scrapper_engine.lstm_optimal_samples(scrapper_engine, X_val[0])
        self.lstm_n_samples = n_samples

        label_bins = scrapper_engine.derive_bins_from_data(
            Y_val.ravel(),
            n_bins=4,
            labels=["Low", "Moderate", "High", "Extreme"]
        )
        # {"Low": (5.0, 42.3), "Moderate": (42.3, 68.1),
        #  "High": (68.1, 98.7), "Extreme": (98.7, 219.0)}

        # build and calibrate engine
        self.lstm_engine = LSTMEngine(self, self.network_model, 
                                       dropout=self.dropout_rate, n_samples=self.lstm_n_samples)
        
        engine = self.lstm_engine

        self.lstm_engine.fit_stm(X, Y)
        engine.calibrate(X_val, Y_val)

        print("\n[= LSTM INSIGHT =] Per-sample confidence report:")
        print(f"[*] {'#':<4} {'Predicted':>10} {'Actual':>10} "
            f"[*] {'Confidence':>12} {'Gate Uncert':>13} "
            f"[*] {'90% Interval':>20}  Label Confidence")
        print("  " + "─" * 100)

        # n display to see the prediction result over specific batch
        for j in range(n_display):
            result = engine.predict(X_val[j], label_bins=label_bins)

            p      = result["prediction"][-1]
            actual = Y_val[j, -1, 0]
            conf   = result["overall"]
            gate_u = result["gate_uncertainty"][-1]
            lo     = result["interval_low"][-1]
            hi     = result["interval_high"][-1]
            lc     = result["label_confidence"]

            best_label = max(lc, key=lc.get)
            label_str  = "  ".join(f"{k}={v:.0%}" for k,v in lc.items())

            print(f"  {j:<4} {p:>+10.4f} {actual:>+10.4f} "
                f"{conf:>12.1%} {gate_u:>13.3f} "
                f"  [{lo:+.3f}, {hi:+.3f}]"
                f"  {label_str}")

        print('[=+=] ==== STATUS REPORT ====')
        print("\n[=] Confidence breakdown for sample 0:")
        r = engine.predict(X_val[0], label_bins=label_bins)
        print(f"    MC mean (last step)   : {r['mc_mean'][-1]:+.4f}")
        print(f"    MC std  (last step)   : {r['mc_std'][-1]:.4f}  "
            f"← tight = certain")
        print(f"    Gate uncertainty      : {r['gate_uncertainty'][-1]:.4f}  "
            f"← low = stable memory")
        print(f"    MC confidence         : {r['mc_confidence'][-1]:.1%}")
        print(f"    Overall confidence    : {r['overall']:.1%}")
        print(f"    90% interval          : "
            f"[{r['interval_low'][-1]:+.4f}, {r['interval_high'][-1]:+.4f}]")
        print(f"    Label confidence      : {r['label_confidence']}")

        self.cache['lstm_result'] = result
        self.cache['label_bins'] = label_bins


    def transformer_utilities(self, rules, datasets, X_raw, y_true=None, batch_size=2, min_signal=1e-3):
        self.text_encoder(datasets)
        if y_true is None:
            _, y_true = self.input_encoding(datasets)

        sequence_inputs = self.sequence_encoding(datasets)
        unsuitable_training = self.training_necessary_condition(sequence_inputs, X_raw)
        lr = self.model2.transformer_lr if self.model2 else self.transformer_lr

        if not unsuitable_training:
            print(f'🚀 Training Transformer with {len(sequence_inputs)} Samples: ')
            conditional_anisotropy = self.anisotropy_measurement(sequence_inputs)
            if conditional_anisotropy >= self.confidence_threshold: 
                print('[+] Dynamic Backward')
                mode = 'dynamic_backward'
            else:
                print('[-] Fixed Backward')
                mode = 'fixed_backward'

            if self.use_transformer:
                self.model2.train(sequence_inputs, y_true, epochs=100, mode=mode, lr=lr, embedded=True, batch_size=batch_size)

            X_raw_generation, y, n_classes, input_dim = self.mlp_training_features(rules, datasets)
            X_raw_features = self.tfidf.transform(X_raw_generation).toarray()
            X_raw_features = self._refit_sparse_data(X_raw_features, X_raw_generation)      
            
            row_sums = X_raw_features.sum(axis=1)
            weak_rows = np.where(row_sums < min_signal)[0]
            weak_ratio = len(weak_rows) / len(X_raw_features)

            print(f'[!] Zero ratio in samples: {weak_ratio * 100}')
            if weak_ratio > 0.3:  # more than 30% zero rows means vocab mismatch
                print(f'[= ! =] High zero-row ratio ({weak_ratio:.0%}), refitting TF-IDF on current batch')
                self.tfidf.fit(X_raw_generation)
                X_raw_features = self.tfidf.transform(X_raw_generation).toarray()  

            transformer_features = self.transformer_pooled_features(sequence_inputs)
            X_raw_features = np.concatenate([X_raw_features, transformer_features], axis=-1)
            
            zero_rows = np.where(X_raw_features.sum(axis=1) == 0)[0]
            if len(zero_rows) > 0:
                print(f'[!] {len(zero_rows)} zero rows detected, applying checksum fallback')
                for i in zero_rows:
                    text = X_raw[i] if isinstance(X_raw[i], str) else str(X_raw[i])
                    checksum = int(hashlib.md5(text.encode()).hexdigest(), 16)
                    # distribute checksum signal across feature dims
                    rng = np.random.default_rng(checksum)
                    X_raw_features[i] = rng.uniform(0.01, 0.1, size=X_raw_features.shape[1])  

            X_features = X_raw_features.copy()
            if isinstance(X_raw_features, list):
                X_features = np.asarray(X_raw_features)
            if isinstance(X_raw, list):
                X_raw = np.asarray(X_raw) 

            # hybrid features by dot product of raw features and extracted features from transformer, this allows the MLP to learn from both the original feature space and the transformer-extracted feature space
            # potentially improving its ability to capture complex patterns in the given first data   
            try:
                if len(X_features.shape) < 2: 
                    X_features = X_features.reshape(1, -1)
                if len(X_raw.shape) < 2:
                    X_raw = X_raw.reshape(1, -1)
                                    
                X_raw = X_raw[:X_features.shape[0], :X_features.shape[1]]

                hybrid_X = np.dot(X_raw, X_features.T)
            except:
                if len(X_features.shape) < 2: 
                    X_features = X_features.reshape(1, -1)
                if len(X_raw.shape) < 2:
                    X_raw = X_raw.reshape(1, -1)

                subnet_X_feature = X_features[:X_raw.shape[1], :X_raw.shape[0]]
                subnet_X_raw = X_raw[:, :subnet_X_feature.shape[0]]
                hybrid_X = np.dot(subnet_X_raw, subnet_X_feature)
            
            hybrid_X = np.concatenate([X_raw, X_features, hybrid_X], axis=-1)
            self.initialize_fitting(X_raw_generation)            
            X = self.shape_adaptation(hybrid_X, input_dim)
                
            self.lstm_setup_inference(X, y) 
            self.initialize_model_(X, input_dim, n_classes)
            self.model3.train(X, y, epochs=1000, lr=0.1)

            if self.lstm_engine:
                self.storage.save_weights(self.memory_name, model_type='Pipeline') 

            print('🎉 All Model Trained!')
        else:
            print(f'[=] No suitable condition for training!')
            print('[=] Saving Weights for prediction')
            self.storage.load_weights(self.memory_name)

            pass

    def transformer_input_encoding(self, titles):
        if hasattr(self, 'vocab') and self.vocab:
            print("🔄 Using Transformer for probability calibration")
            input_ids_list = []
            for title in titles:
                if isinstance(title, tuple):
                    title = title[0]
                    
                ids = self.encode(title, self.vocab)
                input_ids_list.append(np.array(ids))
                
                input_ids = np.array(input_ids_list)
                return input_ids

        else:
            print('[-] Cant get sufficient data!')
            return []


    def train(self, X, y_raw):
        self.initialize_fitting(X)            
        X_tfidf = self.tfidf.transform(X).toarray()
        self.X = X_tfidf.copy()

        print(f"\n🚀 Separate Modular MLP Pipeline:")
        print(f" Samples: {len(self.X)}")

        y_true = self.initialize_model_encoding(self.X, y_raw)
        self.utility_MLP_set(self.X, y_true)       
        print('✅ Done Training MLP Model! ')
         
class RateLimiter:
    '''
    Token-bucket rate limiter (thread-safe).

    Algorithm
    ---------
    The bucket starts full (tokens = requests_per_minute).  Each acquire()
    call refills the bucket proportionally to the elapsed time since the last
    refill (continuous refill model), then attempts to consume one token.

    acquire() returns True if a token was available (request allowed) or
    False if the bucket was empty (request denied).  The internal lock
    ensures correctness under concurrent access from multiple threads.

    Parameters
    ----------
    requests_per_minute : Maximum request rate.  Default 60 (1/sec on average).
    '''
    # Token bucket rate limiter
    
    def __init__(self, requests_per_minute: int = 60):
        self.requests_per_minute = requests_per_minute
        self.tokens = requests_per_minute
        self.last_refill = time.time()
        self._lock = threading.Lock()
    
    def acquire(self) -> bool:
        with self._lock:
            now = time.time()
            # Refill tokens
            elapsed = now - self.last_refill
            new_tokens = elapsed * (self.requests_per_minute / 60)
            self.tokens = min(self.requests_per_minute, self.tokens + new_tokens)
            self.last_refill = now
            
            if self.tokens >= 1:
                self.tokens -= 1
                return True
            return False

class InputSanitizer:
    '''
    Static text sanitisation and validation utilities.

    sanitize_text(text, max_length)
        Strips ASCII control characters (except tab/newline), rejects inputs
        longer than max_length, and removes common injection-style escape
        sequences (hex \\xNN, unicode \\uNNNN) from the string.  Intended to
        be called before passing user-supplied text to the model or logging it.

    Raises SecurityError (a subclass of Exception defined in this module) on
    type violations or length overflows so callers can catch it uniformly.
    '''
    # Sanitize and validate inputs
    
    @staticmethod
    def sanitize_text(text: str, max_length: int = 10000) -> str:
        if not isinstance(text, str):
            raise SecurityError("[-] Input must be a string")
        
        # RemovING null bytes and control characters
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
        
        # Limit length
        if len(text) > max_length:
            raise SecurityError(f"[-] Text exceeds maximum length of {max_length}")
        
        # Remove potential injection patterns (for logging/serialization)
        dangerous_patterns = [
            r'[\x00-\x08\x0b\x0c\x0e-\x1f]',  # Control chars
            r'\\x[0-9a-fA-F]{2}',  # Hex escapes
            r'\\u[0-9a-fA-F]{4}',  # Unicode escapes
        ]
        
        for pattern in dangerous_patterns:
            if re.search(pattern, text):
                # Log but don't block - just escape
                text = re.sub(pattern, '?', text)
        
        return text.strip()
    
    @staticmethod
    def validate_batch_size(size: int, max_batch: int = 100) -> bool:
        if size <= 0 or size > max_batch:
            raise SecurityError(f"[-] Batch size must be between 1 and {max_batch}")
        return True

class ApiKeyManager:
    '''
    Thread-safe API key lifecycle manager with automatic rotation.

    Key storage
    -----------
    Keys are never stored in plain text.  Only the SHA-256 hash of the raw
    key value is kept in self.keys, so a DB/memory dump does not reveal active
    keys.

    Rotation
    --------
    validate_key() automatically deactivates keys that are older than
    rotation_days (default 30).  Callers receive False on the same request
    that triggers deactivation, so they can prompt the user to regenerate.

    Methods
    -------
    generate_key(metadata, key_value)
        Creates a new key.  If key_value is provided (e.g. a user-supplied
        secret) it is hashed and registered; otherwise a cryptographically
        random URL-safe 32-byte token is generated via secrets.token_urlsafe.
    validate_key(api_key) → bool
        Checks existence, activation status, and age.
    revoke_key(api_key) → bool
        Deactivates a key immediately.
    '''
    # Manage API keys with rotation
    
    def __init__(self, rotation_days: int = 30):
        self.keys: Dict[str, dict] = {}  # key_hash -> {created_at, last_used, metadata}
        self.rotation_days = rotation_days
        self._lock = threading.Lock()
    
    def generate_key(self, metadata: dict = None, key_value: str = None) -> str:
        # Generate a new API key
        if key_value:
            # Use provided key value
            raw_key = key_value
        else:
            # Generate random key
            raw_key = secrets.token_urlsafe(32)    

        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        
        with self._lock:
            self.keys[key_hash] = {
                'created_at': datetime.now(),
                'last_used': None,
                'metadata': metadata or {},
                'is_active': True
            }
        
        return raw_key
    
    def validate_key(self, api_key: str) -> bool:
        # Validate an API key
        if not api_key:
            return False
        
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        
        with self._lock:
            key_info = self.keys.get(key_hash)
            if not key_info or not key_info.get('is_active', False):
                return False
            
            # Check rotation
            age = (datetime.now() - key_info['created_at']).days
            if age >= self.rotation_days:
                key_info['is_active'] = False
                return False
            
            key_info['last_used'] = datetime.now()
            return True
    
    def revoke_key(self, api_key: str) -> bool:
        # Revoke an API key
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        with self._lock:
            if key_hash in self.keys:
                self.keys[key_hash]['is_active'] = False
                return True
        return False

class AsyncResultQueue:
    """
    Complete result queue with integrated processor.
    Handles callbacks, webhooks, WebSocket, storage, and streaming.
    """
    
    def __init__(self, max_size: int = 1000, cleanup_interval: int = 60):
        self._requests: Dict[str, AsyncRequest] = {}
        self._pending_queue: asyncio.Queue = asyncio.Queue(maxsize=max_size)
        self._completion_queue: asyncio.Queue = asyncio.Queue()
        self._result_futures: Dict[str, asyncio.Future] = {}
        self._lock = asyncio.Lock()
        self._cleanup_interval = cleanup_interval
        self._running = False
        
        # Result processor components
        self._cleanup_task: Optional[asyncio.Task] = None
        self._processor_task: Optional[asyncio.Task] = None
        
        # Optional features
        self._webhook_url: Optional[str] = None
        self._websocket_clients: List = []  # Store WebSocket connections
        self._storage_enabled: bool = False
        self._storage_path: Optional[str] = None
        self._streaming_queue: Optional[asyncio.Queue] = None
        
        # Metrics
        self._metrics = {
            'total_completed': 0,
            'total_failed': 0,
            'total_callbacks': 0,
            'total_webhooks': 0,
            'avg_processing_time': 0.0
        }
    
    # ============ INITIALIZATION ============
    
    async def start(self, 
                   webhook_url: str = None,
                   storage_path: str = None,
                   enable_streaming: bool = False):
        """
        Start the result queue with optional features.
        
        Args:
            webhook_url: Send results to this URL when complete
            storage_path: Save results to disk
            enable_streaming: Enable result streaming queue
        """
        self._running = True
        self._webhook_url = webhook_url
        self._storage_enabled = bool(storage_path)
        self._storage_path = storage_path
        
        if enable_streaming:
            self._streaming_queue = asyncio.Queue()
        
        # Start background tasks
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())
        self._processor_task = asyncio.create_task(self._result_processor())
        
         
        logger.info("✅ AsyncResultQueue started")
        


    async def stop(self):
        """Stop the result queue"""
        self._running = False
        
        if self._cleanup_task:
            self._cleanup_task.cancel()
        if self._processor_task:
            self._processor_task.cancel()
        
        await asyncio.gather(
            self._cleanup_task, 
            self._processor_task, 
            return_exceptions=True
        )
        
        logger.info("✅ AsyncResultQueue stopped")
    
    # ============ REQUEST SUBMISSION ============
    
    async def submit(self, 
                    texts, 
                    api_key: str = None, 
                    client_ip: str = None,
                    callback: Callable = None,
                    webhook_url: str = None) -> str:
        """
        Submit a prediction request.
        
        Args:
            texts: List of input texts to predict
            api_key: API key for authentication
            client_ip: Client IP address
            callback: Optional callback function
            webhook_url: Optional webhook for this specific request
            
        Returns:
            request_id for tracking
        """
        request_id = str(uuid.uuid4())
        
        async with self._lock:
            request = AsyncRequest(
                request_id=request_id,
                texts=texts,
                api_key=api_key,
                client_ip=client_ip,
                callback=callback,
                webhook_url=webhook_url
            )
            self._requests[request_id] = request
            
            # Create future for awaiting result
            future = asyncio.Future()
            self._result_futures[request_id] = future
            
            # Add to processing queue
            await self._pending_queue.put(request)
            
        logger.debug(f"[=] Submitted request {request_id}: {texts}")
        return request_id
    
    async def wait_for_result(self, request_id: str, timeout: int = 30) -> Dict:
        """
        Wait for a specific request to complete.
        
        Args:
            request_id: ID from submit()
            timeout: Maximum wait time in seconds
            
        Returns:
            Prediction result dictionary
        """
        async with self._lock:
            future = self._result_futures.get(request_id)
            if not future:
                request = self._requests.get(request_id)
                if request and request.status == RequestStatus.COMPLETED:
                    return request.result
                raise ValueError(f"[=] Unknown request_id: {request_id}")
        
        try:
            result = await asyncio.wait_for(future, timeout=timeout)
            return result
        except asyncio.TimeoutError:
            await self._mark_failed(request_id, "Request timeout")
            raise
        finally:
            async with self._lock:
                self._result_futures.pop(request_id, None)
    
    async def complete(self, request_id: str, result: Dict):
        """
        Mark a request as completed with result.
        Called by worker when prediction is done.
        """
        async with self._lock:
            request = self._requests.get(request_id)
            if not request:
                logger.warning(f"[=] Request {request_id} not found")
                return
            
            request.status = RequestStatus.COMPLETED
            request.result = result
            request.completed_at = time.time()
            
            # Calculate processing time for metrics
            processing_time = request.completed_at - request.created_at
            alpha = 0.1
            self._metrics['avg_processing_time'] = (
                alpha * processing_time + 
                (1 - alpha) * self._metrics['avg_processing_time']
            )
            
            # Add to completion queue for processor
            await self._completion_queue.put(request)
            
            logger.debug(f"[=] Request {request_id} completed in {processing_time:.2f}s")
    
    async def _mark_failed(self, request_id: str, error: str):
        """Mark a request as failed"""
        async with self._lock:
            request = self._requests.get(request_id)
            if request:
                request.status = RequestStatus.FAILED
                request.error = error
                request.completed_at = time.time()
                await self._completion_queue.put(request)
            
            future = self._result_futures.get(request_id)
            if future and not future.done():
                future.set_exception(Exception(error))
    
    async def get_pending(self) -> Optional[AsyncRequest]:
        """Get next pending request (blocks)"""
        try:
            return await self._pending_queue.get()
        except asyncio.CancelledError:
            return None
    
    # ============ THE MAIN RESULT PROCESSOR ============
    
    async def _result_processor(self):
        """
        Process results as they complete.
        Handles: Callbacks, Webhooks, WebSocket, Storage, Streaming
        """
        logger.info("[=] Result processor started")
        
        while self._running:
            try:
                # Wait for a completed request
                completed_request = await asyncio.wait_for(
                    self._completion_queue.get(), 
                    timeout=1.0
                )
                
                if not completed_request:
                    continue
                
                request_id = completed_request.request_id
                result = completed_request.result
                error = completed_request.error
                is_success = error is None
                
                # Update metrics
                if is_success:
                    self._metrics['total_completed'] += 1
                else:
                    self._metrics['total_failed'] += 1
                
                # ============ 1. EXECUTE CALLBACK ============
                if completed_request.callback:
                    try:
                        self._metrics['total_callbacks'] += 1
                        
                        # Support both sync and async callbacks
                        if asyncio.iscoroutinefunction(completed_request.callback):
                            # Async callback
                            await completed_request.callback(request_id, result, error)
                        else:
                            # Sync callback - run in thread pool
                            await asyncio.to_thread(
                                completed_request.callback,
                                request_id, result, error
                            )
                        logger.debug(f"[=] Callback executed for {request_id}")
                        
                    except Exception as e:
                        logger.error(f"[=] Callback failed for {request_id}: {e}")
                
                # ============ 2. RESOLVE WAITING FUTURE ============
                future = self._result_futures.get(request_id)
                if future and not future.done():
                    if error:
                        future.set_exception(Exception(error))
                    else:
                        future.set_result(result)
                    self._result_futures.pop(request_id, None)
                
                # ============ 3. WEBHOOK NOTIFICATION ============
                webhook_url = completed_request.webhook_url or self._webhook_url
                if webhook_url and is_success:
                    await self._send_webhook(webhook_url, {
                        'request_id': request_id,
                        'status': 'success',
                        'result': result,
                        'timestamp': completed_request.completed_at
                    })
                    self._metrics['total_webhooks'] += 1
                
                # ============ 4. WEBSOCKET PUSH ============
                if self._websocket_clients:
                    await self._broadcast_websocket({
                        'type': 'prediction_complete',
                        'request_id': request_id,
                        'result': result,
                        'error': error,
                        'processing_time': completed_request.completed_at - completed_request.created_at
                    })
                
                # ============ 5. PERSISTENT STORAGE ============
                if self._storage_enabled and is_success:
                    await self._store_result(request_id, result, completed_request)
                
                # ============ 6. STREAMING TO RESPONSE QUEUE ============
                if self._streaming_queue:
                    await self._streaming_queue.put({
                        'request_id': request_id,
                        'result': result,
                        'error': error,
                        'completed_at': completed_request.completed_at
                    })
                
                # ============ 7. LOG COMPLETION ============
                logger.info(
                    f"[=] Request {request_id} processed - "
                    f"[=] Success: {is_success}, "
                    f"[=] Time: {completed_request.completed_at - completed_request.created_at:.2f}s"
                )
                
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"[=] Result processor error: {e}")
                await asyncio.sleep(0.1)
        
        logger.info("[=] Result processor stopped")
    
    # ============ WEBHOOK HANDLER ============
    
    async def _send_webhook(self, url: str, data: dict):
        """Send result to webhook URL"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url, 
                    json=data,
                    timeout=aiohttp.ClientTimeout(total=5)
                ) as response:
                    if response.status == 200:
                        logger.debug(f"[=] Webhook sent to {url}")
                    else:
                        logger.warning(f"[=] Webhook failed: {response.status}")
        except Exception as e:
            logger.error(f"[=] Webhook error: {e}")
    
    # ============ WEBSOCKET HANDLER ============
    
    async def register_websocket(self, websocket):
        """Register a WebSocket client for real-time updates"""
        self._websocket_clients.append(websocket)
        
        # Remove when closed
        try:
            await websocket.wait_closed()
        finally:
            self._websocket_clients.remove(websocket)
    
    async def _broadcast_websocket(self, message: dict):
        """Broadcast message to all connected WebSocket clients"""
        disconnected = []
        
        for client in self._websocket_clients:
            try:
                await client.send_json(message)
            except:
                disconnected.append(client)
        
        # Clean up disconnected clients
        for client in disconnected:
            self._websocket_clients.remove(client)
    
    # ============ PERSISTENT STORAGE ============
    
    async def _store_result(self, request_id: str, result: dict, request: AsyncRequest):
        # Store result to disk
        if not self._storage_path:
            return
        
        try:
            import aiofiles
            import os
            
            os.makedirs(self._storage_path, exist_ok=True)
            
            filepath = os.path.join(self._storage_path, f"{request_id}.json")
            
            data = {
                'request_id': request_id,
                'text': request.text,
                'result': result,
                'created_at': request.created_at,
                'completed_at': request.completed_at,
                'processing_time': request.completed_at - request.created_at
            }
            
            async with aiofiles.open(filepath, 'w') as f:
                await f.write(json.dumps(data, indent=2))
                
            logger.debug(f"[=] Result stored: {filepath}")
            
        except Exception as e:
            logger.error(f"[=] Storage failed: {e}")
    
    # ============ RESULT STREAMING ============
    
    async def get_result_stream(self) -> asyncio.Queue:
        """
        Get a queue that receives results as they complete.
        Useful for streaming responses to clients.
        """
        if not self._streaming_queue:
            self._streaming_queue = asyncio.Queue()
        return self._streaming_queue
    
    # ============ CLEANUP ============
    
    async def _cleanup_loop(self):
        # Periodically clean up expired and old requests
        while self._running:
            await asyncio.sleep(self._cleanup_interval)
            
            async with self._lock:
                now = time.time()
                
                # Find expired pending requests
                expired = [
                    req_id for req_id, req in self._requests.items()
                    if req.is_expired and req.status in (RequestStatus.PENDING, RequestStatus.PROCESSING)
                ]
                
                for req_id in expired:
                    request = self._requests[req_id]
                    request.status = RequestStatus.TIMEOUT
                    request.completed_at = now
                    request.error = "Request expired"
                    await self._completion_queue.put(request)
                    
                    # Clean up future
                    future = self._result_futures.pop(req_id, None)
                    if future and not future.done():
                        future.set_exception(TimeoutError(f"Request {req_id} expired"))
                
                # Remove completed/failed/timeout requests older than 1 hour
                old_cutoff = now - 3600
                to_remove = [
                    req_id for req_id, req in self._requests.items()
                    if req.completed_at and req.completed_at < old_cutoff
                ]
                for req_id in to_remove:
                    self._requests.pop(req_id, None)
                
                if expired:
                    logger.info(f"[=] Cleaned up {len(expired)} expired requests")
    
    async def _cleanup_request(self, request_id: str):
        # Clean up a single completed request after processing
        # Schedule for removal after delay
        async def _delayed_remove():
            await asyncio.sleep(3600)  # Keep for 1 hour
            async with self._lock:
                self._requests.pop(request_id, None)
        
        asyncio.create_task(_delayed_remove())
    
    # ============ UTILITY METHODS ============
    
    def _update_metrics(self, request: AsyncRequest):
        # Update metrics after processing
        # Metrics already updated in complete() and _result_processor
        pass
    
    def get_status(self, request_id: str) -> Optional[RequestStatus]:
        # Get status of a request
        request = self._requests.get(request_id)
        return request.status if request else None
    
    def get_result(self, request_id: str) -> Optional[Dict]:
        # Get result if completed
        request = self._requests.get(request_id)
        if request and request.status == RequestStatus.COMPLETED:
            return request.result
        return None
    
    def get_metrics(self) -> Dict:
        # Get queue metrics
        return {
            **self._metrics,
            'pending_count': self._pending_queue.qsize(),
            'completion_count': self._completion_queue.qsize(),
            'total_requests': len(self._requests),
            'pending': sum(1 for r in self._requests.values() if r.status == RequestStatus.PENDING),
            'processing': sum(1 for r in self._requests.values() if r.status == RequestStatus.PROCESSING),
            'completed': sum(1 for r in self._requests.values() if r.status == RequestStatus.COMPLETED),
            'failed': sum(1 for r in self._requests.values() if r.status == RequestStatus.FAILED),
            'timeout': sum(1 for r in self._requests.values() if r.status == RequestStatus.TIMEOUT)
        }

class WorkerPool:
    """
    Worker pool that processes requests from the result queue.
    """
    
    def __init__(self, result_queue: AsyncResultQueue, num_workers: int = 4):
        self.result_queue = result_queue
        self.num_workers = num_workers
        self._workers: List[asyncio.Task] = []
        self._running = False
    
    async def start(self, predict_func):
        # Start worker pool with prediction function
        self._running = True
        self._workers = [
            asyncio.create_task(self._worker(predict_func))
            for _ in range(self.num_workers)
        ]

        await self.result_queue.start()
        
    async def stop(self):
        # Stop all workers
        self._running = False
        await self.result_queue.stop()

        # cancel and wait for all workers to exit cleanly
        for worker in self._workers:
            worker.cancel()

        if self._workers:
            await asyncio.gather(*self._workers, return_exceptions=True)

        self._workers.clear()

    async def _worker(self, predict_func):
        # Worker that processes requests
        while self._running:
            try:
                # Get next pending request
                request = await self.result_queue.get_pending()
                if not request:
                    continue
                
                # Mark as processing
                async with self.result_queue._lock:
                    request.status = RequestStatus.PROCESSING
                
                try:
                    # Execute prediction (run sync function in thread pool)
                    result = await asyncio.to_thread(
                        predict_func,
                        texts=request.texts,
                        api_key=request.api_key,
                        client_ip=request.client_ip
                    )
                    
                    # Mark as completed
                    await self.result_queue.complete(request.request_id, result)
                    
                except Exception as e:
                    # Mark as failed
                    await self.result_queue._mark_failed(request.request_id, str(e))
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"[=] Worker error: {e}")
                await asyncio.sleep(0.1)

class PipelineAsyncManager:
    """
    Robust wrapper for using async features in synchronous code.
    
    Features:
    - Automatic retry on failure
    - Task tracking and cleanup
    - Graceful shutdown with timeout
    - Health monitoring
    - Queue for pending requests
    - Thread-safe operations
    - Security Layers
    """
    
    def __init__(self, pipeline, prediction_manager, config: SecurityConfig=None, security_level: SecurityLevel = SecurityLevel.STAGING, state_file: str = None, api_key: Any=None, max_workers=4, task_timeout=30, max_retries=3):
        self.pipeline = pipeline
        self.prediction_manager = prediction_manager
        self.max_workers = max_workers
        self.default_timeout = task_timeout
        self.max_retries = max_retries
        
        self.security_level = security_level
        self.config = self._get_config_for_level(security_level) or SecurityConfig()

        # Security components
        self.rate_limiter = RateLimiter(self.config.rate_limit_requests)
        self.sanitizer = InputSanitizer()
        self.api_key_manager = ApiKeyManager(self.config.api_key_rotation_days) 
        
        # State management
        self._state = WrapperState.UNINITIALIZED
        self._lock = threading.RLock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
     
        # Task management
        self._pending_tasks: Dict[str, AsyncTask] = {}
        self._task_counter = 0
        self.timeout = 120
        self._task_lock = threading.Lock()
        
        # Queue for requests (when at capacity)
        self._request_queue: queue.Queue = queue.Queue(maxsize=1000)
        self._queue_worker: Optional[threading.Thread] = None
        
        # Rate limiting per IP
        self._ip_rate_limiters: Dict[str, RateLimiter] = defaultdict(
            lambda: RateLimiter(self.config.rate_limit_requests)
        ) 

        # Health monitoring
        self._health_check_interval = 30
        self._health_thread: Optional[threading.Thread] = None
        self._last_heartbeat: float = 0
        
        # Audit log
        self._audit_log: List[Dict] = []
        self._max_audit_log = 1000 

        # Statistics
        self._stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'timed_out_requests': 0,
            'avg_response_time': 0.0,
            'queue_size': 0
        }
        # Generate initial API key if enabled
        if self.config.require_api_key:
            self._default_api_key = api_key if api_key else self.api_key_manager.generate_key({'type': 'default'})
            print(f"[🔑] Default API Key: {self._default_api_key}")
            print("[!] Store this key securely - it won't be shown again!")

        self.state_file = state_file if state_file is not None else 'security_state.json'
        self.admin_keys: Dict[str, dict] = {}  # admin_token -> {role, created_at}
        self._load_state()
        self._bootstrap_token_hash = None
        self._bootstrap_token_file = "bootstrap.token"  

        # Generate initial admin key if none exists
        if not self.admin_keys or self.config.require_bootsrap_auth:
            self._initialize_bootstrap_security()

        self._start_count = 0
        self._last_start_time = 0
        self._failed_starts = 0
        self._pending_start = None
                 
        
    @property
    def state(self) -> str:
        # Get current wrapper state.
        return self._state.value
    
    @property
    def is_running(self) -> bool:
        # Check if wrapper is running.
        return self._state == WrapperState.RUNNING

    # ======= Security and Utility Methods =======

    def _get_config_for_level(self, level: SecurityLevel) -> SecurityConfig:
        # appropriate security config for deployment level
        
        if level == SecurityLevel.DEVELOPMENT:
            return SecurityConfig(
                require_api_key=False,
                rate_limit_requests=1000,
                min_start_interval=0,
                require_bootstrap_auth=False
            )
        
        elif level == SecurityLevel.STAGING:
            return SecurityConfig(
                require_api_key=True,
                rate_limit_requests=120,
                min_start_interval=2.0,
                require_bootstrap_auth=False
            )
        
        elif level == SecurityLevel.PRODUCTION:
            return SecurityConfig(
                require_api_key=True,
                rate_limit_requests=60,
                min_start_interval=5.0,
                max_consecutive_failures=3,
                require_bootstrap_auth=False  # Still off for auto-restart
            )
        
        elif level == SecurityLevel.HARDENED:
            return SecurityConfig(
                require_api_key=True,
                rate_limit_requests=30,
                min_start_interval=10.0,
                max_consecutive_failures=2,
                require_bootstrap_auth=True,  # Only for hardened
                bootstrap_token_hash=os.environ.get('BOOTSTRAP_TOKEN_HASH')
            )
     

    def _load_state(self):
        # Load persisted state
        if os.path.exists(self.state_file):
            with open(self.state_file, 'r') as f:
                state = json.load(f)
                # Restore API keys and IP lists
                self.config.allowed_ips = state.get('allowed_ips', [])
                self.config.blocklisted_ips = state.get('blocklisted_ips', [])
                # Restore API keys (needs careful handling)
    
    def _save_state(self):
        # Save state to disk
        with open(self.state_file, 'w') as f:
            json.dump({
                'allowed_ips': self.config.allowed_ips,
                'blocklisted_ips': self.config.blocklisted_ips,
                'last_saved': datetime.now().isoformat()
            }, f)

    def _audit(self, event_type: str, details: dict, client_ip: str = None):
        # Log security events
        entry = {
            'timestamp': datetime.now().isoformat(),
            'event': event_type,
            'details': details,
            'ip': client_ip
        }
        self._audit_log.append(entry)
        
        # Trim log
        if len(self._audit_log) > self._max_audit_log:
            self._audit_log = self._audit_log[-self._max_audit_log:]
        
        # Log critical events
        if event_type in ['auth_failure', 'security_block', 'rate_limit_exceeded']:
            print(f"[=⚠️ SECURITY=] {event_type}: {details}")  
            
        with open('security_audit.log', 'a') as f:
            f.write(json.dumps(entry) + '\n')
    

    def _verify_admin(self, admin_token: str, required_role: AdminRole = AdminRole.ADMIN) -> bool:
        # Verify admin token and role
        if not admin_token:
            return False
        
        token_hash = hashlib.sha256(admin_token.encode()).hexdigest()
        admin_info = self.admin_keys.get(token_hash)
        
        if not admin_info:
            return False
        
        # Check role hierarchy
        role_hierarchy = {
            AdminRole.ADMIN: 3,
            AdminRole.OPERATOR: 2,
            AdminRole.AUDITOR: 1
        }
        
        return role_hierarchy.get(admin_info['role'], 0) >= role_hierarchy.get(required_role, 0)
    
    def _check_ip_allowed(self, client_ip: str, is_admin: bool = False) -> bool:
        # IP checking with CIDR support
        # Check global blocklist first (applies to everyone)
        if client_ip in self.config.blocklisted_ips:
            self._audit('security_block', {'reason': 'blocklisted_ip', 'ip': client_ip}, client_ip)
            return False
        
        # Admin-specific IP whitelist
        if is_admin and self.config.enforce_admin_ip_whitelist:
            if self.config.admin_allowed_ips:
                # Check if admin IP is allowed
                if not self._ip_in_list(client_ip, self.config.admin_allowed_ips):
                    self._audit('security_block', 
                               {'reason': 'admin_ip_not_allowed', 'ip': client_ip}, 
                               client_ip)
                    return False
            return True
        
        # Regular user IP whitelist
        if self.config.allowed_ips:
            return self._ip_in_list(client_ip, self.config.allowed_ips)
        
        return True
        
    def _ip_in_list(self, ip: str, ip_list: List[str]) -> bool:
        # Check if IP matches any entry in list (supports CIDR)
        try:
            client = ipaddress.ip_address(ip)
            for allowed in ip_list:
                if '/' in allowed:
                    network = ipaddress.ip_network(allowed, strict=False)
                    if client in network:
                        return True
                elif ip == allowed:
                    return True
        except ValueError:
            pass
        return False    

    def _check_rate_limit(self, client_ip: str = None, is_admin: bool = False) -> bool:
        # Check rate limit for IP or global
        if is_admin and self.config.admin_bypass_rate_limit:
            # Admins use separate, higher limit or no limit
            if self.config.admin_rate_limit < 999:  # If limit is set
                limiter = self.admin_rate_limiter
            else:
                return True  # No rate limit for admins
        else:
            limiter = self._ip_rate_limiters.get(client_ip, self.rate_limiter)
        
        allowed = limiter.acquire()
        if not allowed:
            self._stats['rate_limiter_blocks'] += 1
            self._audit('rate_limit_exceeded', 
                       {'ip': client_ip or 'global', 'is_admin': is_admin}, 
                       client_ip)
        
        return allowed
        
    def _is_admin_token(self, api_key: str) -> bool:
        # Check if an API key is actually an admin token
        if not api_key:
            return False
        
        token_hash = hashlib.sha256(api_key.encode()).hexdigest()
        return token_hash in self.admin_keys
    
    def _authenticate(self, api_key: str, client_ip: str = None, is_admin: bool = False) -> bool:
        # Enhanced authentication - handles both API keys and admin tokens
        if not self.config.require_api_key:
            return True

        validation = api_key == self._default_api_key
        if self._default_api_key and validation:
            return True
        
        if not api_key:
            if 'auth_failures' in self._stats:
                self._stats['auth_failures'] += 1
                self._audit('auth_failure', {'reason': 'missing_api_key'}, client_ip)
            else:
                self._stats['auth_failures'] = 0
                self._stats['auth_failures'] += 1
                self._audit('auth_failure', {'reason': 'missing_api_key'}, client_ip)                
            return False
        
        # Check if it's an admin token first
        if self._is_admin_token(api_key):
            # Admin tokens are always valid (but may have other restrictions)
            return True
        
        # Regular API key validation
        valid = self.api_key_manager.validate_key(api_key)
        if not valid:
            if 'auth_failures' in self._stats:
                self._stats['auth_failures'] += 1
                self._audit('auth_failure', {'reason': 'invalid_api_key'}, client_ip)
            else:
                self._stats['auth_failures'] = 0
                self._stats['auth_failures'] += 1
                self._audit('auth_failure', {'reason': 'invalid_api_key'}, client_ip)                

        return valid if valid else validation

    # ======= Core Wrapper Methods =======
    def start(self, timeout: float = 5.0, method: str = None, bootstrap_token: str = None) -> bool:
        """
        Start the async event loop and workers.
        
        Args:
            timeout: Maximum time to wait for startup
            method: The prediction method to use
            bootstrap_token: Token for initial authentication

        Returns:
            True if started successfully, False otherwise
        """

        # Only check bootstrap token in HARDENED mode
        if self.security_level == SecurityLevel.HARDENED:
            if not self._validate_bootstrap_token(bootstrap_token):
                logger.error("[=] Bootstrap token required for HARDENED security level")
                return False

        with self._lock:
            if self._state in (WrapperState.RUNNING, WrapperState.STARTING):
                logger.warning(f"[=] AsyncWrapper already in state: {self._state}")
                return True
                
            self._state = WrapperState.STARTING 

            # Prevent rapid restart attacks (crash looping)
            now = time.time()
            if now - self._last_start_time < self.config.min_start_interval:
                logger.warning(f"[-] Start too frequent - need {self.config.min_start_interval}s between starts")
                self._audit('start_throttled', {'interval': now - self._last_start_time})
                return False
            
            # Track failed starts for circuit breaker
            if self._state == WrapperState.ERROR:
                self._failed_starts += 1
                if self._failed_starts > self.config.max_consecutive_failures:
                    logger.error(f"[-] Too many failed starts ({self._failed_starts}) - circuit open")
                    self._audit('circuit_open', {'failures': self._failed_starts})
                    return False
            else:
                self._failed_starts = 0  # Reset on success          
            
        try:
            print(f"[=] Starting PipelineAsyncManager with method: {method or 'default'}")
            # Start event loop thread
            self._start_with_limits(timeout, method=method)
            
            with self._lock:
                self._state = WrapperState.RUNNING
                self._last_heartbeat = time.time()
            
            logger.info(f"[=] PipelineAsyncManager started successfully (workers={self.max_workers})")
            return True
            
        except Exception as e:
            logger.error(f"[-] Failed to start manager: {e}")
            with self._lock:
                self._state = WrapperState.ERROR
            return False
            
    def _start_with_limits(self, timeout: float, method: str = None):
        # Start with resource limits to prevent abuse
        
        # Check system resources before starting
        try:
            import psutil
            
            # CPU limit
            if psutil.cpu_percent(interval=1) > self.config.max_cpu_percent:
                raise RuntimeError(f"[=] System CPU too high ({psutil.cpu_percent()}%)")
            
            # Memory limit  
            memory = psutil.virtual_memory()
            if memory.percent > self.config.max_memory_percent:
                raise RuntimeError(f"[=] System memory too high ({memory.percent}%)")
            
            # Disk space for logs
            disk = psutil.disk_usage('/')
            if disk.free < self.config.min_disk_space_mb * 1024 * 1024:
                raise RuntimeError(f"[=] Insufficient disk space ({disk.free / 1024 / 1024:.0f}MB)")
            
            # Proceed with normal startup
            self._thread = threading.Thread(
                target=self._run_event_loop,
                name="AsyncLoopThread",
                daemon=True
            )
            self._thread.start()
            
            # Wait for loop to start
            start_time = time.time()
            while self._loop is None and (time.time() - start_time) < timeout:
                time.sleep(0.01)

            print(f"[=] Event loop started in {time.time() - start_time:.2f}s")
            if self._loop is None:
                raise RuntimeError("[-] Event loop failed to start")
            
            self._start_queue_worker(method=method)
            self._start_health_monitor()
        except Exception as e:
            logger.error(f"[-] Startup failed due to resource limits: {e}")
            with self._lock:
                self._state = WrapperState.ERROR
                self._last_heartbeat = time.time()


    def _run_event_loop(self):
        # Run the async event loop in background thread.
        try:
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
            self._loop.run_forever()
        except Exception as e:
            logger.error(f"[-] Event loop crashed: {e}")
        finally:
            self._loop = None
    
    def _start_queue_worker(self, method):
        # Start worker thread for processing request queue.
        def process_queue():
            while self.is_running:
                try:
                    # Get request with timeout to allow checking state
                    request = self._request_queue.get(timeout=1.0)
                    self._submit_request(request, method=method)
                except queue.Empty:
                    continue
                except Exception as e:
                    logger.error(f"[-] Queue worker error: {e}")
        
        self._queue_worker = threading.Thread(
            target=process_queue,
            name="QueueWorker",
            daemon=True
        )
        self._queue_worker.start()
    
    def _start_health_monitor(self):
        # Start health monitoring thread.
        def monitor():
            while self.is_running:
                time.sleep(self._health_check_interval)
                logger.info("[.] Checking health...")
                self._check_health()
        
        self._health_thread = threading.Thread(
            target=monitor,
            name="HealthMonitor",
            daemon=True
        )
        self._health_thread.start()
    
    def _check_health(self):
        # Check health of the wrapper and its components.
        now = time.time()
        
        # Check event loop responsiveness
        if self._loop and self._loop.is_running():
            self._last_heartbeat = now
        elif self._state == WrapperState.RUNNING:
            logger.warning("[-] Event loop not responding, attempting recovery")
            self._recover()
        
        # Check for stuck tasks
        with self._task_lock:
            stuck_tasks = [
                task for task in self._pending_tasks.values()
                if (now - task.created_at) > task.timeout * 2
            ]
            
            for task in stuck_tasks:
                logger.warning(f"[-] Cancelling stuck task {task.id}")
                task.future.cancel()
                del self._pending_tasks[task.id]
        
        # Update stats
        with self._lock:
            self._stats['queue_size'] = self._request_queue.qsize()
    
    def _recover(self):
        # Attempt to recover from failure.
        logger.warning("[==] Attempting recovery...")
        with self._lock:
            if self._state != WrapperState.RUNNING:
                return
        
        try:
            # Stop current loop
            if self._loop and self._loop.is_running():
                self._loop.call_soon_threadsafe(self._loop.stop)
            
            # Restart
            self.stop()
            time.sleep(1)
            self.start()
            
        except Exception as e:
            logger.error(f"[-] Recovery failed: {e}")
            with self._lock:
                self._state = WrapperState.ERROR
    
    def predict(self, texts, timeout: float = None, retries: int = None, api_key: str = None, client_ip: str = None, method: str = 'advanced') -> Any:
        """
        Synchronous prediction with layered security retry logic.
        
        Args:
            texts: List of input texts to predict
            timeout: Timeout in seconds (default: self.default_timeout)
            retries: Number of retries on failure (default: self.max_retries)
            method: Prediction method to use (default: 'advanced')

        Returns:
            Prediction result dictionary
        """
            
        try:
            if not self.pipeline.autonomous: 
                print('[=+=] Initiating Autonomous prediction handling...')
                self.pipeline.autonomous = True
                self.pipeline.ensemble.explainer.supervised_learning = False

            # Security checks
            is_admin = self._is_admin_token(api_key)
            if not self._check_ip_allowed(client_ip or 'unknown', is_admin=is_admin):
                raise SecurityError("[==] IP not allowed")
            
            if not self._check_rate_limit(client_ip, is_admin=is_admin):
                raise SecurityError("[==] Rate limit exceeded")
            
            if not self._authenticate(api_key, client_ip, is_admin=is_admin):
                raise SecurityError("[==] Authentication failed")
                
            # Input validation
            try:
                try:
                    if not 'test_titles' in texts and 'label_map' in texts and 'rules' in texts and 'X' in texts and 'y' in texts:
                        for i in range(len(texts)):
                            if isinstance(texts[i], tuple):
                                texts[i] = texts[i][0]  # Extract text from tuple if needed
                                sanitized_texts = self.sanitizer.sanitize_text(texts[i], self.config.max_text_length)
                            else:
                                sanitized_texts = self.sanitizer.sanitize_text(texts[i], self.config.max_text_length)
                    else:
                        sanitized_texts = texts  # Will handle advanced case separately

                except (IndexError, TypeError):
                    # partial sanitization failure, try to sanitize first text if possible and proceed with original texts
                    sanitized_texts = self.sanitizer.sanitize_text(texts[0][0], self.config.max_text_length)

                # texts validated and sanitized at this point, can proceed with original texts for prediction
                if sanitized_texts is None:
                    raise SecurityError("[==] Input validation failed - empty text")

            except SecurityError as e:
                self._audit('input_rejected', {'reason': str(e), 'original_length': len(texts)}, client_ip)
                raise
            
            # Check pending tasks limit
            with self._task_lock:
                if len(self._pending_tasks) >= self.config.max_pending_tasks:
                    self._audit('resource_limit', {'reason': 'max_pending_tasks'}, client_ip)
                    raise SecurityError("[--] Server at capacity - too many pending requests")      

            if not self.is_running:
                if not self.start():
                    raise RuntimeError("[-] AsyncWrapper not running and failed to start")
            
            timeout = timeout or self.default_timeout
            retries = retries or self.max_retries
            
            with self._lock:
                self._stats['total_requests'] += 1
            
            start_time = time.time()
            
            for attempt in range(retries):
                try:
                    # Submit request and wait for result
                    if method != 'advanced':
                        if isinstance(texts, tuple):
                            texts = texts[0]
                            
                        result = self._predict_sync(texts, timeout)
                    else:
                        if 'test_titles' in texts and 'label_map' in texts and 'rules' in texts and 'X' in texts and 'y' in texts:
                            result = self._advanced_predict_sync(texts['test_titles'], texts['label_map'], texts['rules'], texts['X'], texts['y'], texts.get('agent_id', 'default'), texts.get('use_transformer', False), timeout)
                        else:
                            if isinstance(texts, tuple):
                                texts = texts[0]

                            result = self._predict_sync(texts, timeout)

                    # Update success stats
                    elapsed = time.time() - start_time
                    with self._lock:
                        self._stats['successful_requests'] += 1
                        # Update moving average
                        alpha = 0.1
                        self._stats['avg_response_time'] = (
                            alpha * elapsed + 
                            (1 - alpha) * self._stats['avg_response_time']
                        )
                    
                    return result
                    
                except FutureTimeoutError:
                    logger.warning(f"[-] Request timed out (attempt {attempt + 1}/{retries})")
                    self._stats['timed_out_requests'] += 1
                    self._audit('prediction_failed', {'error': 'Request timed out', 'text_preview': texts}, client_ip)                

                    if attempt == retries - 1:
                        raise TimeoutError(f"[-] Prediction timed out after {timeout}s")
                        
                except Exception as e:
                    logger.warning(f"[-] Request failed (attempt {attempt + 1}/{retries}): {e}")
                    traceback.print_exc()
                    self._stats['failed_requests'] += 1
                    self._audit('prediction_failed', {'error': str(e), 'text_preview': texts}, client_ip)                
                    if attempt == retries - 1:
                        raise
            
            # Should never reach here
            raise RuntimeError("[-] Unexpected error in retry loop")
        except Exception as e:
            print(f'[-] Error in predict function: {e}')


    def _predict_sync(self, text: Any, timeout: float) -> Any:
        # Internal synchronous prediction.

        if not self._loop or not self._loop.is_running():
            raise RuntimeError("[-] Event loop not available")

    
        future = asyncio.run_coroutine_threadsafe(
            self._predict_with_timeout(text, timeout),
            self._loop
        )
        
        # Track task for cleanup
        task_id = self._add_task(future, timeout)
        
        try:
            result = future.result(timeout=timeout + 1)
            return result
        finally:
            self._remove_task(task_id)

    def _advanced_predict_sync(self, test_titles, label_map, rules, X=None, y=None, agent_id: str=None, use_transformer: bool=False, timeout: float = 30.0) -> Any:
        # Internal synchronous prediction.

        if not self._loop or not self._loop.is_running():
            raise RuntimeError("[-] Event loop not available")

    
        future = asyncio.run_coroutine_threadsafe(
            self.advanced_predict_async_await(test_titles, label_map, rules, X=X, y=y, use_transformer=use_transformer, agent_id=agent_id, timeout=timeout),
            self._loop
        )
        
        # Track task for cleanup
        task_id = self._add_task(future, timeout)
        
        try:
            result = future.result(timeout=timeout + 1)
            return result
        finally:
            self._remove_task(task_id)

    
    async def _predict_with_timeout(self, text: Any, timeout: float) -> Any:
        # Async prediction with timeout.
        try:
            return await asyncio.wait_for(
                self.pipeline.predict_async_await(text),
                timeout=timeout
            )
        except asyncio.TimeoutError:
            raise FutureTimeoutError(f"[-] Prediction timed out after {timeout}s")
    
    async def advanced_predict_async_await(self, test_titles: list[tuple], label_map: dict, rules: list[tuple], X: np.ndarray=None, y: np.ndarray=None, use_transformer: bool=False, agent_id: str=None, timeout: float = 30.0):
        # Async advanced prediction with await support. 
        try:
            return await asyncio.wait_for(
                self.pipeline.distribution.request_advanced_prediction_async(
                    self.prediction_manager,
                    use_transformer=use_transformer,
                    agent_id=agent_id,
                    test_titles=test_titles,
                    label_map=label_map,
                    rules=rules,
                    X=X, y=y,
                    timeout=timeout
                ),
                timeout=timeout+5
            )

        except asyncio.TimeoutError:
            raise FutureTimeoutError(f"[-] Advanced prediction timed out after {timeout}s")
        except Exception as e:
            print(f'[!] Error in asynchronous advanced prediction: {e}')

    # ============ ADMIN FUNCTIONS (with authentication) ============
    
    def _initialize_bootstrap_security(self):
        # Initialize bootstrap security on first startup
        if self.config.require_bootstrap_auth:
            # Check if bootstrap token exists
            if os.path.exists(self._bootstrap_token_file):
                with open(self._bootstrap_token_file, 'r') as f:
                    self._bootstrap_token_hash = f.read().strip()
            else:
                # Generate first-time bootstrap token
                new_token = secrets.token_urlsafe(32)
                token_hash = hashlib.sha256(new_token.encode()).hexdigest()
                
                with open(self._bootstrap_token_file, 'w') as f:
                    f.write(token_hash)
                
                print("\n" + "="*60)
                print("🔐 FIRST TIME BOOTSTRAP TOKEN GENERATED")
                print("="*60)
                print(f"[=] TOKEN: {new_token}")
                print("\n⚠️  SAVE THIS TOKEN SECURELY - YOU WILL NEED IT TO START THE SERVICE")
                print("="*60 + "\n")
                
                self._bootstrap_token_hash = token_hash
    
    def _validate_bootstrap_token(self, provided_token: str) -> bool:
        # Validate the bootstrap token for service startup
        if not self.config.require_bootstrap_auth:
            return True
        
        if not provided_token:
            logger.error("[=] Bootstrap token required but not provided")
            return False
        
        if not self._bootstrap_token_hash:
            logger.error("[=] No bootstrap token configured")
            return False
        
        provided_hash = hashlib.sha256(provided_token.encode()).hexdigest()
        
        # Use constant-time comparison to prevent timing attacks
        return secrets.compare_digest(provided_hash, self._bootstrap_token_hash)
        
    def regenerate_bootstrap_token(self, current_token: str, admin_token: str = None) -> str:
        # Regenerate bootstrap token (requires current token or admin)
        
        # Allow either current bootstrap token OR admin token
        if not (self._validate_bootstrap_token(current_token) or 
                self._verify_admin(admin_token)):
            raise SecurityError("Valid bootstrap token or admin token required")
        
        new_token = secrets.token_urlsafe(32)
        new_hash = hashlib.sha256(new_token.encode()).hexdigest()
        
        # Save new token
        with open(self._bootstrap_token_file, 'w') as f:
            f.write(new_hash)
        
        self._bootstrap_token_hash = new_hash
        
        self._audit('bootstrap_token_regenerated', {
            'by_admin': bool(admin_token),
            'by_bootstrap': bool(current_token)
        })

        return new_token



    def generate_api_key(self, metadata: dict = None, admin_token: str = None) -> str:
        # Generate a new API key - requires admin token
        if not self._verify_admin(admin_token, AdminRole.ADMIN):
            self._audit('unauthorized_admin_access', {'action': 'generate_api_key'}, 'admin')
            raise SecurityError("Admin authentication required")
        
        api_key = self.api_key_manager.generate_key(metadata)
        self._audit('api_key_generated', {'metadata': metadata}, 'admin')
        self._save_state()
        return api_key
    
    def revoke_api_key(self, api_key: str, admin_token: str = None) -> bool:
        # Revoke an API key - requires admin token
        if not self._verify_admin(admin_token, AdminRole.ADMIN):
            self._audit('unauthorized_admin_access', {'action': 'revoke_api_key'}, 'admin')
            raise SecurityError("Admin authentication required")
        
        result = self.api_key_manager.revoke_key(api_key)
        if result:
            self._audit('api_key_revoked', {}, 'admin')
            self._save_state()
        return result
    
    def add_allowed_ip(self, ip: str, admin_token: str = None):
        # Add IP to whitelist - supports CIDR (requires operator+)
        if not self._verify_admin(admin_token, AdminRole.OPERATOR):
            self._audit('unauthorized_admin_access', {'action': 'add_allowed_ip'}, 'admin')
            raise SecurityError("Operator authentication required")
        
        # Validate CIDR or IP format
        try:
            if '/' in ip:
                ipaddress.ip_network(ip, strict=False)
            else:
                ipaddress.ip_address(ip)
        except ValueError:
            raise SecurityError(f"Invalid IP or CIDR format: {ip}")
        
        if ip not in self.config.allowed_ips:
            self.config.allowed_ips.append(ip)
            self._audit('ip_whitelisted', {'ip': ip}, 'admin')
            self._save_state()
    
    def remove_allowed_ip(self, ip: str, admin_token: str = None):
        # Remove IP from whitelist - requires admin
        if not self._verify_admin(admin_token, AdminRole.ADMIN):
            raise SecurityError("Admin authentication required")
        
        if ip in self.config.allowed_ips:
            self.config.allowed_ips.remove(ip)
            self._audit('ip_removed_from_whitelist', {'ip': ip}, 'admin')
            self._save_state()
    
    def block_ip(self, ip: str, admin_token: str = None):
        # Block an IP address - requires operator+
        if not self._verify_admin(admin_token, AdminRole.OPERATOR):
            raise SecurityError("Operator authentication required")
        
        # Validate IP format
        try:
            ipaddress.ip_address(ip)
        except ValueError:
            raise SecurityError(f"Invalid IP format: {ip}")
        
        if ip not in self.config.blocklisted_ips:
            self.config.blocklisted_ips.append(ip)
            self._audit('ip_blocked', {'ip': ip}, 'admin')
            self._save_state()
    
    def unblock_ip(self, ip: str, admin_token: str = None):
        # Unblock an IP address - requires admin
        if not self._verify_admin(admin_token, AdminRole.ADMIN):
            raise SecurityError("Admin authentication required")
        
        if ip in self.config.blocklisted_ips:
            self.config.blocklisted_ips.remove(ip)
            self._audit('ip_unblocked', {'ip': ip}, 'admin')
            self._save_state()
    
    def get_audit_log(self, limit: int = 100, admin_token: str = None) -> List[Dict]:
        # Get recent audit log entries - requires auditor+
        if not self._verify_admin(admin_token, AdminRole.AUDITOR):
            raise SecurityError("Auditor authentication required")
        
        return self._audit_log[-limit:]
    
    def list_api_keys(self, admin_token: str = None) -> List[Dict]:
        # List all API keys (without revealing full keys) - requires admin
        if not self._verify_admin(admin_token, AdminRole.ADMIN):
            raise SecurityError("Admin authentication required")
        
        return [
            {
                'key_hash': k[:8] + '...',  # Partial hash only
                'created_at': v['created_at'].isoformat(),
                'last_used': v.get('last_used', '').isoformat() if v.get('last_used') else None,
                'metadata': v.get('metadata', {}),
                'is_active': v.get('is_active', True)
            }
            for k, v in self.api_key_manager.keys.items()
        ]
    
    def create_admin_token(self, role: AdminRole = AdminRole.OPERATOR, admin_token: str = None) -> str:
        # Create a new admin token - requires existing admin token
        if not self._verify_admin(admin_token, AdminRole.ADMIN):
            raise SecurityError("Admin authentication required")
        
        new_token = secrets.token_urlsafe(32)
        token_hash = hashlib.sha256(new_token.encode()).hexdigest()
        
        self.admin_keys[token_hash] = {
            'role': role,
            'created_at': datetime.now(),
            'created_by': hashlib.sha256(admin_token.encode()).hexdigest()[:8]
        }
        
        self._audit('admin_token_created', {'role': role.value}, 'admin')
        self._save_state()
        
        return new_token
    
    def revoke_admin_token(self, token_to_revoke: str, admin_token: str = None):
        # Revoke an admin token - requires admin
        if not self._verify_admin(admin_token, AdminRole.ADMIN):
            raise SecurityError("Admin authentication required")
        
        token_hash = hashlib.sha256(token_to_revoke.encode()).hexdigest()
        if token_hash in self.admin_keys:
            del self.admin_keys[token_hash]
            self._audit('admin_token_revoked', {}, 'admin')
            self._save_state()


    def advanced_batch_prediction(self, test_titles, label_map, rules, X=None, y=None, api_key=None, client_ip=None):
        try:
            reverse_label_map = {v: k for k, v in label_map.items()}

            # Batch predictions
            texts = [text[0] for text in test_titles]
            expected_labels = [text[1] for text in test_titles]  # Your ground truth
            predicted_output = []

            text = {"test_titles": test_titles, "label_map": label_map, "rules": rules, "X":X, "y":y, "use_transformer": True}

            if not self.pipeline.intents:
                advanced_result = self.predict(
                text, 
                timeout=self.timeout,
                retries=None,
                api_key=api_key,
                client_ip=client_ip,
                ) # regular predict to populate pipelines data
            else:
                advanced_result = self.advanced_prediction_method(self.prediction_manager
                , test_titles, label_map, rules, method='Transformer_included')

            print(f'[=+=] Local advanced Prediction result: {advanced_result}')

            print('[=] Initiating Batch prediction for multiple texts...')
            results = self.predict_batch(
                texts=texts,
                timeout=60,
                api_key=api_key)

            print("📊 PREDICTION RESULTS")
           
            for text, expected, probs in zip(texts, expected_labels, results):
                # probs is an array of 8 probability values
                predicted_index = np.argmax(probs)  # Get index with highest probability
                predicted_label = reverse_label_map.get(predicted_index, f"class_{predicted_index}")
                confidence = probs[predicted_index]
                
                # Get top 3 predictions for more insight
                top_3_indices = np.argsort(probs)[-3:][::-1]
                top_3 = [(reverse_label_map.get(idx, f"class_{idx}"), probs[idx]) for idx in top_3_indices]
                
                print(f"\n📌 Input: '{text}'")
                print(f"   [=] Expected: {expected}")
                print(f"   🎯 Predicted: {predicted_label} ({confidence:.1%})")
                
                # Show top 3 possibilities
                print(f"   🔍 Top possibilities:")
                for label, conf in top_3:
                    bar = '█' * int(conf * 20)
                    print(f"[•]   {label:<25} {bar} {conf:.1%}")
                
                # Match expected vs predicted
                print('===== COMPARISON MATCHING =====')
                if predicted_label == expected:
                    print(f"[✅] CORRECT LABEL!")
                else:
                    print(f"[❌] INCORRECT LABEL (expected: {expected})")

                predicted_output.append(predicted_label)

            # Get stats
            print(f"[=] Stats: {self.get_stats()}")        
            return predicted_output 

        except Exception as e:
            print(f'[=] Error in advanced batch prediction: {e}')
            return []
            
    
    def predict_batch(self, texts: List[str], timeout: float = None, api_key: Any=None) -> List[Dict[str, Any]]:
        """
        Synchronous batch prediction.
        
        Args:
            texts: List of input texts
            timeout: Timeout per request
            
        Returns:
            List of prediction results
        """
        if not self.is_running:
            if not self.start():
                raise RuntimeError("[-] Wrapper not running and failed to start")
        
        results = []
        for text in texts:
            result = self.predict(text, timeout, None, api_key)
            results.append(result)
        return results

    def advanced_prediction_method(self, manager, test_titles, label_map, rules, X=None, y=None, method='Transformer_included'):
        # starting PredictionManager for advanced prediction
        try:
            if method == 'Transformer_included':
                print('== PREDICTION 1: (advanced predictions with expected labels transformer included)')
                result, chosen_label, confidence = manager.advanced_prediction_method(
                test_titles,  # Titles with expected labels
                label_map,
                rules,
                X=X, y=y,
                show_proba=True,
                top_k=4,
                use_transformer=self.pipeline.use_transformer,
                return_attention=False,
            
                )   
            else:
                print('== PREDICTION 2: (titles only without transformer) ==')
                result, chosen_label, confidence = manager.advanced_prediction_method(
                [t[0] for t in test_titles],  # Just titles
                label_map,
                rules,
                show_proba=True
                )
        except Exception as e:
            logger.error(f"[-] Advanced prediction failed: {e}")
            result = None
            confidence = 0.0
            chosen_label = None

        return result, chosen_label, confidence


    def predict_async(self, text: Any, test_titles: list[tuple]= None, label_map: dict=None, rules: list[tuple]=None, callback: Optional[Callable] = None) -> str:
        """
        Asynchronous prediction (fire and forget).
        
        Args:
            text: Input text to predict
            callback: Optional callback for result
            
        Returns:
            Request ID for tracking
        """
        if not self.is_running:
            self.start()
        
        with self._task_lock:
            request_id = f"[=] req_{self._task_counter}"
            self._task_counter += 1
        
        # Queue the request (non-blocking)
        try:
            print('[===] request Queued... ')
            self._request_queue.put_nowait({
                'id': request_id,
                'text': text,
                'test_titles': test_titles,
                'label_map': label_map,
                'rules': rules,
                'callback': callback
            })
        except queue.Full:
            logger.warning(f"[=] Request queue full, rejecting request {request_id}")
            if callback:
                callback({'error': 'queue_full', 'success': False})
            return request_id
        
        return request_id
    
    def _submit_request(self, request: Dict, method=None):
        # Submit a request from the queue to the event loop.
        if not self._loop or not self._loop.is_running():
            logger.error("[-] Cannot submit request: event loop not available")
            if request.get('callback'):
                request['callback']({'error': 'event_loop_unavailable', 'success': False})
            return

        if method != 'advanced':
            future = asyncio.run_coroutine_threadsafe(
                self._predict_with_timeout(request['text'], self.default_timeout),
                self._loop
            )
        else:
            future = asyncio.run_coroutine_threadsafe(
                self.advanced_predict_async_await(
                    test_titles=request['test_titles'],
                    label_map=request['label_map'],
                    rules=request['rules'],
                    timeout=self.default_timeout
                ),
                self._loop
            )
        
        task_id = self._add_task(future, self.default_timeout)
        
        def on_completion(fut):
            self._remove_task(task_id)
            try:
                result = fut.result()
                if request.get('callback'):
                    request['callback'](result)
            except Exception as e:
                logger.error(f"[-] Async request failed: {e}")
                if request.get('callback'):
                    request['callback']({'error': str(e), 'success': False})
        
        future.add_done_callback(on_completion)
    
    def _add_task(self, future: asyncio.Future, timeout: float) -> str:
        # Track a pending task.
        with self._task_lock:
            task_id = f"[=] task_{self._task_counter}"
            self._task_counter += 1
            self._pending_tasks[task_id] = AsyncTask(
                id=task_id,
                future=future,
                created_at=time.time(),
                timeout=timeout
            )
        return task_id
    
    def _remove_task(self, task_id: str):
        # Remove a completed task.
        with self._task_lock:
            self._pending_tasks.pop(task_id, None)
    
    def get_stats(self) -> Any:
        # Get wrapper statistics.
        with self._lock:
            stats = self._stats.copy()
            stats['state'] = self.state
            stats['pending_tasks'] = len(self._pending_tasks)
            stats['queue_size'] = self._request_queue.qsize()
            stats['loop_running'] = self._loop and self._loop.is_running()
            stats['uptime'] = time.time() - self._last_heartbeat if self._last_heartbeat else 0
        return stats
    
    def wait_for_idle(self, timeout: float = 30.0) -> bool:
        """
        Wait for all pending tasks to complete.
        
        Args:
            timeout: Maximum time to wait
            
        Returns:
            True if idle, False if timeout
        """
        start_time = time.time()
        while (self._pending_tasks or self._request_queue.qsize() > 0) and \
              (time.time() - start_time) < timeout:
            time.sleep(0.1)
        
        return len(self._pending_tasks) == 0 and self._request_queue.qsize() == 0
    
    def stop(self, timeout: float = 10.0, force: bool = False) -> bool:
        '''
        Gracefully stop the wrapper.
        
        Args:
            timeout: Maximum time to wait for pending tasks
            force: Force stop even if tasks pending
            
        Returns:
            True if stopped successfully
        '''

        with self._lock:
            if self._state in (WrapperState.STOPPING, WrapperState.STOPPED):
                return True
            
            self._state = WrapperState.STOPPING
        
        logger.info("[-] Stopping PipelineAsyncManager...")
        
        # Wait for pending tasks if not forcing
        if not force:
            self.wait_for_idle(timeout)
        
        # Stop event loop
        if self._loop and self._loop.is_running():
            # Cancel all pending tasks
            for task in self._pending_tasks.values():
                task.future.cancel()
            
            # Stop the loop
            self._loop.call_soon_threadsafe(self._loop.stop)
        
        # Wait for thread to finish
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=timeout)
        
        # Wait for queue worker
        if self._queue_worker and self._queue_worker.is_alive():
            self._queue_worker.join(timeout=timeout)
        
        # Wait for health monitor
        if self._health_thread and self._health_thread.is_alive():
            self._health_thread.join(timeout=timeout)
        
        with self._lock:
            self._state = WrapperState.STOPPED
            self._loop = None
            self._thread = None
            self._queue_worker = None
            self._health_thread = None

        print('[=] PipelineAsync Wrapper stopped')        
        logger.info("[-] PipelineAsyncWrapper stopped")
        return True
    
    def __enter__(self):
        # Context manager entry.
        self.start()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        # Context manager exit.
        self.stop()
    
    def __del__(self):
        # Destructor for cleanup.
        try:
        # Only attempt cleanup if we have the attribute
            if hasattr(self, '_state'):
                if self._state not in (WrapperState.STOPPED, WrapperState.UNINITIALIZED):
                    # Use force=True since we're in destructor
                    self.stop(force=True)
        except AttributeError:
            # Object is already partially destroyed - nothing to clean
            pass
        except Exception as e:
            logger.debug(f"[=] Cleanup error in __del__: {e}")



class PipelinePredictionManager:
    '''
    High-level prediction and evaluation helper that sits on top of
    IntegratedPipeline.

    Responsibilities
    ----------------
    1. Dataset loading     : load_labels_from_csv() reads a delimited file,
                             builds a string→integer label_map, and returns
                             (titles, y_numeric, label_map).

    2. Regular prediction  : regular_prediction_method() runs MLP + optional
                             Transformer in parallel, validates output indices,
                             and prints a ranked probability display.

    3. Advanced prediction : advanced_prediction_method() adds:
                             - Hybrid probability fusion (MLP + Transformer)
                             - AAT-based arbitration on disagreement
                             - Optional top-k output with attention weights
                             - Optional result saving to ModelStorage

    4. Robust prediction   : robust_prediction_method() (internal) handles
                             edge cases (batch padding, fallback confidences,
                             "best" result selection) for production use.

    The manager does NOT own the model weights — it delegates all forward
    passes to self.pipeline.

    Parameters
    ----------
    pipeline     : IntegratedPipeline instance (must be trained before
                   calling prediction methods).
    label_csv    : Path to training CSV (loaded at construction time).
    target_title : Column name for text inputs in the CSV.
    label        : Column name for class labels in the CSV.
    '''
    def __init__(self, pipeline, label_csv='labels.csv', target_title='title', label='label'):
        self.pipeline = pipeline
        try:
            print("📖 Loading labels from text file...")
            self.titles, self.y_raw, self.label_map = self.load_labels_from_csv(label_csv, target_title, label)
        except Exception as e:
            print(f"Error loading labels: {e}")
            self.titles, self.y_raw, self.label_map = [], [], {}

        print(f"✅ Loaded {len(self.titles)} labeled examples")

    def load_labels_from_csv(self, filename, target_title, label):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        filepath = os.path.join(script_dir, filename)
        
        if not os.path.exists(filepath):
            print(f"❌ File not found: {filepath}")
            return [], [], {}
        
        # Read CSV file
        df = pd.read_csv(filepath)
        
        print(f"✅ Loaded CSV with columns: {list(df.columns)}")
        
        # Extract titles and labels
        titles = df[target_title].tolist()
        string_labels = df[label].tolist()
        
        # Remove quotes if they're still there
        titles = [t.strip('"') for t in titles]
        
        print(f"📊 Found {len(titles)} examples")
        print(f"📊 Labels: {set(string_labels)}")
        
        # Create numeric labels
        unique_labels = sorted(set(string_labels))
        label_map = {label: i for i, label in enumerate(unique_labels)}
        y = [label_map[label] for label in string_labels]
        
        return titles, y, label_map


    def regular_prediction_method(self, titles, label_map, rules, X=None, y=None, show_proba=False, top_k=3, batch_size=2,use_transformer=True):
        try:
            print(f"\n[🚀] Regular Prediction for labels with {len(titles)} titles...")
            self.pipeline.titles = titles
            self.pipeline.labels = label_map

            reverse_map = {v: k for k, v in label_map.items()}
            num_classes = len(label_map)

            if X is None and y is None or X is None or y is None:
                print('[🔄] Creating automatic X samples because X is not provided manually.')
                dataset, X = self.pipeline.data_preparation(titles, label_map)  
                _, y, _, _ = self.pipeline.mlp_training_features(rules, dataset)                  
            else:
                dataset, _ = self.pipeline.data_preparation(titles, label_map)

            self.pipeline.transformer_utilities(rules, dataset, X, batch_size=batch_size) 
            input_ids, _ = self.pipeline.input_encoding(dataset)


            if use_transformer and hasattr(self.pipeline, 'vocab') and self.pipeline.vocab:
                print("[🔄] Using Transformer for probability calibration")
            
                # Encode titles for transformer
                input_ids_list = []
                for title in titles:
                    # Handle both string and tuple inputs
                    if isinstance(title, tuple):
                        title = title[0]
                    # Encode to token IDs using pipeline's vocabulary
                ids = self.pipeline.encode(title, self.pipeline.vocab)
                input_ids_list.append(np.array(ids))
            
                input_ids = np.array(input_ids_list)
            
            # Get transformer probabilities
                trans_probs, attn_weights = self.pipeline.model2.forward(input_ids)
            else:
                print("⚡ Using MLP only for predictions")
                trans_probs = None
        
            if not hasattr(self.pipeline, 'tfidf') or self.pipeline.tfidf is None:
                self.pipeline.initialize_fitting(titles)
            
            # Prepare texts for MLP
            if isinstance(titles[0], tuple):
                mlp_titles = [t[0] for t in titles]
            else:
                mlp_titles = titles
                
            X_tfidf = self.pipeline.tfidf.transform(mlp_titles).toarray()            
            # Forward pass through MLP
            if hasattr(self.pipeline.mlp, 'predict_proba'):
                mlp_probs = self.pipeline.mlp.predict_proba(X_tfidf)
            else:
                # Fallback if predict_proba not available
                logits = self.pipeline.mlp.forward(X_tfidf)
                mlp_probs = self.pipeline._softmax(logits)
                
            # Validate all MLP predictions at once
            mlp_pred_indices = np.argmax(mlp_probs, axis=1)
            if num_classes <= 0:
                num_classes = mlp_probs.shape[1] if mlp_probs.ndim > 1 else len(mlp_probs)

            valid_mask = mlp_pred_indices < num_classes
            if not np.all(valid_mask):
                invalid_count = np.sum(~valid_mask)
                # Replace invalid indices with argmax within valid range
                for i in range(len(mlp_pred_indices)):
                    valid_probs = mlp_probs[i][:num_classes] if num_classes > 0 else mlp_probs[i]
                    if len(valid_probs) > 0:
                        mlp_pred_indices[i] = int(np.argmax(valid_probs))
                    else:
                        mlp_pred_indices[i] = 0  # Default to first class   
                             
            results = []
            for i, title in enumerate(titles):
                # Handle tuple inputs
                if isinstance(title, tuple):
                    display_title = title[0]
                    expected_label = title[1] if len(title) > 1 else None
                else:
                    display_title = title
                    expected_label = None
                
                # MLP prediction
                mlp_class_idx = mlp_pred_indices[i]
                mlp_class_idx = min(mlp_class_idx, num_classes - 1)  # Clamped to valid range
                   
                mlp_confidence = mlp_probs[i][mlp_class_idx]
                mlp_label = reverse_map.get(mlp_class_idx, f"unknown_{mlp_class_idx}")
                anisotropy = self.pipeline.anisotropy_measurement(input_ids)
                anisotropic_rate = 1.0 / (1.0 + np.exp(-anisotropy)) if anisotropy is not None else 1.0

                # Transformer prediction (if available)
                if trans_probs is not None:
                    if trans_probs.shape[0] > i:
                        trans_probs_i = trans_probs[i]
                    else:
                        trans_probs_i = trans_probs[-1]  # fallback to last if mismatch
                    
                    trans_class_idx = np.argmax(trans_probs_i)
                    trans_confidence = trans_probs_i[trans_class_idx]
                    trans_label = reverse_map.get(trans_class_idx, f"unknown_{trans_class_idx}")
                    
                    # Calibrated probabilities (blend of MLP and Transformer)
                    if use_transformer:
                        # Boost MLP's prediction in transformer probabilities
                        calibrated = trans_probs_i.copy()
                        try:
                            calibrated[mlp_class_idx] = max(calibrated[mlp_class_idx], anisotropic_rate)
                            calibrated /= calibrated.sum()
                        except Exception as e:
                            calibrated = self.pipeline._calibrate_probs(mlp_probs, mlp_pred_indices, attn_weights, input_ids)
        
                        final_probs = calibrated
                        final_class_idx = mlp_class_idx  # Trust MLP's class decision
                        try:
                            final_confidence = final_probs[final_class_idx]
                        except IndexError:
                            final_confidence = np.max(final_probs) if isinstance(final_probs, np.ndarray) else final_probs

                        if isinstance(final_confidence, np.ndarray):
                            final_confidence = np.max(final_confidence)
                                          
                    else:
                        final_probs = mlp_probs[i]
                        final_class_idx = mlp_class_idx
                        final_confidence = mlp_confidence
                else:
                    final_probs = mlp_probs[i]
                    final_class_idx = mlp_class_idx
                    final_confidence = mlp_confidence
                    trans_label = reverse_map.get(mlp_class_idx, f"unknown_{mlp_class_idx}")
                    trans_confidence = mlp_confidence
                
                final_label = reverse_map.get(final_class_idx, f"unknown_{final_class_idx}")
                
                result = {
                    'title': display_title,
                    'expected': expected_label,
                    'predicted': final_label,
                    'confidence': final_confidence,
                    'index': final_class_idx,
                    'mlp_prediction': mlp_label,
                    'mlp_confidence': mlp_confidence,
                }
                
                if trans_label is not None:
                    result['transformer_prediction'] = trans_label
                    result['transformer_confidence'] = trans_confidence

                agreement = trans_label  == mlp_label
                
                
                # Include top-k predictions if requested
                if show_proba:
                    top_indices = np.argsort(final_probs)[-top_k:][::-1]
                    top_predictions = []
                    for idx in top_indices:
                        if idx in reverse_map:
                            top_predictions.append({
                                'label': reverse_map[idx],
                                'confidence': final_probs[idx]
                            })
                        else:
                            top_predictions.append({
                                'label': f"unknown_{idx}",
                                'confidence': final_probs[idx]
                            })
                    result['top_predictions'] = top_predictions
                    
                    mlp_top_indices = np.argsort(mlp_probs[i])[-top_k:][::-1]
                    mlp_top = []
                    for idx in mlp_top_indices:
                        if idx in reverse_map:
                            mlp_top.append({
                                'label': reverse_map[idx],
                                'confidence': mlp_probs[i][idx]
                            })
                    result['mlp_top_predictions'] = mlp_top
                    
                    if trans_probs is not None:
                        trans_top_indices = np.argsort(trans_probs[i])[-top_k:][::-1]
                        trans_top = []
                        for idx in trans_top_indices:
                            if idx in reverse_map:
                                trans_top.append({
                                    'label': reverse_map[idx],
                                    'confidence': trans_probs[i][idx]
                                })
                        result['transformer_top_predictions'] = trans_top
                
                results.append(result)
            
            # Display results
            print("\n" + "="*70)
            print("🎯 HYBRID PREDICTION RESULTS (MLP + Transformer)")
            print("="*70)
            
            correct_count = 0
            for result in results:
                print(f"\n📌 '{result['title']}'")
                
                if result.get('expected'):
                    status = "✓" if result['predicted'] == result['expected'] else "✗"
                    print(f"   Expected: {result['expected']} {status}")
                
                print(f"   🎯 FINAL PREDICTION: {result['predicted']} ({result['confidence']:.1%})")
                print(f"   ⚡ MLP: {result['mlp_prediction']} ({result['mlp_confidence']:.1%})")
                
                if result.get('transformer_prediction'):
                    arrow = "⬆️" if result['transformer_confidence'] > result['mlp_confidence'] else "⬇️"
                    print(f"   🌀 Transformer: {result['transformer_prediction']} ({result['transformer_confidence']:.1%}) {arrow}")
                
                if show_proba and 'top_predictions' in result:
                    print("\n   🔍 Top possibilities (calibrated):")
                    for j, pred in enumerate(result['top_predictions'][:top_k], 1):
                        bar = '█' * int(pred['confidence'] * 20)
                        print(f"      {j}. {pred['label']:20s} {bar} {pred['confidence']:.1%}")
                
                if result.get('expected') and result['predicted'] == result['expected']:
                    correct_count += 1
            
            if results and results[0].get('expected'):
                accuracy = correct_count / len(results)
                print(f"\n📊 Accuracy: {correct_count}/{len(results)} = {accuracy:.1%}")

            try:
                joblib.dump(self.pipeline, 'modular_agent.pkl')
                print('💾  Model saved!')
            except Exception as e:
                print(f'|| Failed to joblib dump file! : {e}, User Manual filepath suggestion needed...')

                permission = input('|| Insert Filepath? [Y/N]: ')
                if permission == 'Y':
                    suggested_path = input('|| Filepath suggestion: ')
                    if suggested_path:
                        self.pipeline.safe_pickle_save_with_feedback(self.pipeline, suggested_path)
                        print('💾  Model saved!')                
                    else:
                        print('|| Failed to dump Your model! ')
                        pass
                else:
                    print('|| Failed to dump Your model! ')
                    pass  

            verbose = False
            if float(results[0]['confidence']) < self.pipeline.confidence_threshold:
                verbose = True
            
            self.display_hybrid_results(results, top_k, verbose=verbose)


            # Use results directly - they already contain calibrated predictions
            chosen_label = results[0]['predicted'] if results else None
            confidence = results[0]['confidence'] if results else None

            if isinstance(chosen_label, int) or isinstance(chosen_label, np.integer):
                chosen_label = str(chosen_label)
                
            # Only recalibrate if models disagreed AND we have valid results
            if results and not results[0].get('models_agree', True):
                print("\n[⚠️] Disagreement detected between MLP and Transformer predictions. Using calibrated probabilities for final decision.")
                calibrated_probs = self.pipeline.hybrid_prediction(input_ids, X, batch_size=batch_size)
                
                if calibrated_probs is not None and len(calibrated_probs) > 0:
                    final_idx = int(np.argmax(calibrated_probs[:num_classes]))
                    if final_idx > len(reverse_map):
                        final_idx = int(np.argmax(calibrated_probs[:len(reverse_map)-1]))
                        print(f"[⚠️] Clamping {final_idx} → {final_idx}") 

                    final_idx = int(min(final_idx, num_classes - 1))  # Ensure index is within valid range
                    chosen_label = reverse_map.get(final_idx, f"unknown_{final_idx}")
                    try:
                        confidence = float(calibrated_probs[0][final_idx])   
                    except:
                        confidence = float(calibrated_probs[0][len(reverse_map)-1]) if isinstance(calibrated_probs[0], (float, int)) else 0.0             
                            
            if isinstance(chosen_label, str) and chosen_label.startswith("unknown") or float(confidence) < self.pipeline.confidence_threshold:
                print(f"\n[⚠️] Final prediction is {chosen_label} with uncertain confidence: {confidence:.1%}. Consider collecting more data or adjusting the model.")
            else:
                print(f"\n[🎯] Final chosen label for input: {chosen_label} || Confidence: {confidence:.1%}")  

            if results and results[0]['confidence'] > self.pipeline.confidence_threshold:
                results[0]['predicted'] = chosen_label
                results[0]['confidence'] = confidence

        except Exception as e:
            print(f"[=] Error during prediction: {e}")
            results = []

        return results

    def hybrid_model_prediction(self, datasets, X_raw, batch_size=2):
        self.pipeline.transformer_utilities(datasets, X_raw, batch_size=batch_size)
        input_datasets = self.pipeline.transformer_input_encoding([i[0] for i in datasets])

        probs = self.model.predict_proba(input_datasets, X_raw, type='Hybrid')[0]
        pred = self.model.hybrid_prediction(input_datasets, X_raw)

        return probs, pred

    def robust_prediction(self, pipeline, titles, label_map, X_raw=None, y=None, show_proba=True, top_k=3, batch_size=2):
        self.pipeline.titles = titles
        self.pipeline.labels = label_map   

        try:

            if X_raw is None and y is None or X_raw is None or y is None:
                print('[🔄] Creating automatic X samples because X is not provided manually.')
                datasets, X_raw = self.pipeline.data_preparation(titles, label_map)  
            else:
                datasets, _ = self.pipeline.data_preparation(titles, label_map)

            reverse_map = {v: k for k, v in label_map.items()}
            
            self.pipeline.transformer_utilities(datasets, X_raw, y_true=y, batch_size=batch_size)
            input_datasets = self.pipeline.transformer_input_encoding(datasets)
            pred_probs = self.pipeline.predict_proba(input_datasets, X_raw, type='Hybrid')[0]
            pred_result = self.pipeline.hybrid_prediction(input_datasets, X_raw, batch_size=batch_size)

            print("\n[🔍] Prediction result structure:")
            print(f"[=] Type: {type(pred_result)}")
            print(f"[=] Length: {len(pred_result) if isinstance(pred_result, tuple) else 1}")

            if isinstance(pred_result, tuple):
                if len(pred_result) == 3:
                    pred_indices = pred_result[0]
                    hybrid_probs = pred_result[1]  # Use different variable name
                    attn_weights = pred_result[2]
                    print("✅ Extracted: indices, probs, attention")
                elif len(pred_result) == 2:
                    pred_indices = pred_result[0]
                    hybrid_probs = pred_result[1]  # Use different variable name
                    print("✅ Extracted: indices, probs")
                else:
                    print(f"⚠️ Unknown tuple format with {len(pred_result)} elements")
                    pred_indices = pred_result[0]
                    hybrid_probs = pred_result[1] if len(pred_result) > 1 else None
            else:
                pred_indices = pred_result
                hybrid_probs = None
                print("✅ Single value return")
        
            # Use hybrid_probs if available, otherwise use pred_probs
            final_probs = hybrid_probs if hybrid_probs is not None else pred_probs
        
            if isinstance(pred_indices, (list, tuple)) and len(pred_indices) > 0:
                if isinstance(pred_indices[0], (np.ndarray, list)):

                    pred_indices = np.array([p[0] if isinstance(p, (np.ndarray, list)) else p 
                                        for p in pred_indices])
                else:
                    pred_indices = np.array(pred_indices)
            elif isinstance(pred_indices, np.ndarray):
                if pred_indices.ndim > 1:
                    pred_indices = pred_indices.flatten()
            else:
                pred_indices = np.array([pred_indices])
        
            print(f"\n[📊] Processed predictions:")
            print(f"[=] pred_indices shape: {pred_indices.shape}")
            print(f"[=] pred_indices: {pred_indices}")
        
            if final_probs is not None:
                print(f"[=] final_probs shape: {final_probs.shape if hasattr(final_probs, 'shape') else 'unknown'}")
        
            if final_probs is not None and isinstance(final_probs, np.ndarray) and final_probs.ndim == 1:
                final_probs = final_probs.reshape(1, -1)
        
            n_samples = len(titles)
            if len(pred_indices) < n_samples:
                print(f"[⚠️] Padding predictions from {len(pred_indices)} to {n_samples}")
                last_idx = pred_indices[-1] if len(pred_indices) > 0 else 0
                pred_indices = np.pad(pred_indices, (0, n_samples - len(pred_indices)), 
                                mode='constant', constant_values=last_idx)

            results = []
            best_idx = -1
            best_confidence = -1
            
            # Determine rows and cols from final_probs
            if final_probs is not None and hasattr(final_probs, 'shape'):
                rows = final_probs.shape[0]
                cols = final_probs.shape[1] if len(final_probs.shape) > 1 else 1
            elif final_probs is not None:
                rows = len(final_probs)
                cols = len(final_probs[0]) if rows > 0 and hasattr(final_probs[0], '__len__') else 1
            else:
                rows, cols = 0, 0
            
            for i in range(n_samples):
                class_idx = int(pred_indices[i]) if i < len(pred_indices) else 0
                    
            if final_probs is not None and i < rows and class_idx < cols:
                if hasattr(final_probs, 'shape'):
                    confidence = final_probs[i, class_idx]
                else:
                    if isinstance(final_probs[i], (list, np.ndarray)):
                        confidence = final_probs[i][class_idx]
                    else:
                        confidence = float(final_probs[i])  # Single value
                        
                if confidence > best_confidence:
                    best_idx = i
                    best_confidence = confidence
                    
            for i, title in enumerate(titles):
                if i < len(pred_indices):
                    class_idx = int(pred_indices[i])
                else:
                    class_idx = 0
                    
                # Get confidence from final_probs
                if final_probs is not None and i < rows and class_idx < cols:
                    if hasattr(final_probs, 'shape'):
                        confidence = final_probs[i, class_idx]
                    else:  # list
                        if isinstance(final_probs[i], (list, np.ndarray)):
                            confidence = final_probs[i][class_idx]
                        else:
                            confidence = float(final_probs[i])  # Single value
                else:
                    # Fallback: use max probability instead of min
                    if final_probs is not None and i < len(final_probs):
                        if isinstance(final_probs[i], (list, np.ndarray)):
                            confidence = max(final_probs[i])
                        else:
                            confidence = float(final_probs[i])
                    else:
                        confidence = 0.0
            
                label = reverse_map.get(class_idx, f"unknown_{class_idx}")

                result = {
                'title': title,
                'predicted': label,
                'confidence': confidence,
                'index': class_idx,
                'is_best': (i == best_idx)
                }
                
                if show_proba and i < rows and cols > 1:
                    if hasattr(final_probs, 'shape'):
                        probs_row = final_probs[i]
                    else:
                        if isinstance(final_probs[i], (list, np.ndarray)):
                            probs_row = np.array(final_probs[i])
                        else:
                            probs_row = np.array([final_probs[i]])
                
                    if len(probs_row) > 1:
                        top_indices = np.argsort(probs_row)[-top_k:][::-1]
                        top_predictions = []
                        for idx in top_indices:
                            if idx in reverse_map:
                                top_predictions.append({
                                'label': reverse_map[idx],
                                'confidence': float(probs_row[idx])
                                })
                        result['top_predictions'] = top_predictions
            
                results.append(result)
        
            print("\n" + "="*70)
            print("[🎯] LABEL PREDICTIONS")
            print("="*70)
        
            for i, result in enumerate(results):
                print(f"\n[📌] Label: {i+1}. '{result['title']}'")
            
                best_marker = "[🏆] BEST" if result.get('is_best') else ""
                print(f"   → {result['predicted']} ({result['confidence']}){best_marker}")
            
                if show_proba and 'top_predictions' in result:
                    print(" [  Top possibilities:")
                    for j, pred in enumerate(result['top_predictions'][:top_k], 1):
                        bar = '█' * int(pred['confidence'] * 20)
                        print(f"      {j}. {pred['label']} {bar} {pred['confidence']} %")
            
            # Return the best result (not inside loop)
            best_idx = int(np.argmax(final_probs[:, pred_indices] if final_probs is not None and hasattr(final_probs, 'shape') else [r['confidence'] for r in results]))
            if best_idx >= 0:
                best_result = results[best_idx]
                if isinstance(best_result['predicted'], str) and best_result['predicted'].startswith("unknown") or best_result['confidence'] < self.pipeline.confidence_threshold:
                    print(f"\n[⚠️] Final prediction is {best_result['predicted']} with uncertain confidence. Consider collecting more data or adjusting the model.")
                else:
                    print(f"\n✨ Most confident: '{best_result['title']}' → {best_result['predicted']} ({best_result['confidence']:.1%})")
                return best_result['predicted'], best_result['confidence'], best_result['confidence']
            elif results:
                # Fallback: return first result if no best found
                predicted = results[0]['predicted']
                predicted_confidence = results[0]['confidence']
                if isinstance(predicted, str) and predicted.startswith("unknown") and predicted_confidence < self.pipeline.confidence_threshold:
                    print(f"\n[⚠️] Final prediction is {predicted} with uncertain confidence: {predicted_confidence:.1%}. Consider more consistent data for the model to learn from.")
                else:
                    print(f"\n[🎯] Final chosen label for input: {predicted} || Confidence: {predicted_confidence:.1%}")  
                
                return predicted, predicted_confidence

        except Exception as e:
            print(f"[=] Error during robust prediction: {e}")
            predicted = None
            predicted_confidence = None
        return predicted, predicted_confidence
        
    def calculate_entropy(self, probs):
        return -np.sum(probs * np.log(probs + 1e-10), axis=-1)


    def advanced_prediction_method(self, titles, label_map, rules,
                                X=None, y=None,
                                show_proba=False, top_k=3, 
                                use_transformer=True, return_attention=False,
                                save_results=True, batch_size=2):
        try:
            eps = 1e-5
            trans_probs = None
            attn_weights = None
            sequence_ids = None

            print("\n[🚀] Starting Advanced Hybrid Prediction Method")

            reverse_map = {v: k for k, v in label_map.items()}
            num_classes = len(label_map)

            self.pipeline.titles = titles
            self.pipeline.labels = label_map

            if X is None and y is None or X is None or y is None:
                print('[🔄] Creating automatic X samples because X is not provided manually.')
                dataset, X = self.pipeline.data_preparation(titles, label_map)  
                _, y, _, _ = self.pipeline.mlp_training_features(rules, dataset)                  
            else:
                dataset, _ = self.pipeline.data_preparation(titles, label_map)

            self.pipeline.transformer_utilities(rules, dataset, X, y_true=y, batch_size=batch_size)
            input_ids, _ = self.pipeline.input_encoding(dataset)
          
            if use_transformer and hasattr(self.pipeline, 'vocab') and self.pipeline.vocab:
                use_embedded = False
                print("\n[🔄] Running dual predictions (MLP + Transformer)")
            
                input_ids_list = []
                for title in titles:
                    if isinstance(title, tuple):
                        title = title[0]
                    ids = self.pipeline.encode(title, self.pipeline.vocab)
                    input_ids_list.append(np.array(ids))
                
                input_ids = np.array(input_ids_list)
                sequence_ids = self.pipeline.sequence_encoding(dataset)
                if X is not None:
                    anisotropy = self.pipeline.anisotropy_measurement(X)
                else:
                    anisotropy = self.pipeline.anisotropy_measurement(sequence_ids)

                # Get transformer predictions with attention
                print(f"[⚡] anisotropy rate detected on input: {anisotropy:.1%}.")                
                use_embedded = True
                trans_probs, attn_weights = self.pipeline.model2.forward(sequence_ids, embedded=use_embedded)

            else:
                print("\n[⚡] Running MLP-only predictions")
                print("[⚡] Note: Transformer not available, so Transformer results will be replaced with MLP results.")

            if X is None or len(X) == 0 or isinstance(X, int) or (isinstance(X, np.ndarray) and X.size == 0):
                # Get MLP predictions
                if isinstance(titles[0], tuple):
                    mlp_titles = [t[0] for t in titles]
                else:
                    mlp_titles = titles
                
                if not hasattr(self.pipeline, 'tfidf') or self.pipeline.tfidf is None:
                    self.pipeline.initialize_fitting(mlp_titles)
                                    
                X = self.pipeline.tfidf.transform(mlp_titles).toarray()

            # MLP forward pass
            if hasattr(self.pipeline.mlp, 'predict_proba'):
                mlp_probs = self.pipeline.mlp.predict_proba(X)
            else:
                logits = self.pipeline.mlp.forward(X)
                mlp_probs = self.pipeline._softmax(logits)
            
             # Validate all MLP predictions at once
            mlp_pred_indices = np.argmax(mlp_probs, axis=1)
            if num_classes <= 0:
                num_classes = mlp_probs.shape[1] if mlp_probs.ndim > 1 else len(mlp_probs[0])

            valid_mask = mlp_pred_indices < num_classes
            if not np.all(valid_mask):
                invalid_count = np.sum(~valid_mask)
                # Replace invalid indices with argmax within valid range
                for i in range(len(mlp_pred_indices)):
                    valid_probs = mlp_probs[i][:num_classes] if num_classes > 0 else mlp_probs[i]
                    if len(valid_probs) > 0:
                        mlp_pred_indices[i] = int(np.argmax(valid_probs))
                    else:
                        mlp_pred_indices[i] = 0  # Default to first class  

            if sequence_ids is not None:
                print("\n[🔍] Using sequence encoding for transformer input due to low anisotropy.")
                input_ids = sequence_ids.copy()

            target_probs = self.pipeline.predict_proba(input_ids, X, type='Hybrid', embedded=True)
            target_probs = target_probs[:mlp_probs.shape[0], :mlp_probs.shape[1]] 
            target_pred_indices = np.argmax(target_probs, axis=1)    

            if self.pipeline.cache and 'label_bins' in self.pipeline.cache:
                print('[=] label_bins cache found!')
                label_bins = self.pipeline.cache['label_bins']
                lstm_probs, _ = self.pipeline.ensemble._get_lstm_probs(input_ids, X, label_bins=label_bins)      
            else:
                lstm_probs = None

            results = []
            attention_data = [] if return_attention else None

            target_probs = self.pipeline.predict_proba(input_ids, X, type='Hybrid', embedded=True)
            target_probs = target_probs[:mlp_probs.shape[0], :mlp_probs.shape[1]] 
            target_pred_indices = np.argmax(target_probs, axis=1)          

            results = []
            attention_data = [] if return_attention else None

            for i, title in enumerate(titles):
                # Parse input
                if isinstance(title, tuple):
                    display_title = title[0]
                    expected_label = title[1] if len(title) > 1 else None
                else:
                    display_title = title
                    expected_label = None
                
                # MLP prediction                 
                mlp_class_idx = mlp_pred_indices[i]
                mlp_class_idx = min(mlp_class_idx, num_classes - 1)  # Clamped to valid range
                if mlp_class_idx < 0 or mlp_class_idx >= num_classes:
                    mlp_class_idx = 0  # Safe default              

                mlp_confidence = mlp_probs[i][mlp_class_idx]
                mlp_label = reverse_map.get(mlp_class_idx, f"unknown_{mlp_class_idx}")

                if lstm_probs is not None:
                    lstm_pred_indices = np.argmax(lstm_probs, axis=1)
                    lstm_class_idx = lstm_pred_indices[i]              
                    lstm_confidence = lstm_probs[i][lstm_class_idx]
                else:
                    lstm_confidence = None

                target_class_idx = target_pred_indices[i]
                target_confidence = target_probs[i][target_class_idx]
            
                # Transformer prediction and blending
                if trans_probs is not None:
                    trans_probs_i = trans_probs[i]
                    trans_class_idx = np.argmax(trans_probs_i)
                    if isinstance(trans_probs_i, float):
                        trans_confidence = target_confidence
                    else:
                        trans_confidence = trans_probs_i[trans_class_idx]

                    trans_label = reverse_map.get(trans_class_idx, f"unknown_{trans_class_idx}")

                    calibration = self.pipeline._calibrate_probs(target_probs, target_pred_indices, attn_weights, input_ids)
                    # Blend predictions (MLP decides class, transformer calibrates confidence)
                    mlp_weight = mlp_confidence / (target_confidence + trans_confidence + eps)
                    trans_weight = trans_confidence / (target_confidence + trans_confidence + eps)
                    if lstm_confidence is not None:
                        lstm_weight = lstm_confidence / (target_confidence + lstm_confidence + eps)
                        
                    calibration_weighting = calibration[target_class_idx] if target_class_idx < len(calibration) else 0.0
                        
                    # Weighted blend: calibration_weighting * calibrated + (1-weight) * mlp
                    if lstm_weight is not None:
                        final_probs = mlp_weight * target_probs[i][:len(calibration)] + trans_weight * calibration[i][:len(calibration)] + lstm_weight * calibration[i][:len(calibration)]
                    else:
                        final_probs = mlp_weight * target_probs[i][:len(calibration)] + trans_weight * calibration[i][:len(calibration)]

                    final_class_idx = target_class_idx
                    try:
                        final_confidence = final_probs[final_class_idx]
                    except IndexError:
                        final_confidence = np.max(final_probs) if isinstance(final_probs, np.ndarray) else final_probs

                    if isinstance(final_confidence, np.ndarray):
                        final_confidence = np.max(final_confidence)

                    # Calculate agreement
                    agreement = mlp_class_idx == trans_class_idx
                else:
                    final_probs = mlp_probs[i]
                    final_class_idx = mlp_class_idx
                    final_confidence = mlp_confidence[0] if isinstance(mlp_confidence, np.ndarray) else mlp_confidence
                    if isinstance(final_confidence, np.ndarray) or isinstance(final_confidence, list):
                        final_confidence = np.max(final_confidence)

                    trans_label = None
                    trans_confidence = None
                    agreement = True
                
                final_label = reverse_map.get(final_class_idx, f"unknown_{final_class_idx}")
                # Build result
                result = {
                    'title': display_title,
                    'expected': expected_label,
                    'predicted': final_label,
                    'confidence': float(final_confidence),
                    'index': int(final_class_idx),
                    'mlp_prediction': mlp_label,
                    'mlp_confidence': float(mlp_confidence),
                    'models_agree': bool(agreement),
                    'sec_predicted': None,
                    'sec_confidence': 0.0,
                    'sec_index': None,
                }
                
                if trans_label is not None:
                    result['transformer_prediction'] = trans_label
                    result['transformer_confidence'] = float(trans_confidence)
                
                # Add top-k predictions
                final_probs = final_probs[:num_classes] if num_classes > 0 else final_probs
                if show_proba:
                    top_indices = np.argsort(final_probs)[-top_k:][::-1]
                    result['top_predictions'] = [
                        {
                            'label': reverse_map.get(idx, f"unknown_{idx}"),
                            'confidence': float(final_probs[idx])
                        }
                        for idx in top_indices if idx in reverse_map
                    ]
                    
                    # MLP top predictions
                    mlp_probs_i = mlp_probs[i][:num_classes] if num_classes > 0 else mlp_probs[i]
                    mlp_top = np.argsort(mlp_probs_i)[-top_k:][::-1]
                    result['mlp_top'] = [
                        {
                            'label': reverse_map.get(idx, f"unknown_{idx}"),
                            'confidence': float(mlp_probs_i[idx])
                        }
                        for idx in mlp_top if idx in reverse_map
                    ]
                    
                    # Transformer top predictions
                    if trans_probs is not None:
                        if trans_probs.ndim > 1:
                            trans_probs = trans_probs[i][:num_classes] if num_classes > 0 else trans_probs[i]
                        else:
                            trans_probs = trans_probs.copy()
                        if trans_probs is not None:
                            trans_top = np.argsort(trans_probs)[-top_k:][::-1]
                            result['transformer_top'] = [
                                {
                                    'label': reverse_map.get(idx, f"unknown_{idx}"),
                                    'confidence': float(trans_probs[idx])
                                }
                                for idx in trans_top if idx in reverse_map
                            ]
                
                results.append(result)
                
                # Collect attention data if requested
                if return_attention and attn_weights is not None:
                    attention_data.append({
                        'title': display_title,
                        'attention': attn_weights[i].tolist() if i < len(attn_weights) else None
                    })
            
            # Display results
            verbose = False
            if float(results[0]['confidence']) < self.pipeline.confidence_threshold:
                verbose = True
            
            chosen_label = results[0]['predicted'] if results else None
            confidence = results[0]['confidence'] if results else None
            if isinstance(chosen_label, int) or isinstance(chosen_label, np.integer):
                chosen_label = str(chosen_label)

            print(f"\n[🎯] Initial chosen label for input: {chosen_label} || Confidence: {confidence:.1%}")
            time.sleep(3)

            if results[0].get('models_agree', True) and confidence > self.pipeline.confidence_threshold and not chosen_label.startswith("unknown"):
                print(f"\n[🎯] Proper Confidence of Final chosen label for input: {chosen_label} || Confidence: {confidence:.1%}")
                return results, chosen_label, confidence
            
            # Only recalibrate if models disagreed
            elif results and not results[0].get('models_agree', True) or not self.pipeline.agreement:
                need_peer_condition = not results[0].get('models_agree', True) and self.pipeline.peer_assistance_threshold > 0.3
                print("\n[⚠️] Disagreement detected between MLP and Transformer predictions. Using calibrated probabilities for final decision.")
                if not self.pipeline.autonomous and need_peer_condition:
                    print('|| Uncertain advanced prediction, requesting peer assistance if allowed...')
                    final_probs = self.pipeline._handle_distributed_connections(final_probs, attn_weights, input_ids, agreement)   
                    final_idx = final_probs[0].argmax()
                    original_idx = final_idx

                    if final_idx > len(reverse_map):
                        final_idx = int(np.argmax(final_probs[:len(reverse_map)-1]))
                        print(f"[⚠️] Clamping {final_idx} → {final_idx}")               
                    final_idx = int(final_idx)  

                    chosen_label = reverse_map.get(final_idx, f"unknown_{final_idx}")
                    try:
                        print(final_probs)
                        confidence = float(final_probs[final_idx])   
                    except:
                        confidence = float(final_probs[0][len(reverse_map)-1]) if isinstance(final_probs[0], (float, int)) else 0.0      
                        
                elif self.pipeline.autonomous and need_peer_condition and attn_weights is not None:
                    if agreement is None:
                        agreement = False

                    print('[||] Iniating local peer output search in database for best output...')
                    final_probs = self.pipeline.distribution._handle_peer_agent_request(final_probs, attn_weights, input_ids, type='DevicePeer', agreement=agreement)
                    final_idx = final_probs[0].argmax()
                    original_idx = final_idx

                    if final_idx > len(reverse_map):
                        final_idx = int(np.argmax(final_probs[:len(reverse_map)-1]))
                        print(f"[⚠️] Clamping {final_idx} → {final_idx}")               
                    final_idx = int(final_idx)  

                    chosen_label = reverse_map.get(final_idx, f"unknown_{final_idx}")
                    try:
                        confidence = float(final_probs[final_idx])   
                    except:
                        confidence = float(final_probs[0][len(reverse_map)-1]) if isinstance(final_probs[0], (float, int)) else 0.0      


                elif not results[0].get('models_agree', True) and confidence > self.pipeline.confidence_threshold:
                    if final_confidence is not None and confidence < self.pipeline.confidence_threshold:
                        print("\n[⚠️] Low confidence detected, but both models don't agree. Using calibrated probabilities for final decision to ensure robustness.")
                        final_probs = self.pipeline.hybrid_prediction(rules, input_ids, dataset)
                        final_idx = final_probs[0].argmax()
                        original_idx = final_idx

                        if final_idx > len(reverse_map):
                            final_idx = int(np.argmax(final_probs[:len(reverse_map)-1]))
                            print(f"[⚠️] Clamping {final_idx} → {final_idx}")               
                        final_idx = int(final_idx)  
                    else:
                        print('[🎯] Stable confidence established, But both Models doesnt Agree, Re-evaluating...')   
                        final_probs = self.pipeline.hybrid_prediction(rules, input_ids, dataset)
                        final_idx = final_probs[0].argmax()
                        original_idx = final_idx

                        if final_idx > len(reverse_map):
                            final_idx = int(np.argmax(final_probs[:len(reverse_map)-1]))
                            print(f"[⚠️] Clamping {final_idx} → {final_idx}")               
                        final_idx = int(final_idx)    

                    chosen_label = reverse_map.get(final_idx, f"unknown_{final_idx}")
                    try:
                        confidence = float(final_probs[0][final_idx])   
                    except:
                        confidence = float(final_probs[0][len(reverse_map)-1]) if isinstance(final_probs[0], (float, int)) else 0.0             
                else:
                    if self.pipeline.use_transformer:
                        print("\n[⚠️] Uncertain confidence and disagreement detected. Using ensemble method for final decision.")
                        input_forward = sequence_ids if sequence_ids is not None else input_ids
                        final_probs, details = self.pipeline.ensemble.predict_ensemble(input_forward, X, y, method='dynamic', embedded=True)
                        final_idx = final_probs[0].argmax()
                        original_idx = final_idx 

                        if final_idx > len(reverse_map):
                            final_idx = int(np.argmax(final_probs[:len(reverse_map)-1]))
                            print(f"[⚠️] Clamping {final_idx} → {final_idx}")               
                        final_idx = int(final_idx)          

                        chosen_label = reverse_map.get(final_idx, f"unknown_{final_idx}")
                        try:
                            confidence = float(final_probs[0][final_idx])   
                        except:
                            confidence = float(final_probs[0][len(reverse_map)-1]) if isinstance(final_probs[0], (float, int)) else 0.0             
                    else:
                        input_forward = sequence_ids if sequence_ids is not None else input_ids
                        final_idx = final_probs[0].argmax() if final_probs is not None else target_probs[0].argmax()

                        original_idx = final_idx 

                        if final_idx > len(reverse_map):
                            final_idx = int(np.argmax(final_probs[:len(reverse_map)-1]))
                            print(f"[⚠️] Clamping {final_idx} → {final_idx}")               
                        final_idx = int(final_idx)          

                        chosen_label = reverse_map.get(final_idx, f"unknown_{final_idx}")
                        if final_probs is None:
                            final_probs = target_probs.copy()

                        try:
                            try:
                                confidence = float(final_probs[0][final_idx])   
                            except:
                                confidence = float(final_probs[0][len(reverse_map)-1]) if isinstance(final_probs[0], (float, int)) else 0.0             
                        except:
                            try:
                                confidence = float(final_probs[final_idx]) 
                            except:
                                confidence = self.pipeline.confidence_threshold

            elif confidence < self.pipeline.confidence_threshold and not self.pipeline.agreement and not results[0].get('models_agree', True):
                if trans_probs is not None:
                    prob_entropy = self.calculate_entropy(final_probs)
                    normalized_entropy = prob_entropy / np.log(prob_entropy.shape[-1]) if prob_entropy.shape[-1] > 1 else 0
                    attn_quality = 1.0 / (1.0 + np.exp(-attn_weights.mean()) + eps) if attn_weights is not None else 0.5
                    anisotropy = self.pipeline.anisotropy_measurement(attn_weights.mean() if attn_weights is not None else 0.5)

                else:
                    normalized_entropy = self.calculate_entropy(input_ids)  # Max entropy for uniform distribution
                    attn_quality = 0.05
                    anisotropy = self.anisotropy_measurement(input_ids) if hasattr(self.pipeline, 'anisotropy_measurement') else 0.5

                mean_entropy = np.mean(normalized_entropy)

                use_robust_prediction = (
                anisotropy < 0.3 or
                mean_entropy > 0.5 or  # High uncertainty
                results[0].get('confidence', 0) < 0.4 or  # Low confidence
                not results[0].get('models_agree', True) or  # Disagreement
                attn_quality < 0.4
                )

                if use_robust_prediction:
                    print("\n[⚡] Condition is poorly unviable to handle agreement. Using robust prediction method for better reliability.")
                    predicted_label, confidence = self.robust_prediction(self.pipeline, titles, label_map, X_raw=X, y=y, show_proba=show_proba, top_k=top_k)
                    if predicted_label is not None:
                        print(f"\n[🎯] Robust prediction result: {predicted_label} with confidence {confidence:.1%}")
                        return _, predicted_label, confidence  
                else:
                    final_idx = final_probs[0].argmax()
                    original_idx = final_idx

                    if final_idx > len(reverse_map):
                        final_idx = int(np.argmax(final_probs[:len(reverse_map)-1]))
                        print(f"[⚠️] Clamping {final_idx} → {final_idx}")                      
                    final_idx = int(final_idx) 

                    chosen_label = reverse_map.get(final_idx, f"unknown_{final_idx}")
                    try:
                        confidence = float(final_probs[0][final_idx])   
                    except:
                        confidence = float(final_probs[0][len(reverse_map)-1]) if isinstance(final_probs[0], (float, int)) else 0.0             
                            
            else:
                print("\n[🎯] Using initial Regular final prediction as final decision.")
                final_idx = final_probs[0].argmax()

                if final_idx > len(reverse_map):
                    final_idx = int(np.argmax(final_probs[:len(reverse_map)-1]))
                    print(f"[⚠️] Clamping {final_idx} → {final_idx}")                    
                final_idx = int(final_idx)

                chosen_label = reverse_map.get(final_idx, f"unknown_{final_idx}")
                try:
                    confidence = float(final_probs[0][final_idx])   
                except:
                    confidence = float(final_probs[0][len(reverse_map)-1]) if isinstance(final_probs[0], (float, int)) else 0.0             
                                                  
            if isinstance(chosen_label, str) and chosen_label.startswith("unknown") or float(confidence) < self.pipeline.confidence_threshold:
                if chosen_label.startswith("unknown"):
                    chosen_label = 'Unknown'
                    confidence = 1.0 - confidence  # Invert confidence for unknown class

                print(f"\n[⚠️] Final prediction is {chosen_label} with uncertain confidence: {confidence:.1%}. Consider more consistent data for the model to learn from.")
            else:
                print(f"\n[🎯] Final chosen label for input: {chosen_label} || Confidence: {confidence:.1%}")  

            try:
                consecutive_probs = self.pipeline.distribution._handle_peer_agent_request(target_probs, attn_weights, input_ids, type='DevicePeer', agreement=agreement)
                sec_final_idx = consecutive_probs[0].argmax()

                if sec_final_idx > len(reverse_map):
                    sec_final_idx = int(np.argmax(consecutive_probs[:len(reverse_map)-1]))
                    print(f"[⚠️] Clamping {sec_final_idx} → {sec_final_idx}")                    
                sec_final_idx = int(sec_final_idx)

                sec_chosen_label = reverse_map.get(sec_final_idx, f"unknown_{sec_final_idx}")
                try:
                    sec_confidence = float(consecutive_probs[0][sec_final_idx])   
                except:
                    sec_confidence = float(consecutive_probs[0][len(reverse_map)-1]) if isinstance(consecutive_probs[0], (float, int)) else self.pipeline.confidence_threshold         

                print('========== Second Prediction Initiative ==========')
                print(f'[⚡] My Second Prediction: {sec_chosen_label}') 
                print(f'[⚡] Confidence: {sec_confidence:.1%}')  

                results[0]['sec_predicted'] = sec_chosen_label
                results[0]['sec_confidence'] = sec_confidence
                results[0]['sec_index'] = sec_final_idx

                if confidence > results[0]['confidence']:
                    results[0]['predicted'] = chosen_label
                    results[0]['confidence'] = confidence
                    results[0]['index'] = final_idx
            except Exception as e:
                print(f'[!] Error initiating second prediction in Advanced prediction method: {e} ')

                results[0]['sec_predicted'] = chosen_label
                results[0]['sec_confidence'] = confidence
                results[0]['sec_index'] = final_idx

                time.sleep(5)

        except Exception as e:
            print(f"[!] Error in advanced prediction method: {e}, Initiating regular prediction method...")
            try:
                results = self.regular_prediction_method(titles, label_map, rules, X=X, y=y, show_proba=False, top_k=3, batch_size=2,use_transformer=True)
                chosen_label = results[0]['predicted']
                confidence = results[0]['confidence']
            except Exception as error:
                print(f'[= ! =] Error in all prediction method: {error}')
                traceback.print_exc()
                results, chosen_label, confidence = None, None, 0.0
                time.sleep(5)

        print('[=] Displaying Results....')     
        correct, sec_correct = self.display_hybrid_results(results, top_k, verbose=True)
        if sec_chosen_label and sec_correct > correct:
            print(f'[⚡] Second Prediction: {sec_chosen_label} has higher accuracies, relying on: {sec_chosen_label} as final label.')
            chosen_label = sec_chosen_label # overrides previous chosen label if accuracy is higher
        if self.pipeline.autonomous and sec_confidence > self.pipeline.confidence_threshold:
            print(f'[⚡] Autonomous Prediction used second predicted label: {sec_chosen_label}')
            chosen_label = sec_chosen_label

        return results, chosen_label, confidence
        
        
    def display_hybrid_results(self, results, top_k=3, verbose=False):
        print("\n" + "="*80)
        print("[🎯] == PREDICTION RESULTS == ")
        print("="*80)
        
        correct = 0
        sec_correct = 0
        total_with_expected = 0
        
        for idx, result in enumerate(results):
            print(f"\n{idx+1}. 📌 '{result['title']}'")
            
            if result.get('expected'):
                total_with_expected += 1
                status = ": ✅" if result['predicted'] == result['expected'] else ": ❌"
                sec_status = ": ✅" if result['sec_predicted'] == result['expected'] else ": ❌"
                print(f"[=] First Expectation: {result['expected']} || Model Answer: {status}")
                print(f"[=] Second Expectation: {result['expected']} || Model Answer: {sec_status}")    

                if result['predicted'] == result['expected']:
                    correct += 1
                if result['sec_predicted'] == result['expected']:
                    sec_correct += 1
            
            # Agreement indicator
            agree_symbol = "✓" if result.get('models_agree', True) else "⚠️"
            print(f"   {agree_symbol} FINAL: {result['predicted']} ({result['confidence']:.1%})")
            
            # MLP vs Transformer
            print(f"      ├─ [⚡] MLP: {result['mlp_prediction']} ({result['mlp_confidence']:.1%})")
            if result.get('transformer_prediction'):
                arrow = "⬆️" if result['transformer_confidence'] > result['mlp_confidence'] else "⬇️"
                print(f"      └─ [🌀] Transformer: {result['transformer_prediction']} ({result['transformer_confidence']:.1%}) {arrow}")
            
            # Top predictions
            if 'top_predictions' in result:
                print(f"\n [🔍] Top {top_k} possibilities:")
                for j, pred in enumerate(result['top_predictions'][:top_k], 1):
                    bar = '█' * int(pred['confidence'] * 20)
                    print(f"         {j}. {pred['label']:20s} {bar} {pred['confidence']:.1%}")
        
        if total_with_expected > 0:
            accuracy = correct / total_with_expected
            print(f"\n📊 Accuracy: {correct}/{total_with_expected} = {accuracy:.1%}")

        return correct, sec_correct


class ConsecutivePeerAgent:
    """
    Lightweight, security-hardened peer agent used as a fallback when the main
    AgentDistributedInference system cannot be initialised or has failed.

    Compared to AgentDistributedInference, this class is intentionally simpler:
    it handles a single peer connection at a time and does not implement async
    queuing or TrustLevel tiers.  Its primary use-case is in
    CohesiveAgentDeployment where a chain of agents needs to exchange
    predictions sequentially.

    Security features
    -----------------
    - All messages are HMAC-SHA256 signed (same sign/verify pattern as
      AgentDistributedInference).
    - A 10 MB message size cap prevents memory exhaustion.
    - allowed_ips whitelist (default: localhost only).
    - Messages with an invalid signature are silently dropped.

    Parameters
    ----------
    peer_id    : Unique string identifier for this agent.
    port       : TCP port this agent listens on.
    secret_key : HMAC key shared with all trusted peers.
    manager    : Optional PipelinePredictionManager for prediction requests.
    pipeline   : Optional IntegratedPipeline for direct model access.
    """
    
    def __init__(self, peer_id: str, port: int, secret_key: str, 
                 manager=None, pipeline=None):
        self.peer_id = peer_id
        self.port = port
        self.secret_key = secret_key
        self.manager = manager  # PipelinePredictionManager
        self.pipeline = pipeline  # IntegratedPipeline
        
        self.connected_peers: Dict[str, Dict] = {}
        self.server_socket: Optional[socket.socket] = None
        self.running = False
        self._lock = threading.RLock()
        
        # Security
        self.allowed_ips = {'127.0.0.1'}
        self.max_message_size = 10 * 1024 * 1024  # 10MB
        
        # Statistics
        self.stats = {
            'predictions': 0,
            'peer_requests': 0,
            'errors': 0
        }
    
    def _sign_message(self, message: dict) -> str:
        """Sign message with HMAC"""
        msg_copy = {k: v for k, v in message.items() if k != 'signature'}
        sorted_msg = {k: msg_copy[k] for k in sorted(msg_copy.keys())}
        msg_bytes = pickle.dumps(sorted_msg, protocol=4)
        key = self.secret_key.encode()
        return hmac.new(key, msg_bytes, hashlib.sha256).hexdigest()
    
    def _verify_signature(self, message: dict, signature: str) -> bool:
        # Verify message signature
        expected = self._sign_message({k: v for k, v in message.items() if k != 'signature'})

        print(f'[ConsecutivePeerAgent] Comparing Signature and verifying...')
        return hmac.compare_digest(expected, signature)
    
    def _send_message(self, sock: socket.socket, message: dict) -> bool:
        """Send signed message"""
        try:
            if sock is None:
                print('[=] Sock is None !')  
                return None

            msg_copy = message.copy()
            msg_copy['timestamp'] = time.time()
            msg_copy['signature'] = self._sign_message(msg_copy)   

            data = pickle.dumps(msg_copy)
            sock.send(len(data).to_bytes(4, 'big'))
            sock.send(data)
            return True
        except Exception as e:
            print(f"[ConsecutivePeerAgent] Send error: {e}")
            return False
    
    def _receive_message(self, sock: socket.socket) -> Optional[dict]:
        """Receive and verify message"""
        try:
            data_len = sock.recv(4)

            print(f'[ConsecutivePeerAgent] Got data length: {data_len}')
            if not data_len:
                return None
            
            msg_len = int.from_bytes(data_len, 'big')
            if msg_len > self.max_message_size:
                return None
            
            data = b''
            while len(data) < msg_len:
                chunk = sock.recv(min(4096, msg_len - len(data)))
                if not chunk:
                    return None
                data += chunk
            
            message = pickle.loads(data)

            print(f'[ConsecutivePeerAgent] Received a message!')
            if 'signature' in message:
                signature = message.pop('signature')
                if not self._verify_signature(message, signature):
                    print(f"[ConsecutivePeerAgent] Invalid signature authentication from message, Message Ignored.")
                    return None

                message['signature'] = signature
            
            return message
            
        except Exception as e:
            print(f"[ConsecutivePeerAgent] Receive error: {e}")
            return None


    async def predict_local(self, text: Any=None) -> Dict:
        """Predict using local model (advanced prediction)"""
        try:
            # Use your existing advanced prediction method
            if self.manager:
                # For single text, wrap in list
                if 'test_titles' in text:
                    test_titles = text['test_titles']
                    label_map = text['label_map']
                    rules = text['rules']
                    result, chosen_label, confidence = self.manager.advanced_prediction_method(
                        test_titles,
                        label_map,
                        rules,
                        show_proba=False,
                        use_transformer=self.pipeline.use_transformer
                    )                    
                else:
                    chosen_label = self.pipeline.predict_single(text)
                    confidence = self.pipeline.confidence_threshold # doubt on simple predictions

                return {
                    'text': text,
                    'prediction': chosen_label,
                    'confidence': confidence,
                    'source': 'local'
                }

            elif not self.manager and self.pipeline:
                result = self.pipeline.predict_single(text)
                return {
                    'text': text,
                    'prediction': result.get('prediction', 'unknown'),
                    'confidence': result.get('confidence', 0.5),
                    'source': 'local'
                }
            else:
                # Fallback simple prediction
                return {
                    'text': text,
                    'prediction': 'unknown',
                    'confidence': 0.5,
                    'source': 'local'
                }
        except Exception as e:
            print(f"[ConsecutivePeerAgent] Local prediction error: {e}")
            return {
                'text': text,
                'prediction': 'error',
                'confidence': 0.0,
                'source': 'local',
                'error': str(e)
            }
    
    async def request_peer_prediction(self, peer_host: Any, peer_port: int, text: Any, timeout: float = 5.0) -> Optional[Dict]:
        """Request prediction from peer - ONLY sends text!"""
        
        peer_key = f"{peer_host}:{peer_port}"
        
        with self._lock:
            # Check if already connected
            if peer_key not in self.connected_peers:
                # Create new connection
                try:
                    if self.pipeline.distribution.enable_ssl and self.pipeline.distribution.ssl_context:
                        sock = self.pipeline.distribution.ssl_context.wrap_socket(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
                    else:
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                
                    sock.settimeout(timeout)
                    sock.bind(('127.0.0.1', 0))

                    sock.connect((peer_host, peer_port))

                    if peer_host in ['127.0.0.1', 'localhost', 'local'] and peer_port == self.port:
                        print(f"[❌] Requesting to self, ignoring request...")
                        sock.close()
                        return  
                    
                    # Authenticate
                    
                    auth_msg = {
                    'type': 'auth',
                    'peer_id': self.peer_id,
                    'token': self.secret_key
                    }


                    if not self._send_message(sock, auth_msg):
                        print(f"[ConsecutivePeerAgent] Failed to send auth to {peer_key}")                        
                        sock.close()
                        return None   
                    else:
                        print('[ConsecutivePeerAgent] Successfully send Authentication message')                        

                    response = self._receive_message(sock)

                    print(f'[ConsecutivePeerAgent] Got Authentication response from peer: {response} ')
                    if not response or response.get('status') != 'ok':
                        sock.close()
                        print('[ConsecutivePeerAgent] Socket is closed!')
                        return None
                    else:
                        print(f'[ConsecutivePeerAgent] Received Response from peer')
                    
                    self.connected_peers[peer_key] = {
                        'sock': sock,
                        'host': peer_host,
                        'port': peer_port,
                        'last_seen': time.time()
                    }
                except Exception as e:
                    print(f"[ConsecutivePeerAgent] Connection to {peer_key} failed: {e}")
                    return None
            
            sock = self.connected_peers[peer_key]['sock']
        
        # Send prediction request 
        try:
            request = {
                'type': 'predict',
                'text': text,
                'peer_id': self.peer_id
            }
            
            sock.settimeout(timeout)
            if not self._send_message(sock, request):
                print('[ConsecutivePeerAgent] Send Prediction request Message Failed!')
                return None
            else:
                print('[ConsecutivePeerAgent] Prediction request Message send successful ')
            
            response = self._receive_message(sock)
            sock.settimeout(None)
            print(f'[ConsecutivePeerAgent] Got Prediction response from peer with address: {peer_host}:{peer_port}')

            if response and response.get('type') == 'predict_response':
                self.stats['peer_requests'] += 1

    
                return {
                    'text': text,
                    'prediction': response.get('prediction'),
                    'confidence': response.get('confidence', 0.0),
                    'source': f"peer_{peer_host}:{peer_port}"
                }
            
            return None
            
        except Exception as e:
            print(f"[ConsecutivePeerAgent] Peer request error: {e}")
            # Clean up dead connection
            with self._lock:
                if peer_key in self.connected_peers:
                    try:
                        self.connected_peers[peer_key]['sock'].close()
                    except:
                        pass
                    del self.connected_peers[peer_key]
            return None
    
    async def ensemble_predict(self, peer_addresses: List[Tuple[str, int]],  text: Any=None,
                                confidence_threshold: float = 0.6) -> Dict:
        """
        Ensemble prediction: local first, then ask peers if confidence is low.
        """
        print(f"[ConsecutivePeerAgent] Starting ensemble prediction with port {self.port}!")
        
        # Step 1: Local prediction
        local_result = await self.predict_local(text)
        print(f"[ConsecutivePeerAgent] Local: {local_result['prediction']} ({local_result['confidence']:.1%})")
        
        best_result = local_result
        
        # Step 2: If low confidence, ask peers
        if local_result['confidence'] < confidence_threshold and peer_addresses or peer_addresses:
            print(f"[ConsecutivePeerAgent] Low confidence, asking {len(peer_addresses)} peers...")
            
            peer_results = []
            for host, port in peer_addresses:
                result = await self.request_peer_prediction(host, port, text, timeout=60)
                if result:
                    peer_results.append(result)

                    print(f"[ConsecutivePeerAgent] Peer {host}:{port}: {result['prediction']} ({result['confidence']:.1%})")
                    print(f'[==] Local result: {local_result['prediction']} With Confidence: {local_result['confidence']}')
                    print(f'[==] Peer result: {result['prediction']} With Confidence: {result['confidence']}')

            if peer_results:
                best_peer = max(peer_results, key=lambda x: x['confidence'])                                   
                if best_peer['confidence'] > local_result['confidence']:
                    best_result = best_peer
                    print(f"[ConsecutivePeerAgent] Using peer result: {best_peer['prediction']} || Confidence: ({best_peer['confidence']:.1%})")
        else:
            print('[ConsecutivePeerAgent] Skipping Ensemble prediction... Peer address is None or empty')
            time.sleep(5)
            return best_result


        self.stats['predictions'] += 1
        return best_result
    
    def start_server(self):
        """Start server to accept peer connections"""
        
        def server_loop():
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(('0.0.0.0', self.port))

            self.server_socket.settimeout(1.0)           
            self.server_socket.listen(5)

            if self.pipeline.distribution.enable_ssl and self.pipeline.distribution.ssl_context:
                self.server_socket = self.pipeline.distribution.ssl_context.wrap_socket(self.server_socket, server_side=True)

            self.running = True
            
            print(f"[ConsecutivePeerAgent] Server listening on port {self.port}!")
            
            while self.running:
                try:
                    client, addr = self.server_socket.accept()
                    
                    # Check IP
                    if addr[0] not in self.allowed_ips:
                        print(f"[ConsecutivePeerAgent] Rejected connection from {addr}")
                        client.close()
                        continue
                    
                    # Handle in thread
                    thread = threading.Thread(target=self._handle_client, args=(client, addr))
                    thread.daemon = True
                    thread.start()

                except socket.timeout:
                    continue    

                except Exception as e:
                    if self.running:
                        print(f"[ConsecutivePeerAgent] Server error: {e}")
    
            try:
                self.server_socket.close()
            except:
                pass

        print("[ConsecutivePeerAgent] Server Successfully Stopped listening !")
        
        thread = threading.Thread(target=server_loop, daemon=True)
        thread.start()
    
    def _handle_client(self, client, addr):
        # Handle incoming peer connection
        print(f"[ConsecutivePeerAgent] Client connected from {addr}")
        
        try:
            # Authenticate
            if addr[0] in ['127.0.0.1', 'localhost', 'local'] and addr[1] == self.port:
                print(f"[❌] Client is self, ignoring...")
                client.close()
                return   

            auth_msg = self._receive_message(client)

            if not auth_msg:
                print(f"[ConsecutivePeerAgent] No authentication message from peer {addr}")
                client.close()
                return


            if not auth_msg or auth_msg.get('type') != 'auth':
                print(f"[ConsecutivePeerAgent] Auth failed from {addr}")
                client.close()
                return
            
            if auth_msg.get('token') != self.secret_key:
                print(f"[ConsecutivePeerAgent] Invalid token from {addr}")
                client.close()
                return
            
            # Send auth response
            self._send_message(client, {'type': 'auth_response', 'status': 'ok'})
            
            # Handle prediction requests
            while self.running:
                message = self._receive_message(client)
                if message is None:
                    break
                
                if message.get('type') == 'predict':
                    text = message.get('text', '')
                    print(f"[ConsecutivePeerAgent] Received prediction request!")
                    
                    # Use local prediction
                    result = asyncio.run(self.predict_local(text))
                    
                    response = {
                        'type': 'predict_response',
                        'prediction': result['prediction'],
                        'confidence': result['confidence']
                    }
                    self._send_message(client, response)
                    
                elif message.get('type') == 'ping':
                    self._send_message(client, {'type': 'pong'})
                    
        except Exception as e:
            print(f"[ConsecutivePeerAgent] Client handler error: {e}")
        finally:
            client.close()
            print(f"[ConsecutivePeerAgent] Client disconnected from {addr}")


    def stop_server(self):
        self.running = False

        print('[ConsecutivePeerAgent] Initiating Server shutdown...')   
        # Close all peer connections
        try:
            with self._lock:
                for key, info in self.connected_peers.items():
                    try:
                        info['sock'].shutdown(socket.SHUT_RDWR)
                        info['sock'].close()
                    except:
                        pass
                
                self.connected_peers.clear()
                if self.server_socket:
                    try:
                        self.server_socket.close()  
                    except Exception as e:
                        print(f'[ConsecutivePeerAgent] Cant close socket: {e}')
                        pass  
                                
                print('[ConsecutivePeerAgent] Server Successfully Stopped listening !')

        except Exception as e:
            print(f'[ConsecutivePeerAgent] Error closing socket: {e}')
            pass


    def get_stats(self) -> Dict:
        # Get statistics
        return {
            **self.stats,
            'connected_peers': len(self.connected_peers)
        }

    
class CohesiveAgentDeployment:
    """
    Production-grade deployment wrapper that assembles and manages the full
    system stack in a single object.

    What it wires together
    ----------------------
    1. IntegratedPipeline          — core ML pipeline (training + inference).
    2. PipelinePredictionManager   — dataset loading and high-level prediction.
    3. PipelineAsyncManager        — async event loop, API-key auth, rate limits.
    4. AgentDistributedInference   — P2P peer networking (via the pipeline).
    5. ConsecutivePeerAgent        — fallback peer agent for direct connections.

    Lifecycle
    ---------
    __init__  : Constructs all components, loads training data, and initialises
                security (API key, bootstrap token if HARDENED level).
    train()   : Trains the pipeline on the loaded dataset.
    start()   : Starts the async manager and (if enable_peers) the peer server.
    predict() : Routes through the async manager if running, otherwise falls
                back to synchronous prediction.
    stop()    : Gracefully shuts down async manager and peer connections.

    Singleton behaviour
    -------------------
    _singleton_initialized guard prevents double-construction when the same
    instance is reused across call sites.

    Parameters
    ----------
    memory_name            : Logical DB scope for all model artefacts.
    filename               : Path to the label CSV file.
    target_title           : Column name for text inputs in the CSV.
    label_name             : Column name for class labels in the CSV.
    security_level         : One of "DEVELOPMENT", "STAGING", "PRODUCTION",
                             "HARDENED" (maps to SecurityLevel enum).
    enable_peers           : Whether to start the peer discovery server.
    trusted_networks       : List of CIDR strings for the IP allowlist.
    secret_key             : HMAC key for peer message signing.
    peer_discovery_port    : TCP port for AgentDistributedInference server.
    shared_auth_token      : Shared secret for peer authentication.
    predict_manager        : External PipelinePredictionManager (optional;
                             one is created internally if not provided).
    peer_config            : Path to a JSON file with pre-configured peer
                             addresses (host/port pairs).
    consecutive_peer_config: Optional config for ConsecutivePeerAgent setup.
    """
    
    def __init__(self, 
                 pipeline: IntegratedPipeline,    
                 memory_name: str,
                 filename: str,
                 target_title: str,
                 label_name: str,
                 security_level: str = "PRODUCTION",
                 enable_peers: bool = True,
                 trusted_networks: list = None,
                 secret_key: str = None,
                 peer_discovery_port: int = 5555,
                 shared_auth_token: str = None,
                 predict_manager: Any=None,
                 peer_config: Any='peer_config.json',
                 consecutive_peer_config: Any=None
                 ):
        self.pipeline = pipeline
        self.pipeline.autonomous = True
        
        # Initialize prediction manager
        self.manager = PipelinePredictionManager(
            self.pipeline,
            label_csv=filename,
            target_title=target_title,
            label=label_name
        )

        self._peer_agent = ConsecutivePeerAgent(
            peer_id=self.pipeline.memory_name,
            port=peer_discovery_port + 100,  # Different port to avoid conflict
            secret_key=secret_key,
            manager=self.manager,
            pipeline=self.pipeline
        ) 

        # Map security level string to enum
        security_map = {
            "DEVELOPMENT": SecurityLevel.DEVELOPMENT,
            "STAGING": SecurityLevel.STAGING,
            "PRODUCTION": SecurityLevel.PRODUCTION,
            "HARDENED": SecurityLevel.HARDENED
        }
        
        # Create Async Manager with security
        self.async_manager = PipelineAsyncManager(
            pipeline=self.pipeline,
            prediction_manager=self.manager,
            security_level=security_map.get(security_level, SecurityLevel.PRODUCTION),
            api_key=shared_auth_token,
            max_workers=4,
            task_timeout=30,
            max_retries=3
        )

        self.peer_config_name = peer_config
        self.consecutive_peer_config = consecutive_peer_config
        if shared_auth_token:
            # Set for distribution (peer authentication)
            self.pipeline.distribution.auth_token = shared_auth_token
            self.pipeline.distribution.secret_key = shared_auth_token
            
            # Set for async manager (API key for predictions)
            self.async_manager._default_api_key = shared_auth_token
            self.async_manager.api_key_manager.keys = {}  # Reset
            self.async_manager.api_key_manager.generate_key(
                {'type': 'shared', 'source': 'cluster'},
                key_value=shared_auth_token  # Need to modify generate_key to accept value
            )
            
            print(f"[🔑] Using shared auth token for entire cluster") 


        self.enable_peers = enable_peers
        self.peer_discovery_port = peer_discovery_port
        self._shutdown_event = asyncio.Event()
        self._peer_tasks = []
        self._known_peers = {}
        self.identified_peers = []

        self.attempt = 0
        self.timeout = 120
        self.max_attempts = 3
        
        self.result_queue = AsyncResultQueue(max_size=1000)
        self.worker_pool = WorkerPool(self.result_queue, num_workers=4) 
        
        # Discovery security settings
        self.discovery_secret = os.environ.get('DISCOVERY_SECRET', 'default_secret_change_me')
        self.discovery_enabled = True
        self.discovery_broadcast_only_trusted_network = True
        self.trusted_networks = trusted_networks  # Only respond to these networks
        self.discovery_rate_limit = 5  # Max 5 discovery responses per minute per IP
        self._discovery_requests = defaultdict(list)  # Track request rates
        self.local_ips = self._get_local_ips()  # Get local IPs for discovery filtering
        self._connecting_to = set()
        self.consecutive_peer_config = consecutive_peer_config if consecutive_peer_config else "consecutive_peers.json"

    def _get_local_ips(self) -> List[str]:
        # Get all local IP addresses for this machine
        ips = set()
        try:
            # Get hostname IP
            ips.add(socket.gethostbyname(socket.gethostname()))
            
            # Get all network interfaces
            hostname = socket.gethostname()
            for ip in socket.gethostbyname_ex(hostname)[2]:
                ips.add(ip)
            
            # Add localhost
            ips.add('127.0.0.1')
            
        except Exception as e:
            logger.warning(f"[-] Could not get local IPs: {e}")
            ips.add('127.0.0.1')
        
        return list(ips)
        
    def _is_trusted_network(self, client_ip: str) -> bool:
        # if client IP is from trusted network
        import ipaddress
        
        try:
            client = ipaddress.ip_address(client_ip)
            for network in self.trusted_networks:
                if client in ipaddress.ip_network(network):
                    return True
        except:
            pass
        return False
    
    def _check_discovery_rate_limit(self, client_ip: str) -> bool:
        # Rate limit discovery requests
        now = time.time()
        # Clean old requests
        self._discovery_requests[client_ip] = [
            t for t in self._discovery_requests[client_ip] 
            if now - t < 60  # Keep last minute
        ]
        
        if len(self._discovery_requests[client_ip]) >= self.discovery_rate_limit:
            logger.warning(f"[=] Discovery rate limit exceeded for {client_ip}")
            return False
        
        self._discovery_requests[client_ip].append(now)
        return True
    
    def _create_discovery_response(self) -> dict:
        # a secure discovery response (minimal info)
        return {
            'type': 'DISCOVERY_RESPONSE',
            'version': '1.0',
            'port': self.peer_discovery_port,
            'requires_auth': True,  # Don't reveal agent_id or capabilities
            'timestamp': time.time()
        }    


    async def start(self, bootstrap_token: str = None):
        # Start the agent with all components
        
        logger.info("[🚀] Starting Safe Agent Deployment...")
        
        # 1. Start Async Manager
        success = self.async_manager.start(bootstrap_token=bootstrap_token)
        if not success:
            raise RuntimeError("[-] Failed to start Async Manager")
        
        logger.info("[✅] Async Manager started")
        
        # 2. Start distributed inference (for peer connections)
        if self.enable_peers:
            # Start the server to listen for peer connections
            self.pipeline.distribution.start_server()
            logger.info(f"[✅] Peer server listening on port {self.peer_discovery_port}")
            
            # Start peer discovery if needed
            await self._start_peer_discovery()
        
            asyncio.create_task(self._health_monitor())
           
        # Start result queue and workers
        await self.result_queue.start()
        await self.worker_pool.start(self._prediction_worker)
        
        # 4. Start health monitoring loop
        asyncio.create_task(self._health_monitor())

        logger.info("[🎉] Agent fully operational!")
        self._print_status()
        
        return True
        
    async def _prediction_worker(self, texts: list, api_key: str = None, client_ip: str = None) -> dict:
        # Worker function for processing predictions
        # This runs in a thread pool via asyncio.to_thread
        return self.async_manager.predict(
            texts=texts,
            timeout=self.timeout,
            retries=None,
            api_key=api_key,
            client_ip=client_ip,
            method='advanced'
        )

    async def _start_peer_discovery(self):
        # Discover and connect to peer agents safely
        
        #  Connect to known peers from config file
        known_peers = self._load_known_peers()
        
        for peer_host, peer_port in known_peers:
            try:
                try:
                    await self._connect_to_peer(peer_host, peer_port)
                except:
                    if self.peer_discovery_broadcast:
                        await self._discover_local_peers()
        
                    if self.peer_discovery_broadcast:
                        self._discovery_task = asyncio.create_task(self._broadcast_discovery())    

            except Exception as e:
                logger.error(f"[❌] Peer connection error {peer_host}:{peer_port} - {e}")
    
    def _load_known_peers(self):
        # Load known peers from config file

        print(f'[==] Loading known peers from config: {self.peer_config_name}')
        config_file = self.peer_config_name
        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                config = json.load(f)
                return config.get('known_peers', [])
        
        # Default peers (can be replaced with other IPs)
        return [
            ('127.0.0.1', 5555),  # Example peer
            ('127.0.0.1', 5556)
        ]
        
    async def _discover_local_peers(self):
        # Discover peers on local network via port scanning
        logger.info("🔍 Scanning for local peers...")
        
        # Scan common ports
        for port in range(self.peer_discovery_port, self.peer_discovery_port + 5):
            if port == self.peer_discovery_port:
                continue  # Skip self
                
            for ip in self.local_ips[:3]:  # Limit to first few IPs to avoid long scan
                if ip == '127.0.0.1':
                    continue
                    
                await self._connect_to_peer(ip, port)
    
    async def _broadcast_discovery(self):
        # broadcast discovery message to find peers on network
        logger.info("📡 Starting broadcast discovery...")
        
        while not self._shutdown_event.is_set() and self.discovery:
            try:
                # UDP broadcast socket
                if self.pipeline.distribution.enable_ssl and self.pipeline.distribution.ssl_context:
                    sock = self.pipeline.distribution.ssl_context.wrap_socket(socket.socket(socket.AF_INET, socket.SOCK_DGRAM))
                else:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                            
                print(f"[broadcast_discovery() SOCKET CREATED] id={id(sock)}")                
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                sock.settimeout(2)
                
                # Broadcast discovery message
                discovery_msg = json.dumps({
                    'type': 'DISCOVERY',
                    'agent_id': id(self.pipeline.distribution),
                    'port': self.peer_discovery_port,
                    'timestamp': time.time()
                }).encode()
                
                # Adding signature to prevent spoofing
                signature = self._sign_message(discovery_msg)
                discovery_msg['signature'] = signature

                sock.sendto(discovery_msg, ('<broadcast>', self.peer_discovery_port))
                
                # Listen for responses
                try:
                    data, addr = sock.recvfrom(1024)
                    client_ip = addr[0]
                    client_port = addr[1]

                    if client_ip in ['127.0.0.1', 'localhost']:
                        if client_port == self.peer_discovery_port:
                            print(f"[=] Ignoring self-discovery response")
                            continue  

                    # Security checks before processing response
                    if not self._is_trusted_network(client_ip):
                        logger.debug(f"[==] Ignoring discovery from untrusted network: {client_ip}")
                        continue
                    
                    if not self._check_discovery_rate_limit(client_ip):
                        continue    

                    response = json.loads(data.decode())
                    # Verify signature
                    if not self._verify_signature(response):
                        logger.warning(f"[=-=] Invalid discovery response signature from {client_ip}")
                        continue   

                    if response.get('type') == 'DISCOVERY_RESPONSE':
                        logger.info(f"✅ Received discovery response from {client_ip}")
                        peer_host = addr[0]
                        peer_port = response.get('port')
                        await self._connect_to_peer(peer_host, peer_port)
                except socket.timeout:
                    pass
                
                sock.close()
                
            except Exception as e:
                logger.debug(f"Broadcast discovery error: {e}")
            
            # Wait before next broadcast
            await asyncio.sleep(60)
    
    def _sign_message(self, message: dict) -> str:
        # Sign message with HMAC to prevent spoofing
       
        # Sort keys for consistent serialization
        message_str = json.dumps(message, sort_keys=True)
        return hmac.new(
            self.discovery_secret.encode(),
            message_str.encode(),
            hashlib.sha256
        ).hexdigest()  
        
    def _verify_signature(self, message: dict) -> bool:
        # Verify message signature
        if 'signature' not in message:
            return False
        
        signature = message.pop('signature')
        expected = self._sign_message(message)
        message['signature'] = signature
        
        return hmac.compare_digest(signature, expected)


    async def _connect_to_peer(self, host: str, port: int) -> bool:
        # Connect to a peer agent
        try:
            # Check if already connected    
            # Store peer info for reconnection
            peer_key = f"{host}:{port}"

            #  ✅ Prevent multiple simultaneous connection attempts to same peer
            if peer_key in self._connecting_to:
                print(f"[⚠️] Already connecting to {peer_key}, skipping")
                return False     

            self._connecting_to.add(peer_key)  

            for agent_id, info in self.pipeline.distribution.remote_agents.items():
                if info.get('host') == host and info.get('port') == port:
                    logger.debug(f"[=+=] Already connected to {host}:{port}")
                    return True
            
            logger.info(f"🔗 Connecting to peer {host}:{port}")
            
            # Use the distribution system to connect
            sock = self.pipeline.distribution.connect_to_agent(host, port)
            
            if sock:
                logger.info(f"✅ Connected to peer {host}:{port}")

                self._known_peers[peer_key] = {
                    'host': host,
                    'port': port,
                    'sock': sock,
                    'last_seen': datetime.now(),
                    'connected': True
                }
                
                # Start background task to handle peer messages
                task = asyncio.create_task(
                    self._handle_peer_communication(host, port, sock)
                )
                self._peer_tasks.append(task)
                return True
            else:
                logger.warning(f"[❌] Failed to connect to {host}:{port}")
                return False
                
        except Exception as e:
            logger.error(f"[-] Peer connection error {host}:{port} - {e}")
            return False
            


    async def _handle_peer_communication(self, peer_host: str, peer_port: int, sock):
        # Handle bidirectional communication with a peer
        logger.info(f"📡 Peer communication active for {peer_host}:{peer_port}")
        
        try:
            while not self._shutdown_event.is_set():
                # The distribution system handles message receiving internally
                # This task just monitors connection health
                await asyncio.sleep(5)
                
                # Send heartbeat to check connection
                try:
                    # self.pipeline.distribution._send_message(
                        # sock, {'type': 'PING', 'timestamp': time.time()}
                   # )
                   sock.getpeername()
                   print(f'[==] Peer name: {sock.getpeername()}')
                except:
                    logger.warning(f"[-] Peer {peer_host}:{peer_port} disconnected")
                    break
                
        except asyncio.CancelledError:
            logger.info(f"[-] Peer communication cancelled for {peer_host}:{peer_port}")
        except Exception as e:
            logger.error(f"[-] Peer communication error: {e}")
        finally:
            # Update peer status
            peer_key = f"{peer_host}:{peer_port}"
            if peer_key in self._known_peers:
                self._known_peers[peer_key]['connected'] = False
            sock.close()

    
    async def _peer_health_monitor(self):
        # Monitor peer health and reconnect if needed
        logger.info("[💓] Peer health monitor started")
        
        while not self._shutdown_event.is_set():
            await asyncio.sleep(30)
            
            try:
                # Ping all connected peers
                alive_agents = self.pipeline.distribution.broadcast_ping()
                logger.info(f"[=+=] Connected peers: {len(alive_agents)}")
                
                # Reconnect to known peers that went offline
                for peer_key, peer_info in self._known_peers.items():
                    if not peer_info.get('connected', False):
                        logger.info(f"[==] Attempting to reconnect to {peer_key}")
                        await self._connect_to_peer(peer_info['host'], peer_info['port'])
                        
            except Exception as e:
                logger.error(f"[❌] Peer health monitor error: {e}")
       
    
    async def _health_monitor(self):
        # Background health monitoring
        while not self._shutdown_event.is_set():
            await asyncio.sleep(30)
            
            try:
                stats = self.async_manager.get_stats()
                logger.info(f"[==] Health Check - Stats: {stats}")
                
                # Check if we need to reconnect peers
                if self.enable_peers:
                    alive_agents = self.pipeline.distribution.broadcast_ping()
                    logger.info(f"[=+=] Connected peers: {len(alive_agents)}")
                    
            except Exception as e:
                logger.error(f"[❌] Health monitor error: {e}")
                
    def save_peer_config(self, peers: List[tuple]):
        """Save peer configuration to file"""
        config = {'known_peers': peers}
        with open('peer_config.json', 'w') as f:
            json.dump(config, f, indent=2)
        logger.info(f"[==] Saved {len(peers)} peers to config")    

        
    def _print_status(self):
        print("\n" + "="*70)
        print("=== 🤖 COHESIVE INTEGRATED PIPELINE - STATUS ===")
        print("="*70)
        print(f"📊 State: {self.async_manager.state}")
        print(f"🔒 Security Level: {self.async_manager.security_level.value}")
        print(f"🌐 Peers Enabled: {self.enable_peers}")
        print(f"🔗 Connected Peers: {len(self.pipeline.distribution.remote_agents)}")
        print(f"📡 Peer Port: {self.peer_discovery_port}")
        print(f"🖥️  Local IPs: {', '.join(self.local_ips)}")
        print(f"⏳ Queue Size: {self.async_manager._stats['queue_size']}")
        print(f"🔑 API Key Required: {self.async_manager.config.require_api_key}")
        if self.async_manager.config.require_api_key:
            print(f"🔑 Default API Key: {getattr(self.async_manager, '_default_api_key', 'N/A')[:20]}...")
        
        # Show connected peers
        if self.pipeline.distribution.remote_agents:
            print("\n📡 Connected Peers:")
            for agent_id, info in self.pipeline.distribution.remote_agents.items():
                print(f"   → {info.get('host', 'unknown')}:{info.get('port', 'unknown')} (trust: {info.get('trust', 1.0):.2f})")
        
        print("="*70)
    
    def get_peers_status(self) -> Dict:
        """Get detailed status of all peers"""
        return {
            'connected_peers': len(self.pipeline.distribution.remote_agents),
            'known_peers': self._known_peers,
            'remote_agents': {
                agent_id: {
                    'host': info.get('host'),
                    'port': info.get('port'),
                    'trust': info.get('trust', 1.0)
                }
                for agent_id, info in self.pipeline.distribution.remote_agents.items()
            }
        }
    

    # ============ PREDICTION METHODS ============
    async def multi_modal_peer_ensemble_prediction(self, texts, api_key: str = None, method: str = 'advanced', disable_sync: bool=False) -> dict:
        """
        Robust prediction: try main system first, fallback to SecurePeerAgent.
        """
        try:
            # Try main prediction with timeout
            if not self.pipeline.autonomous:
                print('[==] Initiating Autonomous ensemble prediction...')
                self.pipeline.ensemble.explainer.supervised_learning = False
                self.pipeline.autonomous = True

            result = await asyncio.wait_for(
                self.predict_with_peers(texts, api_key, method, disable_sync=disable_sync),
                timeout=60.0
            )
            
            # Check if result is valid
            if result and result.get('confidence', 0) > self.pipeline.confidence_threshold and result.get('peer_count') > 0:
                return result
            
            # Low confidence, try fallback
            print("[=] Initiating Consecutive peer ensemble...")
            return await self.predict_with_peer_consecutive(texts, api_key, method)
            
        except (asyncio.TimeoutError, Exception) as e:
            print(f"[=] Main prediction failed: {e}, using consecutive ensemble...")
            return await self.predict_with_peer_consecutive(texts, api_key, method)

    def _load_consecutive_known_peers(self):
        """Load peers for fallback using different ports"""
        config_file = self.consecutive_peer_config
        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                config = json.load(f)
                return config.get('known_peers', [])
        
        return [
            ('127.0.0.1', 5656),
            ('127.0.0.1', 5655)
        ]
    
    async def predict_with_peer_consecutive(self, texts, api_key: str = None, method: str = 'advanced') -> dict:
        """
        Fallback prediction using SecurePeerAgent when main system fails.
        """
        print("[=] Using Secure Peer Agent fallback...")
        

        if not self._peer_agent.running:
            self._peer_agent.start_server()
        
        # Extract text
        # Get peer addresses from config
        peer_addresses = self._load_consecutive_known_peers()
        print(f'[===] Peer addresses: {peer_addresses}')
        
        # Ensemble prediction
        result = await self._peer_agent.ensemble_predict(
            peer_addresses=peer_addresses,
            text=texts,           
            confidence_threshold=self.pipeline.confidence_threshold
        )

        
        return {
            'prediction': result['prediction'],
            'confidence': result['confidence'],
            'source': result.get('source', 'unknown'),
            'fallback': True
        }


    async def predict_with_peers(self, texts, api_key: str = None, method: str = 'advanced', disable_sync: bool=False) -> dict:
        """
        Simple peer prediction: Connect to peers first, then get predictions.
        """
        print("[=+=] Starting peer-augmented prediction")
        
        try:
            if not disable_sync:
                local_result = self.predict_sync(texts, api_key, method=method)
                print(f'[==] Local prediction Result: {local_result.get("prediction")} ({local_result.get("confidence", 0):.1%})')
            else:
                local_result = {'prediction': None, 'confidence': 0.0}

            connection = await self._ensure_peer_connections(api_key)

            print(f'[=] Peer connection ensured: {connection}')
                     
            peers = []
            for agent_id, info in list(self.pipeline.distribution.remote_agents.items()):
                if agent_id != 'local' and str(agent_id) != str(id(self)):
                    sock = info.get('sock')
                    if sock:
                        try:
                            sock.getpeername()
                            peers.append(agent_id)
                            print('[=+=] Socket is alive!')
                        except Exception as e:
                            print('[=] Socket is not available')
                            pass
                    else:
                        print('[=] No socket is available')
                else:
                    print(f'[=^=] peer in sight: {self.pipeline.distribution.remote_agents}')
            
            print(f'[=+=] Connected peers: {len(peers)}') 

            confidence_threshold = getattr(self.pipeline, 'confidence_threshold', 0.6)
            if not peers or local_result.get('confidence', 0) >= confidence_threshold:
                print(f'[==] Using local result (confidence: {local_result.get("confidence", 0):.1%})')
                return local_result
            
            print(f'[=/=] Asking {len(peers)} peers...')
            
            peer_results = []
            for agent_id in peers:
                try:
                    result = await self._ask_peer_simple(agent_id, texts)
                    if result:
                        peer_results.append(result)
                        print(f'[/==] Peer {agent_id} result: {result.get("prediction")} ({result.get("confidence", 0):.1%})')
                except Exception as e:
                    print(f'[/=-] Peer {agent_id} failed: {e}')
            
            if peer_results:
                best = max(peer_results, key=lambda x: x.get('confidence', 0))
                best_conf = best.get('confidence', 0)
                local_conf = local_result.get('confidence', 0)
                
                print(f'[==] Local: {local_conf:.1%}, Best peer: {best_conf:.1%}')
                
                if best_conf > local_conf:
                    print(f'[/==] Using peer result: {best.get("prediction")}')
                    return best
            
            return local_result
            
        except Exception as e:
            print(f"[=] Peer prediction failed: {e}")
            traceback.print_exc()
            return self.predict_sync(texts, api_key, method='basic')
            
    async def _ask_peer_simple(self, agent_id, texts):
        """
        Simple request to a single peer.
        """
        info = self.pipeline.distribution.remote_agents.get(agent_id)
        if not info:
            return None
        
        sock = info.get('sock')
        if not sock:
            return None
        
        # Prepare message
        print('[==] Preparing Message...')
        if isinstance(texts, dict) and 'test_titles' in texts:
            message = {
                'type': self.pipeline.distribution.MSG_TYPES['PREDICT_REQUEST'],

                'payload': {
                    'test_titles': texts.get('test_titles'),
                    'label_map': texts.get('label_map'),
                    'rules': texts.get('rules'),
                    'use_transformer': texts.get('use_transformer', True)
                },
                'token': self.get_api_key()
            }
        else:
            text = texts[0] if isinstance(texts, list) else str(texts)
            message = {
                'type': self.pipeline.distribution.MSG_TYPES['PREDICT_REQUEST'],
                'text': text,
                'token': self.get_api_key(),
                'timestamp': time.time()
            }
        
        try:
            sock.settimeout(10)
            # Add this before sending
            try:
                sock.getpeername()  # Test if socket is still alive
                print('[=] Socket still present!')
            except:
                print(f"[=] Socket to {agent_id} is dead")
                return None   

            self.pipeline.distribution._send_message(sock, message)

            print('[==] Successfully send prediction message!')
            response = self.pipeline.distribution._receive_message(sock)
            sock.settimeout(20)
            
            if response and response.get('type') == 2:
                print(f'[=+=] Got response from peer: {response}')
                return {
                    'prediction': response.get('prediction'),
                    'confidence': response.get('confidence', 0)
                }
            else:
                print('[-] No response from peer.')
            return None
            
        except Exception as e:
            print(f'[=] Error asking peer {agent_id}: {e}')
            return None


    def _is_server_listening(self) -> bool:
        # if the server is actually listening on its port
        if self.pipeline.distribution.enable_ssl and self.pipeline.distribution.ssl_context:
            sock = self.pipeline.distribution.ssl_context.wrap_socket(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
        else:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                
        sock.settimeout(1)
        try:
            result = sock.connect_ex(('127.0.0.1', self.peer_discovery_port))
            sock.close()
            listening = result == 0
            print('[=+=] Server is listening!')
            return listening
        except:
            return False

    async def _ensure_peer_connections(self, api_key: str = None):
        """
        Robust peer connection manager - prevents duplicate connections and WinError.
        """
        print("[=] Ensuring peer connections...")
        
        # ✅ Step 1: Clean up dead connections first
        dead_connections = []
        for agent_id, info in list(self.pipeline.distribution.remote_agents.items()):
            if agent_id == 'local':
                continue
            
            sock = info.get('sock')
            if sock is None:
                dead_connections.append(agent_id)
                continue
            
            # Test if socket is still alive
            try:
                sock.getpeername()
            except:
                print(f"[=] Dead connection detected: {agent_id}")
                dead_connections.append(agent_id)
        
        # Remove dead connections
        for agent_id in dead_connections:
            print(f"[=] Removing dead connection: {agent_id}")
            try:
                del self.pipeline.distribution.remote_agents[agent_id]
            except:
                pass
        
        # ✅ Step 2: Load known peers from config
        known_peers = self._load_known_peers()
        
        if not known_peers:
            print("[=] No known peers configured")
            return False
        
        # ✅ Step 3: Try each peer once, no retry loops
        successful = False
        
        for host, port in known_peers:
            peer_key = f"{host}:{port}"
            
            # Skip self
            if host in ['127.0.0.1', 'localhost'] and port == self.peer_discovery_port:
                print(f"[=] Skipping self: {peer_key}")
                continue
            
            # Check if already connected (and alive)
            already_connected = False
            for agent_id, info in self.pipeline.distribution.remote_agents.items():
                if info.get('host') == host and info.get('port') == port:
                    sock = info.get('sock')
                    if sock:
                        try:
                            sock.getpeername()
                            print(f"[=] Already connected to {peer_key}")
                            already_connected = True
                            successful = True
                            break
                        except:
                            # Socket dead, will reconnect
                            pass
            
            if already_connected:
                continue
            
            # ✅ Step 4: Single connection attempt (NO RETRY)
            print(f"[=] Connecting to {peer_key}...")
            
            try:
                # Use add_peer with timeout
                result = await self._connect_single_attempt(host, port, api_key)
                
                if result:
                    print(f"[=] ✅ Connected to {peer_key}")
                    successful = True
                else:
                    print(f"[=] ❌ Failed to connect to {peer_key}")
                    
            except Exception as e:
                print(f"[=] ❌ Error connecting to {peer_key}: {e}")
        
        return successful


    async def _connect_single_attempt(self, host, port, api_key, timeout=5):
        """
        Single connection attempt - no retries, no loops.
        """
        try:
            # Check if already connected (one more time)
            for agent_id, info in self.pipeline.distribution.remote_agents.items():
                if info.get('host') == host and info.get('port') == port:
                    sock = info.get('sock')
                    if sock:
                        try:
                            sock.getpeername()
                            return True
                        except:
                            pass
            
            # Single connection attempt with timeout
            result = await asyncio.wait_for(
                asyncio.to_thread(self.add_peer, host, port, api_key),
                timeout=timeout
            )
            
            # Verify connection is alive
            await asyncio.sleep(0.1)  # Give it a moment
            
            for agent_id, info in self.pipeline.distribution.remote_agents.items():
                if info.get('host') == host and info.get('port') == port:
                    sock = info.get('sock')
                    if sock:
                        try:
                            sock.getpeername()
                            return True
                        except:
                            pass
            
            return result
            
        except asyncio.TimeoutError:
            print(f"[=] Connection timeout to {host}:{port}")
            return False
        except Exception as e:
            print(f"[=] Connection error to {host}:{port}: {e}")
            return False


    async def _request_peer_prediction_async(self, agent_id, texts):
        """Async peer prediction request"""
        try:
            # Use async version
            return await self.pipeline.distribution.request_prediction_async(agent_id, texts, timeout=5)
        except Exception as e:
            logger.warning(f"[=-] Peer {agent_id} failed: {e}")
            return None

    def _ensemble_predictions(self, local: dict, peers: list) -> dict:
        # Combine predictions from multiple agents
        try:
            print('[=+=] Initiating Ensemble weighting with: {peers} peers total')
            votes = defaultdict(float)
            votes[local.get('prediction', 'unknown')] += local.get('confidence', 0)
            
            for peer in peers:
                if peer and isinstance(peer, dict):
                    votes[peer.get('prediction', 'unknown')] += peer.get('confidence', 0)
            
            best_pred = max(votes.items(), key=lambda x: x[1])
            
            total_weight = len(peers) + 1
            return {
                'prediction': best_pred[0],
                'confidence': min(best_pred[1] / total_weight, 1.0),
                'local_prediction': local.get('prediction'),
                'local_confidence': local.get('confidence'),
                'peer_count': len(peers),
                'ensemble_votes': dict(votes)
            }
        except Exception as e:
            print(f'[-] Error in ensemble weighting; {e}, returning local prediction with 0.0 confidence')
            return {
                'prediction': local,
                'confidence': 0.0,
                'peer_count': 0.0,
            }
     

    async def predict_batch_async(self, texts: List[str], api_key: str = None, client_ip: str = None) -> List[dict]:
        """
        Batch async predictions - runs in parallel!
        """
        tasks = [
            self.predict_async(text, api_key, client_ip)
            for text in texts
        ]
        
        # Run all predictions concurrently
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process results
        output = []
        for text, result in zip(texts, results):
            if isinstance(result, Exception):
                output.append({
                    'text': text,
                    'prediction': 'error',
                    'confidence': 0.0,
                    'error': str(result)
                })
            else:
                output.append({
                    'text': text,
                    'prediction': result.get('prediction'),
                    'confidence': result.get('confidence', 0),
                    **result
                })
        
        return output 


    def predict_sync(self, texts: Any, api_key: str = None, client_ip: str = None, method: str = 'advanced') -> dict:
        """
        Synchronous prediction with security.
        Use this for simple, blocking calls.
        """
        # ✅ Direct prediction without async queue
        print('[==] Initiating predict sync...')
        try:
            if method == 'advanced':
                test_titles = texts['test_titles']
                label_map = texts['label_map']
                rules = texts['rules']

                result, chosen_label, confidence = self.manager.advanced_prediction_method(
                    test_titles,
                    label_map,
                    rules,
                    show_proba=True,
                    use_transformer=self.pipeline.use_transformer
                )
                return {
                    'prediction': chosen_label,
                    'confidence': confidence,
                    'result': result
                }
            else:
                # Basic prediction
                text = texts[0] if isinstance(texts, list) and texts else str(texts)
                result = self.pipeline.predict_single(text)
                return result
                        

        except Exception as e:
            logger.error(f"[-] Prediction failed: {e}")
            print(f"[-] Prediction failed: {e}")
            traceback.print_exc()
            return {
                'prediction': 'error',
                'confidence': 0.0,
                'error': str(e)
            }
    
    async def predict_async(self, texts, api_key: str = None, client_ip: str = None) -> dict:
        """
        Asynchronous prediction.
        Use this for non-blocking operations.
        """
        try:
            # Submit request to queue
            request_id = await self.result_queue.submit(
                texts=texts,
                api_key=api_key,
                client_ip=client_ip,
            )
            
            # Wait for result with timeout
            result = await self.result_queue.wait_for_result(
                request_id=request_id,
                timeout=30
            )
            
            return result
            
        except TimeoutError:
            logger.error(f"[-] Async prediction timed out for: {texts}")
            return {
                'prediction': 'timeout',
                'confidence': 0.0,
                'error': 'Request timeout'
            }
        except Exception as e:
            logger.error(f"[-] Async prediction failed: {e}")
            traceback.print_exc()
            return {
                'prediction': 'error',
                'confidence': 0.0,
                'error': str(e)
            }
            
    def get_queue_stats(self) -> Dict:
        # Get result queue statistics
        logger.info("[=] Fetching result queue stats...")
        return self.result_queue.get_status(request_id=None)

     
    # ============ PEER MANAGEMENT ============
    
    def add_peer(self, host: str, port: int, api_key: str = None):
        # Manually add a peer connection
        if not api_key:
            agent_id = f"{host}:{port}"
            if hasattr(self.pipeline.distribution, 'peer_tokens'):
                api_key = self.pipeline.distribution.peer_tokens.get(agent_id)
        else:
            self.pipeline.distribution.add_trusted_agent(f"{host}:{port}", api_key)
        
        # Connecting
        sock = self.pipeline.distribution.connect_to_agent(host, port)
        if host in ['127.0.0.1', 'localhost', '0.0.0.0']:
            if port == self.pipeline.distribution.port or port == 0:
                print(f"[❌] Cannot add self as peer ({host}:{port})")
                return False        

        if sock:
            # Store in known peers
            peer_key = f"{host}:{port}"
            self._known_peers[peer_key] = {
                'host': host,
                'port': port,
                'sock': sock,
                'last_seen': datetime.now(),
                'connected': True
            }
            
            # Start communication task
            task = asyncio.create_task(
                self._handle_peer_communication(host, port, sock)
            )
            self._peer_tasks.append(task)
            
            logger.info(f"✅ Manually added peer {host}:{port}")
            return True
        
        logger.error(f"[-] Failed to add peer {host}:{port}")
        return False
    
    def remove_peer(self, host: str, port: int):
        # Remove a peer connection
        peer_key = f"{host}:{port}"
        
        # Find and disconnect
        for agent_id, info in list(self.pipeline.distribution.remote_agents.items()):
            if info.get('host') == host and info.get('port') == port:
                self.pipeline.distribution.disconnect_agent(agent_id)
                break
        
        # Remove from known peers
        if peer_key in self._known_peers:
            del self._known_peers[peer_key]
        
        logger.info(f"[-] Removed peer {host}:{port}")
    
    def list_peers(self) -> List[Dict]:
        # List all connected peers
        peers = []
        for agent_id, info in self.pipeline.distribution.remote_agents.items():
            if agent_id == 'local':
                continue

            if info.get('port') == 0 or info.get('port') == self.pipeline.distribution.port:
                continue
            if info.get('host') in ['localhost', '127.0.0.1', '0.0.0.0']:
                if info.get('port') == self.pipeline.distribution.port:
                    continue        

            peers.append({
                'agent_id': agent_id,
                'host': info.get('host'),
                'port': info.get('port'),
                'trust': info.get('trust', 1.0),
                'last_seen': info.get('last_seen', datetime.now()).isoformat()
            })

        return peers 

    async def _connect_with_smart_retry(self, agent, host, port, api_key, max_retries=3, delay=1):
        """
        Smart connection with retry - STOPS once connected.
        """
        
        for attempt in range(max_retries):
            # ✅ Check if already connected BEFORE attempting
            existing_peers = agent.list_peers()
            for peer in existing_peers:
                if peer.get('host') == host and peer.get('port') == port:
                    print(f"[/==] Already connected to {host}:{port}, skipping retry")
                    return True
            
            print(f"[/==] Attempt {attempt + 1}/{max_retries}: Connecting to {host}:{port}...")
            
            try:
                # Try to connect
                if asyncio.iscoroutinefunction(agent.add_peer):
                    result = await agent.add_peer(host, port, api_key)
                else:
                    result = agent.add_peer(host, port, api_key)
                
                if result:
                    # ✅ Verify connection was successful
                    await asyncio.sleep(0.5)  # Give it a moment
                    existing_peers = agent.list_peers()
                    for peer in existing_peers:
                        if peer.get('host') == host and peer.get('port') == port:
                            print(f"[✅] Successfully connected on attempt {attempt + 1}")
                            return True
                    
                    print(f"[⚠️] Connection reported success but peer not found")
                    return True
                    
            except Exception as e:
                print(f"[=/] Attempt {attempt + 1} failed: {e}")
            
            # Don't retry if already connected
            if attempt < max_retries - 1:
                # Check again before waiting
                existing_peers = agent.list_peers()
                if any(p.get('host') == host and p.get('port') == port for p in existing_peers):
                    print(f"[=+=] Already connected, stopping retries")
                    return True
                
                print(f"[===] Waiting {delay}s before retry...")
                await asyncio.sleep(delay)
                delay *= 1.5
        
        return False


    # ============ SHUTDOWN ============
    
    async def shutdown(self):
        # Graceful shutdown of all components
        # Graceful shutdown of all components
        logger.info("🛑 Shutting down agent...")
        
        # signal shutdown to all loops
        self._shutdown_event.set()

        # stop worker pool.
        if hasattr(self, 'worker_pool'):
            await self.worker_pool.stop()

        if hasattr(self, 'result_queue'):
            await self.result_queue.stop()   

        # cancel peer tasks
        if self._peer_tasks:
            for task in self._peer_tasks:
                task.cancel()
            await asyncio.gather(*self._peer_tasks, return_exceptions=True)
        
        # stop peer agent server
        if hasattr(self, '_peer_agent'):
            self._peer_agent.stop_server()

        # stop distribution server
        if self.enable_peers:
            self.pipeline.distribution.stop_server()

        # FIX 1 — offload blocking stop() to thread so event loop stays free
        print('[=] Stopping Asynchronous manager setup...')
        await asyncio.get_event_loop().run_in_executor(
            None, 
            lambda: self.async_manager.stop(timeout=5, force=True)
        )

        await asyncio.sleep(0.5)
        print('✅ Agent shutdown complete')

        logger.info("✅ Agent shutdown complete")
    

    def get_api_key(self) -> str:
        # Get the default API key (for client distribution)
        return getattr(self.async_manager, '_default_api_key', None)
    
 

# ============ EXAMPLE: SECURE PEER-TO-PEER CLUSTER ============

async def run_secure_agent_cluster(pipeline,test_titles, label_map, rules, X=None, y=None, agent_id=None, filename=None, title_name=None, label_name=None, manager=None):
    """
    Run multiple agents that securely communicate.
    Stops retrying once connected successfully.
    """
    print("\n" + "="*60)
    print("=== SECURE PEER-TO-PEER CLUSTER ===")
    print("="*60)
    
    # Set discovery secret (in production, use environment variable)
    secret_key = 'my-ultra-safe-secret-key-for-authentication'

    # Agent 1 - Primary (Port 5555)
    agent1 = CohesiveAgentDeployment(
        pipeline=pipeline,
        memory_name="agent_primary",
        filename=filename,
        target_title=title_name,
        label_name=label_name,
        security_level="PRODUCTION",
        enable_peers=True,
        trusted_networks=['127.0.0.1/32', '192.168.1.0/24'],
        peer_discovery_port=5555,
        secret_key=secret_key,
        shared_auth_token=secret_key,
        predict_manager=manager
    )
    
    # Agent 2 - Secondary (Port 5556)
    agent2 = CohesiveAgentDeployment(
        pipeline=pipeline,
        memory_name="agent_secondary",
        filename=filename,
        target_title=title_name,
        label_name=label_name,
        security_level="PRODUCTION",
        enable_peers=True,
        trusted_networks=['127.0.0.1/32', '192.168.1.0/24'],
        peer_discovery_port=5556,
        secret_key=secret_key,
        shared_auth_token=secret_key,
        predict_manager=manager
    )
    
    try:
        # Start both agents
        print("\n🚀 Starting Agent 1...")
        await agent1.start()
        print("✅ Agent 1 started on port 5555")
        
        print("\n🚀 Starting Agent 2...")
        await agent2.start()
        print("✅ Agent 2 started on port 5556")
        
        # Give servers time to fully bind
        await asyncio.sleep(2)
        
        # Get API keys
        api_key = agent1.get_api_key()
        print(f"\n🔑 Using API Key: {api_key[:20]}...")
        
        texts = {"test_titles": test_titles, "label_map": label_map, "rules": rules, "X": X, 'y':y, "use_transformer": True, "agent_id": agent_id}

        # Make prediction with peer ensemble
        # Peer Connection will be ensured successful during P2P 
        result = await agent1.multi_modal_peer_ensemble_prediction(
            texts=texts,
            api_key=api_key,
            method='advanced',
            disable_sync=True
        )    

        result2 = await agent2.multi_modal_peer_ensemble_prediction(
            texts=texts,
            api_key=api_key,
            method='advanced',
            disable_sync=True
        )      
        
        print(f"\n📊 Ensemble Result for Agent 1:")
        print(f"   Prediction: {result.get('prediction', 'N/A')}")
        print(f"   Confidence: {result.get('confidence', 0):.2%}")

        print(f"   Second Prediction: {result2.get('prediction', 'N/A')}")
        print(f"   Second Confidence: {result2.get('confidence', 0):.2%}")

        # Keep running briefly
        print("\n⏳ Cluster stable. Waiting 5 seconds before shutdown...")
        await asyncio.sleep(5)
        agent2._peer_agent.stop_server()
        
    except Exception as e:
        print(f"\n❌ Error in cluster: {e}")
        traceback.print_exc()
        
    finally:
        print("\n🛑 Shutting down cluster...")
        await agent1.shutdown()
        await agent2.shutdown()
        print("✅ Cluster shutdown complete")




async def example_async_with_result_queue(pipeline, test_titles, label_map, rules, agent_id, filename, title_name, label_name):
    # Example using the proper result queue
    
    agent = CohesiveAgentDeployment(
        memory_name="test_agent",
        filename=filename,
        target_title=title_name,
        label_name=label_name,
        security_level="DEVELOPMENT",
        enable_peers=False
    )
    
    await agent.start()
    
    api_key = agent.get_api_key()
    payloads = {"test_titles": test_titles, "label_map": label_map, "rules": rules, "use_transformer": True, "agent_id": agent_id}
    
    # Single async prediction
    print('[==] Single sync prediction: (using single text: "Opening Thesis.docx")')
    sync_result = agent.predict_sync(
        texts=payloads,
        api_key=api_key,
        client_ip="127.0.0.1",
        method='advanced'
    )

    print(f"[=] Sync Result: {sync_result}")


    print("[==] Single async prediction: (using single text: Opening Thesis.docx)")
    result = await agent.predict_async(
        texts=payloads,
        api_key=api_key,
        client_ip="127.0.0.1",
    )
    print(f"[=] Result: {result.get('prediction')} ({result.get('confidence', 0)}")
    
    # Batch async predictions (parallel!)
    print("\n[=] Batch async predictions (parallel):")
    texts = [
        "Watching YouTube",
        "Programming in VS Code",
        "Checking Slack messages",
        "Reading documentation",
        "Taking a break"
    ]
    
    start_time = time.time()
    results = await agent.predict_batch_async(texts, timeout=60, api_key=api_key)
    elapsed = time.time() - start_time
    
    for result in results:
        print(f"[=] '{result['text']}' → {result['prediction']} ({result['confidence']:.1%})")
    
    print(f"\n[=] Completed {len(texts)} predictions in {elapsed:.2f}s")
    
    # Get queue stats
    stats = agent.get_queue_stats()
    print(f"[=] Queue stats: {stats}")
    
    await agent.shutdown()




def initiate_cohesive_agent_deployment_test(pipeline, test_titles, label_map, rules, X, y, agent_id, filename, title_name, label_name, manager):
    print("\n" + "="*60)
    print("🔮 = TESTING COHESIVE AGENT DEPLOYMENT WITH ASYNC MANAGER = ")

    print('Test 1 of Multi agent cluster')
    asyncio.run(run_secure_agent_cluster(pipeline=pipeline, test_titles=test_titles, label_map=label_map, rules=rules, X=X, y=y, agent_id=agent_id, filename=filename, title_name=title_name, label_name=label_name, manager=manager))
      
    print("\n1. Basic async with result queue")
    asyncio.run(example_async_with_result_queue(pipeline=pipeline, test_titles=test_titles, label_map=label_map, rules=rules, X=X, y=y, agent_id=agent_id, filename=filename, title_name=title_name, label_name=label_name))
    

# async manager setup examples
def initiate_prediction_usage(pipeline, manager, predict_wrapper, test_titles, label_map, rules, X, y):
    """Basic synchronous usage."""
    # Use context manager (auto start/stop)
    api_key = 'my-ultra-safe-secret-key-for-authentication'

    with predict_wrapper as wrapper:
        print('[==] Initiating regular prediction')
        texts = {'test_titles': test_titles, 'label_map': label_map, 'rules': rules, 'X':X, 'y':y, 'use_transformer': True}
        regular_predict = wrapper.predict(
        texts=texts, 
        timeout=120,
        retries=None,
        api_key=api_key,
        client_ip=None)

        print('[==] Initiating advanced batch prediction')
        predicted_output = wrapper.advanced_batch_prediction(test_titles, label_map, rules, X=X, y=y, api_key=api_key, client_ip=None)


def initiate_with_retries(pipeline, manager, wrapper, test_titles, label_map, rules, X, y):
    """Example with retry logic."""
    
    try:
        # Will retry up to 5 times
        texts = {"test_titles": test_titles, "label_map": label_map, "rules": rules, "X":X, "y":y, "use_transformer": True}
        result = wrapper.predict(texts, timeout=60, retries=None, api_key=None)
        advanced_result, chosen_label, confidence = wrapper.advanced_prediction_method(manager, test_titles, label_map, rules, X=X, y=y, method='Transformer_included')
        print(f"[=] Result after retries: {result}")
        print(f"[=] Advanced Result: {chosen_label} || ({confidence:.1%})")

    except Exception as e:
        print(f"[!] Failed after retries: {e}")
    finally:
        wrapper.stop()


def initiate_graceful_shutdown(pipeline, wrapper):
    """Example showing graceful shutdown."""
   
    # Submit many async requests
    for i in range(10):
        wrapper.predict_async(f"[=] Request {i}")
    
    # Wait for idle with timeout
    if wrapper.wait_for_idle(timeout=30):
        print("[+] All requests completed")
    else:
        print("[!] Some requests still pending")
    
    # Graceful shutdown
    wrapper.stop(timeout=10)

def AsyncWrappertest(pipeline, prediction_manager, test_titles, label_map, rules, X, y):
    print("\n" + "="*60)
    print("🔮 = TESTING ASYNCHRONOUS PREDICTION WRAPPER = ")
    print("="*60)

    api_key = 'my-ultra-safe-secret-key-for-authentication'

    config = SecurityConfig(
            max_text_length=10000,
            max_queue_size=100,
            rate_limit_requests=60,  # 60 per minute
            require_api_key=True,
            max_pending_tasks=50,
            request_timeout=30.0,

            # Start with no IP restrictions, add via admin API
            allowed_ips=[],
            blocklisted_ips=[],
            require_bootstrap_auth = False
        )

    wrapper = PipelineAsyncManager(pipeline, 
              prediction_manager, 
              config=config, 
              state_file=None, 
              security_level=SecurityLevel.PRODUCTION,
              api_key=api_key, 
              max_workers=4, 
              task_timeout=30, 
              max_retries=3 )

    wrapper.start(method='Transformer_included', bootstrap_token=None)
    
    logging.basicConfig(level=logging.INFO)
    
    # Run examples
    initiate_prediction_usage(pipeline, prediction_manager, wrapper, test_titles, label_map, rules, X, y)
    initiate_with_retries(pipeline, prediction_manager, wrapper, test_titles, label_map, rules, X, y)
    initiate_graceful_shutdown(pipeline, wrapper)

    print("\n✅ Asynchronous prediction wrapper test completed successfully.")


def PermissiveTest():
    print("\n" + "="*60)
    print("🔮 = TESTING HYBRID PREDICTION SYSTEM = ")
    print("="*60)

    print("📖 Loading labels from text file with CSV format...")
    filename = input('|| Insert Filename (press N to skip): ')
    title = input('|| Insert Title name you have in your file (press N to skip): ')
    label = input('|| Insert Label name you have in your file (press N to skip): ')
    agent_id = input('|| Insert Agent ID for distributed inference (press N to skip): ')

    print('📖 Need to insert custom memory Name for the AI')
    file = input('|| Insert Memory name: ')
    print('📖 Need to insert custom SSL certificate and key files for secure communication')
    print('[=] Important for secure external-device Peer to peer between Agents (optional)')

    cert_file = input('|| Insert SSL certificate file (press N to skip): ')
    key_file = input('|| Insert SSL key file (press N to skip): ')
    if cert_file != 'N':
        cert_file = cert_file
    else:
        cert_file = None
    if key_file != 'N':
        key_file = key_file
    else:
        key_file = None

    if file:
        pipeline = IntegratedPipeline(file, use_async=True, agent_port=5001, ssl_cert_file=cert_file, ssl_key_file=key_file)
    else:
        print('|| Using original csv_file.pkl file as fallback...')
        pipeline = IntegratedPipeline('csv_file.pkl', use_async=True, agent_port=5001,ssl_cert_file=cert_file, ssl_key_file=key_file)

    manager = PipelinePredictionManager(pipeline, label_csv='ManualsTraining.txt', target_title='window_title', label='label')

    pipeline.distribution.predict_manager = manager
    if agent_id == 'N':
        agent_id = 'local'

    if filename and title and label and filename != 'N':
        titles, y_raw, label_map = manager.load_labels_from_csv(filename, title, label)
        print(f"✅ Loaded {len(titles)} labeled examples")
    else:
        print('|| Fallback to Original given files...')
        titles, y_raw, label_map = manager.load_labels_from_csv('ManualsTraining.txt', 'window_title', 'label')
        print(f"✅ Loaded {len(titles)} labeled examples")


    print('== Training Model... ==')
    loss_history = pipeline.train(titles, y_raw)

    test_titles = [
    ("Opening Thesis.docx", "slight_work"),
    ("Watching YouTube and Google Chrome", "distracted"),
    ("Watching Slack", "communication"),
    ("Programming in Visual Studio Code", "focused_work"),
    ("Watching netflix.com - Chrome", "break"),
    ]
    rules = [
        # === WORK / PRODUCTIVITY ===
        (r'code|programming|develop|debug|compile|script', 'focused_work'),
        (r'vscode|visual_studio|ide|terminal|shell', 'focused_work'),
        (r'notion|evernote|onenote|notes|todo|task', 'productive'),
        (r'slack|teams|discord|zoom|meeting|call', 'communication'),
        (r'email|gmail|outlook|inbox|mail', 'communication'),
        
        # === ENTERTAINMENT ===
        (r'youtube|netflix|twitch|stream|video', 'entertainment'),
        (r'music|spotify|soundcloud|audio|player', 'entertainment'),
        (r'game|gaming|steam|epic|play', 'gaming'),
        (r'facebook|instagram|tiktok|social|post', 'social_media'),
        
        # === BROWSING ===
        (r'chrome|firefox|edge|safari|browser', 'browsing'),
        (r'google|search|wiki|wiki|article', 'information'),
        (r'stackoverflow|github|docs|documentation', 'research'),
        
        # === FILE MANAGEMENT ===
        (r'download|folder|file|document|pdf', 'file_work'),
        (r'dropbox|onedrive|google_drive|cloud', 'cloud_storage'),
        (r'zip|rar|extract|compress|archive', 'file_management'),
        
        # === SYSTEM / DEV ===
        (r'terminal|cmd|powershell|bash|shell', 'system_work'),
        (r'docker|kubernetes|container|deploy', 'devops'),
        (r'git|commit|push|pull|branch|merge', 'version_control'),
        (r'test|unit|debug|error|exception', 'testing'),
        
        # === DATA / ANALYSIS ===
        (r'excel|spreadsheet|sheet|csv|table', 'data_work'),
        (r'python|r|sql|query|database', 'data_analysis'),
        (r'chart|graph|visualization|dashboard|plot', 'visualization'),
        
        # === COMMUNICATION ===
        (r'whatsapp|telegram|signal|messenger', 'messaging'),
        (r'zoom|meet|webex|video_call', 'video_call'),
        (r'calendar|schedule|event|meeting|appointment', 'scheduling'),
        
        # === CREATIVE ===
        (r'photoshop|illustrator|figma|design|canvas', 'creative'),
        (r'premiere|final_cut|video_edit|render', 'video_editing'),
        (r'blender|3d|model|render|animation', '3d_work'),
        
        # === LEARNING ===
        (r'coursera|udemy|edx|course|learn', 'learning'),
        (r'book|ebook|reader|pdf|document', 'reading'),
        (r'podcast|audiobook|listen|lecture', 'audio_learning'),
        
        # === UTILITY ===
        (r'calculator|converter|tool|utility', 'utility'),
        (r'weather|clock|timer|alarm|reminder', 'utility'),
        (r'translate|language|dictionary|translate', 'utility'),
        
        # === RARITY PATTERNS ===
        (r'common|not_common|twitch|debian|watch', 'very abundant'),
        (r'bit-common|pycharm|unix|code|programming|python|java', 'bit-abundant'),
        (r'medium|discord|teams|zoom|linux_mint|message', 'abundant'),
        (r'rare|pdf|word|macOS|ubuntu|document', 'not abundant'),
        (r'ultra|firefox|edge|browser|unix|web', 'medium rare'),
        (r'ultra_rare|music|linux|Home_linux_router', 'bit-rare'),
        (r'medium-rare|steam|red_hat_enterprise_linux|play|windows', 'very rare'),
        (r'rarer|oracle|system|config|server_linux_router', 'absolute rare'),
    ]

    running = True
    X, y = None, None
    while running:
        permission = input('|| Allow Hybrid prediction test? [Y/N]: ')

        if permission == 'Y' or permission == 'y':
            print('== TEST 1: (titles only without transformer) ==')
            advanced_result = manager.advanced_prediction_method(
            [t[0] for t in test_titles],  # Just titles
            label_map,
            rules,
            X=X, y=y,
            show_proba=True
            )
            time.sleep(5)
        
            print('== TEST 2: (advanced predictions with expected labels and also use transformer)')
            advanced_results = manager.advanced_prediction_method(
            test_titles,  # Titles with expected labels
            label_map,
            rules,
            show_proba=True,
            top_k=4,
            use_transformer=True,
            return_attention=True
        
            )
        
            print("\n📊 COMPARISON: MLP-only vs Hybrid")
            mlp_only = manager.regular_prediction_method(
            [t[0] for t in test_titles],
            label_map,
            rules,
            use_transformer=False
            )
        
            hybrid = manager.regular_prediction_method(
            [t[0] for t in test_titles],
            label_map,
            rules,
            use_transformer=True       
            )
            print('== CompletePipeline Successfully tested! ==')

        permission_continue = input('|| Do you want to test the Asynchronous wrapper for multiple predictions? [Y/N]: ')
        if permission_continue == 'Y' or permission_continue == 'y':
            AsyncWrappertest(pipeline, manager, test_titles, label_map, rules, X, y)
            print('== Asynchronous wrapper Successfully tested! ==')

        cohesive_permission = input('|| Do you want to test the Cohesive Agent Deployment with Async Manager? [Y/N]: ')
        if cohesive_permission == 'Y' or cohesive_permission == 'y':
            if not (filename and title and label and filename != 'N'):
                print('[=] Searching fallback filename: ManualsTraining.txt, window_title, label')
                initiate_cohesive_agent_deployment_test(pipeline,test_titles, label_map, rules, X, y, agent_id, 'ManualsTraining.txt', 'window_title', 'label', manager)
            else:
                initiate_cohesive_agent_deployment_test(pipeline, test_titles, label_map, rules, X, y, agent_id, filename, title, label, manager)
            print('== Cohesive Agent Deployment Successfully tested! ==')

        else:
            running = False
            print('|| Program Prediction test aborted!')
            pass


if __name__ == "__main__":
    try:
        PermissiveTest()
    except Exception as e:
        print(f'|| Program Crashed...,  Error: {e}')
        traceback.print_exc()
        pass


